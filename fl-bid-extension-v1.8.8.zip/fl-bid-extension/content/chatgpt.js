// Injected into the bid chat by the panel: ChatGPT (chatgpt.com) or DeepSeek
// (chat.deepseek.com). Types the prompt, sends it, waits for the answer to finish and
// returns it as plain text. Every so many bids it also deletes the bid chat and starts
// a new one with your first message.
(() => {
  // Change with every update of this file: the panel replaces a copy whose build
  // differs (one left in the page from before an update).
  const BUILD = "1.8.8";
  const prev = window.__flbidGpt;
  if (prev && prev.alive()) {
    if (prev.build === BUILD) return;
    prev.retire();
  } else if (!prev && window.__flbidGptAlive && window.__flbidGptAlive()) {
    // A live copy from before v1.7 cannot be retired; the panel reloads this tab.
    return;
  }

  // The site, for its few differences and for the messages ("DeepSeek took too long").
  const DEEPSEEK = /(^|\.)deepseek\.com$/i.test(location.hostname);
  const SITE = DEEPSEEK ? "DeepSeek" : "ChatGPT";

  // ChatGPT changes its markup from time to time; update these lists if it does.
  // Each list holds the current markup (checked 2026-10-29) and the older one.
  // DeepSeek: its message box ("Message DeepSeek"); the rest of its page is read by
  // text, like an unknown ChatGPT markup.
  const SEL = {
    composer: ["textarea#mobile-composer-prompt", "form textarea[name='prompt']", "[contenteditable='true'][aria-label='Ask ChatGPT']",
      "#prompt-textarea[contenteditable='true']", "div#prompt-textarea", ".ProseMirror[contenteditable='true']", "textarea#prompt-textarea", "main form textarea",
      "textarea#chat-input", "textarea[placeholder*='DeepSeek' i]"],
    send: ["button[data-composer-submit][aria-label='Send message']",
      "button[data-testid='send-button']", "#composer-submit-button", "button[aria-label='Send prompt']", "button[aria-label='Send message']"],
    stop: ["button[data-composer-submit][aria-label*='Stop']",
      "button[data-testid='stop-button']", "button[aria-label='Stop streaming']", "button[aria-label='Stop generating']"],
    user: "[data-message-role='user'], [data-message-author-role='user']",
    assistant: "[data-message-role='assistant'], [data-message-author-role='assistant']",
    content: ["[data-assistant-markdown-root]", ".markdown", ".ds-markdown"],
  };

  const PROPOSAL_RE = /\[\[\s*PROPOSAL\s*\]\]/i;
  const QUESTIONS_RE = /\[\[\s*QUESTIONS\s*\]\]/i;
  const END_RE = /\[\[\s*END\s*\]\]/i;
  // ChatGPT's own screen text that the page-text reader picks up around an answer
  // (it once ended up in a proposal: "You're using the free version of ChatGPT...",
  // "Try Plus free", "Latest response", "Response complete").
  const UI_LINE = new RegExp("^(" + [
    "you['’]re using the free version of chatgpt.*", "upgrade (to plus|for .*)", "try plus free", "get plus",
    "chatgpt can make mistakes.*", "latest response", "response complete", "response stopped",
    "chatgpt said:?", "you said:?", "is this conversation helpful so far\\??", "show more", "show less", "thinking",
    // DeepSeek
    "ai-generated, for reference only", "thought for [0-9.]+ seconds?", "thinking\\.*", "read [0-9]+ web pages?", "found [0-9]+ results?",
  ].join("|") + ")$", "i");
  const dropUiLines = (t) => t.split("\n").filter((l) => !UI_LINE.test(l.trim())).join("\n").replace(/\n{3,}/g, "\n\n").trim();

  // Each ask / wait runs under a token, one per Freelancer tab ("from"). That tab's
  // Stop or next ask stops it, so an earlier wait (its box gone after a page reload)
  // never keeps running alongside; a bid from another tab carries on.
  const tokens = new Map();
  const newToken = (from) => {
    const old = tokens.get(from);
    if (old) old.stopped = true;
    const t = { stopped: false };
    tokens.set(from, t);
    return t;
  };
  // A new chat being made for a tab runs under "chat:<tab>": that tab's next ask waits
  // for it instead of stopping it; its Stop ends both.
  const stopTokens = (from) => {
    for (const [k, t] of tokens) if (from == null || k === from || k === "chat:" + from) t.stopped = true;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Laid out and not hidden with visibility/opacity (a hidden Stop button must not count).
  const visible = (el) => {
    if (!el || !el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && parseFloat(cs.opacity || "1") > 0.05;
  };
  // On screen the way the page's text is (innerText): laid out and not visibility:hidden.
  const shown = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  // Live status for the panel while waiting.
  function progress(text, details) {
    try { chrome.runtime.sendMessage({ type: "cgpt:progress", text, diag: details }).catch(() => {}); } catch (e) {}
  }
  function first(list) {
    for (const s of list) {
      for (const el of document.querySelectorAll(s)) if (visible(el)) return el;
    }
    return null;
  }
  // Checks right away, then every 40 ms: a wait ends as soon as its condition holds.
  async function waitFor(fn, ms, tk) {
    for (const t0 = Date.now(); ; await sleep(40)) {
      if (tk.stopped) throw new Error("Stopped");
      const v = fn();
      if (v) return v;
      if (Date.now() - t0 >= ms) return null;
    }
  }

  // Rendered markdown -> plain text, keeping paragraphs and list markers.
  function plainText(root) {
    let out = "";
    const gap = (n) => {
      if (!out) return;
      // Right after a list marker ("- ", "2. ") the item's text follows on the same line,
      // even when ChatGPT wraps it in its own block.
      if (/(^|\n)[ ]*(- |\d+\. )$/.test(out)) return;
      const have = out.length - out.replace(/\n+$/, "").length;
      if (have < n) out += "\n".repeat(n - have);
    };
    const walk = (node, depth) => {
      node.childNodes.forEach((c) => {
        if (c.nodeType === Node.TEXT_NODE) { out += c.nodeValue; return; }
        if (c.nodeType !== Node.ELEMENT_NODE) return;
        const tag = c.tagName.toUpperCase();
        if (tag === "BUTTON" || tag === "SVG") return;
        if (tag === "BR") { out += "\n"; return; }
        if (tag === "PRE") {
          gap(2);
          out += (c.querySelector("code") || c).textContent.replace(/\n+$/, "");
          gap(2);
          return;
        }
        if (tag === "LI") {
          gap(1);
          const list = c.parentElement;
          const ordered = list && list.tagName === "OL";
          const num = ordered ? Array.prototype.indexOf.call(list.children, c) + (parseInt(list.getAttribute("start"), 10) || 1) : 0;
          out += "  ".repeat(depth) + (ordered ? num + ". " : "- ");
          walk(c, depth + 1);
          gap(1);
          return;
        }
        if (tag === "UL" || tag === "OL") { gap(depth ? 1 : 2); walk(c, depth); gap(depth ? 1 : 2); return; }
        if (/^(P|H[1-6]|BLOCKQUOTE|TABLE|HR)$/.test(tag)) {
          // depth > 0 only inside a list item of the answer itself.
          const inLi = depth > 0;
          if (!inLi || c.previousElementSibling) gap(inLi ? 1 : 2);
          walk(c, depth);
          gap(inLi ? 1 : 2);
          return;
        }
        if (tag === "DIV" || tag === "TR") { gap(1); walk(c, depth); gap(1); return; }
        walk(c, depth);
      });
    };
    walk(root, 0);
    return out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function answerText(msg) {
    for (const s of SEL.content) {
      const parts = msg.querySelectorAll(s);
      if (!parts.length) continue;
      const text = [...parts].map(plainText).join("\n\n").trim();
      // Writing blocks / canvas can sit outside the markdown root; then read the whole message.
      if (PROPOSAL_RE.test(text)) return text;
      const all = plainText(msg);
      return PROPOSAL_RE.test(all) ? all : text;
    }
    return plainText(msg);
  }

  async function insert(el, text, tk) {
    el.focus();
    if (el.tagName === "TEXTAREA") {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    const typed = () => {
      const have = norm(el.innerText), want = norm(text);
      return have.includes(want.slice(0, 60)) && have.length >= want.length * 0.9;
    };
    document.execCommand("selectAll");
    document.execCommand("delete");
    // A paste keeps the line breaks; the editor turns them into paragraphs. The
    // editor handles it at once, so a short look is enough before the fallback.
    const dt = new DataTransfer();
    dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    if (await waitFor(typed, 120, tk)) return;
    document.execCommand("selectAll");
    document.execCommand("insertText", false, text);
    if (!(await waitFor(typed, 400, tk))) throw new Error("Could not type the prompt into " + SITE);
  }

  const composerText = (el) => norm(el ? (el.tagName === "TEXTAREA" ? el.value : el.innerText) : "");
  const usable = (b) => b && !b.disabled && b.getAttribute("aria-disabled") !== "true";
  // The message box's surroundings: its form, or the nearest box holding its buttons
  // (DeepSeek's are elements with role "button").
  function composerArea(composer) {
    if (!composer) return null;
    const form = composer.closest("form");
    if (form) return form;
    for (let el = composer.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      if (el.querySelectorAll("button, [role='button']").length > 1) return el;
    }
    return null;
  }
  const buttonName = (x) => [x.id, x.getAttribute("data-testid"), x.getAttribute("aria-label"), x.type === "submit" ? "submit" : ""].join(" ");

  // The send button: a known one, else a "send"/"submit" button around the message
  // box, never the voice/dictate ones. DeepSeek's has no name: the last icon-only button
  // around its message box (after DeepThink, Search and the paperclip).
  function findSend(composer) {
    const b = first(SEL.send);
    if (b) return b;
    const scope = composerArea(composer);
    if (!scope) return null;
    const named = [...scope.querySelectorAll("button")].find((x) => visible(x) && /send|submit/i.test(buttonName(x)) && !/voice|dictat|stop/i.test(buttonName(x)));
    if (named || !DEEPSEEK) return named || null;
    const icons = [...scope.querySelectorAll("button, [role='button']")].filter((x) => visible(x) && !norm(x.textContent) && x.querySelector("svg") && !x.querySelector("input[type='file']"));
    return icons[icons.length - 1] || null;
  }
  // Enter in the message box. keyCode is set as well: the constructor leaves it 0, and
  // some pages check it.
  function enterKey() {
    const e = new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true });
    for (const k of ["keyCode", "which"]) Object.defineProperty(e, k, { get: () => 13 });
    return e;
  }
  // ChatGPT's Stop button while it writes: a known one, else a visible "stop" button
  // around the message box (its label changes from time to time).
  function stopButton() {
    const b = first(SEL.stop);
    if (b) return b;
    const scope = composerArea(first(SEL.composer));
    if (!scope) return null;
    return [...scope.querySelectorAll("button")].find((x) => visible(x) && /\bstop\b/i.test(buttonName(x)) && !/dictat|voice|record|listen/i.test(buttonName(x))) || null;
  }

  // What the page looked like, so a failed run can be diagnosed from the log.
  function describe(el) {
    if (!el) return "none";
    const a = (n) => el.getAttribute(n);
    return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (el.classList.length ? "." + [...el.classList].slice(0, 2).join(".") : "") +
      (a("data-testid") ? "[testid=" + a("data-testid") + "]" : "") +
      (a("aria-label") ? "[aria=" + a("aria-label") + "]" : "") +
      (!usable(el) ? "[disabled]" : "") + (visible(el) ? "" : "[hidden]");
  }
  // Ancestors of a text node: tag + data-*/role/aria attributes.
  function chainOfNode(n) {
    const out = [];
    for (let el = n.parentElement, i = 0; el && i < 8; el = el.parentElement, i++) {
      const attrs = [...el.attributes].filter((a) => /^(data-|role$|aria-|id$)/.test(a.name)).map((a) => a.name + "=" + a.value.slice(0, 30));
      out.push(el.tagName.toLowerCase() + (attrs.length ? "[" + attrs.join(" ") + "]" : ""));
    }
    return out.join(" < ");
  }
  // The last text nodes matching re (outside scripts/styles), shown or hidden, with their place.
  function copiesOf(re) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const hits = [];
    let n;
    while ((n = w.nextNode())) {
      if (re.test(n.nodeValue) && !n.parentElement.closest("script, style")) hits.push(n);
    }
    const out = hits.slice(-3).map((h) => (shown(h.parentElement) ? "shown " : "hidden ") + chainOfNode(h));
    return out.length ? (hits.length > 3 ? hits.length + " copies, last 3:\n    " : "") + out.join("\n    ") : "not in one text node";
  }

  let currentMarker = "";
  let lastSlow = null;
  function diag() {
    const composer = first(SEL.composer);
    const scope = composerArea(composer) || document;
    const count = (s) => document.querySelectorAll(s).length;
    const esc = (s) => new RegExp(s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    let pageHas = "-";
    try { pageHas = currentMarker ? String(document.body.innerText.includes(currentMarker)) : "-"; } catch (e) {}
    return [
      "script " + BUILD + ", page " + location.pathname,
      "composer " + describe(composer) + " (" + composerText(composer).length + " chars)",
      "buttons " + [...scope.querySelectorAll("button")].filter(visible).slice(0, 15).map(describe).join(" "),
      "user msgs " + count(SEL.user) + ", assistant msgs " + count(SEL.assistant) +
        ", turns " + count("[data-testid^='conversation-turn']") + ", articles " + count("article"),
      "stop " + describe(stopButton()),
      "my message: " + (currentMarker ? copiesOf(esc(currentMarker)) : "-"),
      "my message in the page text: " + pageHas,
      "answer: " + copiesOf(END_RE),
      "page text after my message: " + (lastSlow ? JSON.stringify((lastSlow.text || lastSlow.raw || "").slice(-200)) : "-"),
    ].join("\n");
  }

  // ChatGPT's own control for stopping its thinking and answering at once, if it shows
  // one after our message while it thinks.
  const SKIP_LABEL = /^(skip|skip thinking|answer now|get a quick answer|quick answer)$/i;
  function skipControl(anchor, box) {
    const all = document.querySelectorAll("button, a, [role='button']");
    for (let i = all.length - 1; i >= 0; i--) {
      const b = all[i];
      if (!(anchor.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING)) break;
      if (box && box.contains(b)) continue;
      if (SKIP_LABEL.test((b.innerText || b.getAttribute("aria-label") || "").trim()) && visible(b)) return b;
    }
    return null;
  }

  // Types the text into the message box and sends it. Returns what the chat held before
  // (to tell the new message and answer apart) and how long typing and sending took.
  async function sendText(composer, prompt, marker, tk) {
    const t0 = Date.now();
    const before = document.querySelectorAll(SEL.user).length;
    const oldAnswers = new Set(document.querySelectorAll(SEL.assistant));
    progress("typing the prompt");
    await insert(composer, prompt, tk);
    const typedMs = Date.now() - t0;
    progress("sending");

    // The site took the message once the box empties, a Stop button shows, a new user
    // turn appears or the message shows in the chat. ChatGPT: send button (it appears as
    // soon as the box has text), else Enter. DeepSeek: Enter (its send button has no
    // name), else its send button. Last, the form's submit.
    const accepted = () => {
      const box = first(SEL.composer);
      return document.querySelectorAll(SEL.user).length > before || !!stopButton() || (box && !composerText(box)) ||
        markerNodes(marker, composerArea(box)).length > 0;
    };
    let sentBy = null, send = null;
    const byButton = async () => {
      send = await waitFor(() => { const b = findSend(composer); return usable(b) ? b : null; }, 1000, tk);
      if (send) { send.click(); if (await waitFor(accepted, 2500, tk)) sentBy = "send button"; }
    };
    const byEnter = async () => {
      const box = first(SEL.composer) || composer;
      box.focus();
      box.dispatchEvent(enterKey());
      if (await waitFor(accepted, 2000, tk)) sentBy = "Enter key";
    };
    for (const step of DEEPSEEK ? [byEnter, byButton] : [byButton, byEnter]) if (!sentBy) await step();
    if (!sentBy) {
      const form = (first(SEL.composer) || composer).closest("form");
      if (form && form.requestSubmit) form.requestSubmit();
      if (await waitFor(accepted, 2500, tk)) sentBy = "form submit";
    }
    if (!sentBy) throw new Error(send || DEEPSEEK ? SITE + " did not accept the message" : SITE + " send button not found");
    return { t0, before, oldAnswers, typedMs, sentMs: Date.now() - t0 - typedMs, sentBy };
  }

  // until "questions": return as soon as the proposal is written (see waitAnswer).
  async function ask({ prompt, marker, promptEnd, timeoutMs, from, until }) {
    const tk = newToken(from);
    // A new chat still being made (its first message answered) comes first.
    if (chatJob) {
      progress("waiting for the new chat to be ready");
      await waitFor(() => !chatJob, 360000, tk);
    }
    const composer = await waitFor(() => first(SEL.composer), 15000, tk);
    if (!composer) throw new Error(SITE + " message box not found. Is the chat open and are you logged in?");
    // The last bid returned at [[END]], so ChatGPT may still be finishing it.
    if (stopButton()) {
      progress("still finishing the previous answer");
      if (!(await waitFor(() => !stopButton(), 30000, tk))) throw new Error(SITE + " is still answering an earlier message");
    }

    const { t0, before, oldAnswers, typedMs, sentMs, sentBy } = await sendText(composer, prompt, marker, tk);
    // For the log: earlier prompts from the box in this chat (their "(ref:...)" line;
    // ChatGPT gets slower as a chat grows) and the model ChatGPT's header shows.
    const refs = bidRefs();
    refs.delete("(" + marker + ")");
    const modelBtn = document.querySelector("[data-testid='model-switcher-dropdown-button']");
    const model = modelBtn ? norm(modelBtn.innerText).slice(0, 40) : "";

    const r = await waitAnswer({ marker, promptEnd, before, oldAnswers, timeoutMs, until, tk });
    return Object.assign(r, { typedMs, sentMs, sentBy, answerMs: Date.now() - t0 - typedMs - sentMs, chatBids: refs.size, model });
  }
  // The box's bid prompts in this chat: the "(ref:...)" on their first line.
  const bidRefs = () => new Set((document.querySelector("main") || document.body).textContent.match(/\(ref:[0-9a-z]+\)/g) || []);

  // ---------- reading the answer without knowing ChatGPT's markup ----------
  // Our message starts with this run's marker ("ref:..."). The answer is the page
  // text after it, from [[PROPOSAL]] to [[END]]. Two readers do this: a fast one that
  // starts at the marker (its text node, or the element around it when the page splits
  // it over several elements), and, as the last resort, the page's whole visible text
  // (innerText). A hidden copy of our message (the page may keep one, e.g. to size the
  // box) or a later copy for screen readers has no answer after it, so every copy is
  // tried, the last first.

  // { text: from [[PROPOSAL]] (to [[END]] once it is there), raw: what ChatGPT wrote so
  // far without the format (only once our own prompt's last line is seen) }
  // The last [[PROPOSAL]]: DeepSeek shows its thinking (DeepThink) on the page before the
  // answer, and that may name the marker.
  function cut(t, promptEnd) {
    t = dropUiLines(t);
    const all = [...t.matchAll(new RegExp(PROPOSAL_RE.source, "gi"))];
    const p = all.length ? all[all.length - 1].index : -1;
    if (p < 0) {
      const tail = promptEnd ? t.lastIndexOf(promptEnd) : -1;
      return { text: "", raw: tail >= 0 ? t.slice(tail + promptEnd.length).trim() : "" };
    }
    const a = t.slice(p);
    const e = a.match(END_RE);
    return { text: (e ? a.slice(0, e.index + e[0].length) : a).trim(), raw: "" };
  }

  // Copies of the marker on screen and outside the message box: the text node holding
  // it, or, when the page splits it (link + spans), the smallest element around the
  // piece with the run's id that holds all of it.
  const ownText = (n) => (n.nodeType === Node.TEXT_NODE ? n.nodeValue : n.textContent);
  function markerNodes(marker, box) {
    const out = [];
    if (!marker) return out;
    const id = marker.replace(/^ref:/, "");
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!n.nodeValue.includes(id)) continue;
      let at = n.nodeValue.includes(marker) ? n : null;
      for (let p = n.parentElement, up = 0; !at && p && up < 4; p = p.parentElement, up++) {
        if (p.textContent.includes(marker)) at = p;
      }
      const el = at && (at === n ? n.parentElement : at);
      if (!el || el.closest("textarea, [contenteditable='true']") || (box && box.contains(el)) || !shown(el)) continue;
      if (out[out.length - 1] !== at) out.push(at);
    }
    return out;
  }

  // The page text after node, in page order, up to stopAt (ChatGPT's message box),
  // without reading the chat before it: the rest of node's own text node is the
  // caller's; this adds what follows it at each level up to root. Hidden parts are skipped.
  function textAfterNode(node, root, stopAt) {
    const parts = [];
    for (let cur = node; cur && cur !== root; cur = cur.parentNode) {
      for (let s = cur.nextSibling; s; s = s.nextSibling) {
        if (s.nodeType === Node.TEXT_NODE) { parts.push(s.nodeValue); continue; }
        if (s.nodeType !== Node.ELEMENT_NODE) continue;
        if (stopAt && (s === stopAt || s.contains(stopAt))) return parts.join("\n");
        const cs = getComputedStyle(s);
        if (cs.display === "none" || cs.visibility === "hidden") continue;
        parts.push(s.innerText || "");
      }
    }
    return parts.join("\n");
  }
  const rootOf = (n) => { const main = document.querySelector("main"); return main && main.contains(n) ? main : document.body; };

  // Fast reader. The copy that has the answer after it is kept in st (searching a long
  // bid chat on every look is slow); while no copy has one, they are searched again
  // each second, and while none is on the page, every 300 ms.
  function readFast(st, marker, promptEnd, box) {
    const after = (n) => { const own = ownText(n); return cut(own.slice(own.indexOf(marker) + marker.length) + "\n" + textAfterNode(n, rootOf(n), box), promptEnd); };
    if (st.node && st.node.isConnected && ownText(st.node).includes(marker)) {
      const r = after(st.node);
      if (r.text || Date.now() - st.searchAt < 1000) return r;
    } else if (!st.node && st.searchAt && Date.now() - st.searchAt < 300) {
      return null;
    }
    st.searchAt = Date.now();
    const nodes = markerNodes(marker, box);
    let best = null;
    st.node = null;
    for (let i = nodes.length - 1; i >= 0; i--) {
      const r = after(nodes[i]);
      if (r.text) { st.node = nodes[i]; return r; }
      if (!best) { best = r; st.node = nodes[i]; }
    }
    return best;
  }

  // Slow reader: the page's visible text, as ChatGPT shows it. null = marker not in it.
  function readSlow(marker, promptEnd) {
    const main = document.querySelector("main");
    let t = main ? main.innerText : "";
    if (!t.includes(marker)) t = document.body.innerText || "";
    let i = t.lastIndexOf(marker);
    if (i < 0) return null;
    let best = null;
    for (let k = 0; i >= 0 && k < 6; k++, i = i > 0 ? t.lastIndexOf(marker, i - 1) : -1) {
      const r = cut(t.slice(i + marker.length), promptEnd);
      if (r.text) return r;
      if (!best) best = r;
    }
    return best;
  }

  // The answer is the last assistant message after our own message (ChatGPT's markup,
  // when it is recognised), else what the page readers find after the run's marker.
  // An older bid in the chat is never picked up: the marker is new for every run.
  // "resume" is used when the page reloaded after sending, and to read on in an answer
  // returned early: then only the marker counts.
  // until "questions": the proposal is all that is wanted now. It is complete once the
  // QUESTIONS marker line follows it, so the answer is returned then, marked partial,
  // while ChatGPT goes on with the clarification post (read later with cgpt:wait).
  async function waitAnswer({ marker, promptEnd, before, oldAnswers, timeoutMs, resume, until, tk }) {
    currentMarker = marker || "";
    lastSlow = null;
    const st = { node: null, searchAt: 0 };   // the fast reader's place for this wait
    let slow = null, slowAt = 0, slowCost = 0;
    let last = "", since = Date.now(), lastReport = 0, detailsSent = false, kept = null, foundAt = 0, firstAt = 0;
    let part = "", partSince = 0;   // until "questions": the proposal seen before the QUESTIONS line
    let skipped = false, skipLookAt = 0;
    const t0 = Date.now();
    // foundMs: our message showed in the chat; firstMs: the answer's first line showed;
    // skipped: ChatGPT's own "Skip" / "Answer now" was clicked while it was thinking.
    // path: the chat's address (a new chat gets its /c/ address once the message is in).
    const result = (text, via) => ({ ok: true, text, via, foundMs: foundAt ? foundAt - t0 : null, firstMs: firstAt ? firstAt - t0 : null, skipped, path: location.pathname });
    for (; ; await sleep(100)) {
      if (tk.stopped) throw new Error("Stopped");
      const now = Date.now();
      const waited = now - t0;
      if (waited > (timeoutMs || 360000)) throw new Error(SITE + " took too long to answer");

      const assistants = [...document.querySelectorAll(SEL.assistant)];
      const after = (u) => assistants.filter((a) => u.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_FOLLOWING);
      // Our message, once found with an answer after it, is kept (no re-search of the chat).
      let mine = kept && kept.isConnected ? kept : null;
      if (!mine) {
        const users = [...document.querySelectorAll(SEL.user)];
        const marked = marker ? users.filter((u) => u.textContent.includes(marker)) : [];
        for (let i = marked.length - 1; i >= 0 && !mine; i--) if (after(marked[i]).length) mine = kept = marked[i];
        if (!mine && marked.length) mine = marked[marked.length - 1];
        if (!mine && !resume && users.length > before) mine = users[users.length - 1];
      }
      const answers = mine ? after(mine) : resume ? [] : assistants.filter((a) => !oldAnswers.has(a));
      const answer = answers[answers.length - 1] || null;

      // What each reader sees, best first: ChatGPT's message markup, the fast page
      // reader, the page's visible text (only once it has [[PROPOSAL]]: before that it
      // also holds the message box and footer, not ChatGPT's words).
      const reads = [];
      if (answer) {
        const t = dropUiLines(answerText(answer));
        const r = cut(t, null);
        reads.push({ text: r.text, raw: r.text ? "" : t, how: "message" });
      }
      let fast = null;
      if (marker) {
        fast = readFast(st, marker, promptEnd, composerArea(first(SEL.composer)));
        if (fast) reads.push(Object.assign({ how: "page" }, fast));
        // The page's whole text is the last resort: in a long chat it takes a while to
        // read, and ChatGPT's page (its writing too) waits meanwhile. Never while another
        // reader has the answer; every second while it is the one that has it or our
        // message is not found otherwise; every 3 s while nothing reads as the answer yet.
        const gap = reads.some((r) => r.text) ? Infinity : (slow && slow.text) || !(mine || st.node) ? 1000 : 3000;
        if (now - slowAt >= Math.max(gap, slowCost * 8)) {
          const s0 = Date.now();
          slow = readSlow(marker, promptEnd);
          lastSlow = slow;
          slowAt = Date.now();
          slowCost = slowAt - s0;   // a huge chat is read less often
        }
        if (slow && slow.text && !reads.some((r) => END_RE.test(r.text))) reads.push(Object.assign({ how: "page text" }, slow));
      }
      const found = !!mine || !!fast || !!slow;
      if (found && !foundAt) foundAt = now;
      const pick = reads.find((r) => END_RE.test(r.text)) || reads.find((r) => r.text) || reads.find((r) => r.raw) || null;
      if (pick && pick.text && !firstAt) firstAt = now;
      const seen = pick ? pick.text || pick.raw : "";
      if (seen !== last) { last = seen; since = now; }
      const quiet = now - since;
      // Only a complete answer is used: [[END]] is the last line the format asks
      // for, so once it shows (and one more look finds the text unchanged) the
      // answer is done, without waiting for ChatGPT's Stop button to go away.
      const ended = !!pick && PROPOSAL_RE.test(pick.text) && END_RE.test(pick.text);
      if (ended && quiet >= 100) return result(pick.text, pick.how);
      // The proposal is done when the QUESTIONS line follows it and one more look finds it
      // unchanged (pick.text starts at [[PROPOSAL]]).
      if (until === "questions" && !ended && pick && pick.text) {
        const q = pick.text.search(QUESTIONS_RE);
        const p = q > 0 ? pick.text.slice(0, q) : "";
        if (p !== part) { part = p; partSince = now; }
        else if (p && now - partSince >= 100) return Object.assign(result(pick.text, pick.how), { partial: true });
      }

      const anchor = mine || st.node;
      const busy = !!stopButton() || (!!anchor && [...document.querySelectorAll("[aria-busy='true']")].some((el) => anchor.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING));
      // Thinking (nothing of the answer written yet): ChatGPT's own skip control, once.
      if (anchor && !skipped && !(pick && pick.text) && now - skipLookAt >= 300) {
        skipLookAt = now;
        const skip = skipControl(anchor, composerArea(first(SEL.composer)));
        if (skip) { skip.click(); skipped = true; progress("skipped " + SITE + "'s thinking"); }
      }
      // ChatGPT finished (flag on the current markup, or no change for a while)
      // without the [[END]] line: never fill a half answer.
      const done = answer && answer.hasAttribute("data-message-complete");
      if (last && !busy && quiet > (done ? 3000 : 12000)) {
        // One more look at the page's whole text before giving up on the answer.
        const s = marker ? readSlow(marker, promptEnd) : null;
        if (s && PROPOSAL_RE.test(s.text) && END_RE.test(s.text)) return result(s.text, "page text");
        const tail = last.replace(/\s+/g, " ").trim();
        if (PROPOSAL_RE.test(last)) {
          throw new Error(SITE + "'s answer stopped before its [[END]] line, so it was not used. It ends with: \"" +
            tail.slice(-120) + "\". Nothing was filled; press Start to try again.");
        }
        if (tail.length > 40) {
          throw new Error(SITE + " did not answer in the [[PROPOSAL]] format, so nothing was filled. Its reply starts: \"" + tail.slice(0, 160) + "\"");
        }
      }
      // Never a silent wait: our message must show in the chat, and ChatGPT must start.
      if (!found && waited > (resume ? 20000 : 30000)) {
        throw new Error(resume ? SITE + " reloaded before the prompt was sent. Press Start again."
          : "The prompt was sent, but it does not show in the " + SITE + " chat (looked for 30 s), so the answer cannot be read. Nothing was filled. Send the log (Settings > Log > Copy log).");
      }
      if (found && !last && !busy && now - foundAt > 120000) {
        throw new Error(SITE + " has not answered for 2 minutes (no reply on the page). Nothing was filled; check the chat and press Start again.");
      }
      if (now - lastReport >= 1000) {
        lastReport = now;
        const state = !found ? "looking for your message in the chat" : pick && pick.text ? `writing the bid, ${pick.text.length} chars` : busy ? "thinking" : "waiting for the answer";
        const details = !detailsSent && (waited > 45000 || (!found && waited > 15000)) ? diag() : undefined;
        if (details) detailsSent = true;
        progress(state, details);
      }
    }
  }

  // ---------- a new chat: delete the bid chat, open a new one, send the first message ----------
  // ChatGPT's chat menu (the "..." over the chat, or on its sidebar entry), its Delete
  // item and the confirm dialog. Checked 2026-10-30; update these if ChatGPT changes them.
  // DeepSeek's menu, Delete and confirm have no such names: they are found by their text
  // ("Delete") and the "..." as the icon-only button on the chat's sidebar entry.
  const CHAT_SEL = {
    options: ["button[data-testid='conversation-options-button']", "header button[aria-label='Open conversation options']"],
    sideOptions: "button[data-testid$='-options'], button[aria-label*='options' i], button[data-trailing-button]",
    openSidebar: ["button[data-testid='open-sidebar-button']", "button[aria-label*='open sidebar' i]", "button[aria-label*='show sidebar' i]"],
    newChat: ["a[data-testid='create-new-chat-button']", "button[data-testid='create-new-chat-button']", "a[aria-label='New chat' i]", "button[aria-label='New chat' i]"],
    menu: "[role='menu']",
    item: "[role='menuitem'], button",
    dialog: "[role='dialog'], [role='alertdialog']",
    confirm: ["button[data-testid='delete-conversation-confirm-button']"],
  };
  const DELETE_LABEL = /^delete( chat)?$/i;
  // The chat's id in its address: ChatGPT /c/<id> (also inside a project or GPT),
  // DeepSeek /a/chat/s/<id>; "" on a new chat.
  const chatId = (p) => ((p || "").match(/\/(?:c|chat\/s)\/([0-9a-z-]+)/i) || [])[1] || "";
  // Where a new chat starts for a chat at this address: in its ChatGPT project, in its
  // GPT, else on the site's home page.
  function homeOf(p) {
    if (DEEPSEEK) return "/";
    const project = p.match(/^(\/g\/g-p-[^/]+)\//);
    if (project) return project[1] + "/project";
    const gpt = p.match(/^(\/g\/g-[^/]+)\//);
    return gpt ? gpt[1] : "/";
  }
  // A whole mouse click: ChatGPT's menus open on the press (pointerdown), its buttons on click.
  function press(el) {
    const o = { bubbles: true, cancelable: true, composed: true, button: 0, pointerId: 1, pointerType: "mouse", isPrimary: true };
    el.dispatchEvent(new PointerEvent("pointerdown", Object.assign({ buttons: 1 }, o)));
    el.dispatchEvent(new MouseEvent("mousedown", Object.assign({ buttons: 1 }, o)));
    el.dispatchEvent(new PointerEvent("pointerup", o));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.click();
  }
  const escape = () => (document.activeElement || document.body).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
  // Visible elements showing exactly this text (their own text node), e.g. "Delete".
  function byText(re) {
    const out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const el = n.parentElement;
      if (!el || !re.test(n.nodeValue.trim()) || out.includes(el) || el.closest("script, style, textarea, [contenteditable='true']")) continue;
      if (visible(el)) out.push(el);
    }
    return out;
  }
  // What to press for a piece of text: its button / menu item, else the text's element.
  const clickable = (el) => el.closest("button, [role='button'], [role='menuitem'], [role='option'], a, li") || el;
  // The chat's own entry in the sidebar (a link to its address), and the "..." on it:
  // a named options button, else the entry's last icon-only button.
  const sidebarEntry = (id) => [...document.querySelectorAll("a[href]")].find((a) => chatId(a.pathname) === id) || null;
  function optionsOn(entry) {
    for (let el = entry, up = 0; el && up < 2; el = el.parentElement, up++) {
      const named = el.querySelector(CHAT_SEL.sideOptions);
      if (named) return named;
      const icons = [...el.querySelectorAll("button, [role='button'], [tabindex]")].filter((x) => x !== entry && !norm(x.textContent) && x.querySelector("svg"));
      if (icons.length) return icons[icons.length - 1];
    }
    return null;
  }

  // Deletes the chat on screen, only when it is the box's bid chat: the chat the last
  // bid went to (path) and holding at least atLeast of the box's bid prompts.
  async function deleteChat({ path, atLeast, tk }) {
    const here = location.pathname, id = chatId(here);
    if (!id) throw new Error("the " + SITE + " pane shows no saved chat (" + here + ")");
    if (chatId(path) && chatId(path) !== id) throw new Error("the " + SITE + " pane shows another chat now (" + here + ")");
    const bids = bidRefs().size, need = atLeast || 1;
    if (bids < need) throw new Error(`this ${SITE} chat holds ${bids} bid${bids === 1 ? "" : "s"} from the box, fewer than ${need}`);
    try {
      await deleteByMenu(id, tk);
      return { via: "menu" };
    } catch (e) {
      if (DEEPSEEK || e.message === "Stopped") throw e;
      // ChatGPT: the request its own Delete sends, when its menu is not found or does
      // not work (a page layout the box does not know).
      const diag = chatDiag();
      progress("deleting the old chat (ChatGPT's delete request)");
      try { await deleteByRequest(id); }
      catch (e2) { throw Object.assign(new Error(e.message + "; ChatGPT's delete request did not work either (" + e2.message + ")"), { diag }); }
      return { via: "request", menuError: e.message, diag };
    }
  }
  // ChatGPT's delete request, as its Delete button sends it (the chat leaves your
  // history). The sign-in token is read from ChatGPT's own page and used only here.
  async function deleteByRequest(id) {
    const s = await fetch("/api/auth/session", { credentials: "include" }).then((r) => (r.ok ? r.json() : null), () => null);
    if (!s || !s.accessToken) throw new Error("no ChatGPT sign-in found on the page");
    const r = await fetch("/backend-api/conversation/" + encodeURIComponent(id), {
      method: "PATCH", credentials: "include",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + s.accessToken },
      body: JSON.stringify({ is_visible: false }),
    });
    if (!r.ok) throw new Error("ChatGPT answered " + r.status);
  }
  // Delete through the chat's own menu, as you would.
  async function deleteByMenu(id, tk) {
    // The "..." over the chat, else the one on the chat's sidebar entry (that one may
    // show on hover only, so it need not be visible). A narrow pane (split view) hides
    // the sidebar: it is opened first.
    let entry = sidebarEntry(id);
    let opener = first(CHAT_SEL.options) || (entry && optionsOn(entry));
    if (!opener && !entry) {
      const side = first(CHAT_SEL.openSidebar);
      if (side) {
        press(side);
        entry = await waitFor(() => sidebarEntry(id), 2000, tk);
        opener = entry && optionsOn(entry);
      }
    }
    if (!opener) throw new Error(SITE + "'s chat menu (the ... button) was not found" + (entry ? "" : " (no sidebar entry links to this chat)"));
    // "Delete" already on screen before the menu opens is never the menu's.
    const shownBefore = new Set(byText(DELETE_LABEL));
    const openMenus = () => [...document.querySelectorAll(CHAT_SEL.menu)].filter(visible);
    const deleteItem = () => {
      for (const m of openMenus()) {
        const it = [...m.querySelectorAll(CHAT_SEL.item)].find((x) => DELETE_LABEL.test(norm(x.innerText || x.textContent)) || /delete/i.test(x.getAttribute("data-testid") || ""));
        if (it) return it;
      }
      const t = byText(DELETE_LABEL).filter((el) => !shownBefore.has(el));
      return t.length ? clickable(t[t.length - 1]) : null;
    };
    progress("deleting the old chat (its menu)");
    press(opener);
    let item = await waitFor(deleteItem, 2500, tk);
    if (!item && !openMenus().length) {
      // A menu that opens from the keyboard only.
      opener.focus();
      opener.dispatchEvent(enterKey());
      item = await waitFor(deleteItem, 2000, tk);
    }
    if (!item) {
      const seen = openMenus().map((m) => norm(m.innerText).slice(0, 80)).join(" | ");
      escape();
      throw new Error(seen ? SITE + "'s chat menu has no Delete (it shows: " + seen + ")" : SITE + "'s chat menu did not open (or shows no Delete)");
    }
    const beforeConfirm = new Set(byText(DELETE_LABEL));
    press(item);
    const confirmButton = () => {
      const b = first(CHAT_SEL.confirm);
      if (b) return b;
      for (const d of document.querySelectorAll(CHAT_SEL.dialog)) {
        if (!visible(d)) continue;
        const x = [...d.querySelectorAll("button, [role='button']")].find((x) => visible(x) && DELETE_LABEL.test(norm(x.innerText)));
        if (x) return x;
      }
      // A confirm box without a role: a "Delete" that showed after the menu's was pressed.
      const t = byText(DELETE_LABEL).filter((el) => !beforeConfirm.has(el) && !item.contains(el));
      return t.length ? clickable(t[t.length - 1]) : null;
    };
    const yes = await waitFor(confirmButton, 3000, tk);
    if (!yes) { escape(); throw new Error(SITE + " did not ask to confirm the delete"); }
    progress("deleting the old chat");
    press(yes);
    // Deleted: the site leaves the chat (its address changes), or its sidebar entry goes.
    const gone = () => chatId(location.pathname) !== id || (entry && !sidebarEntry(id));
    if (!(await waitFor(gone, 10000, tk))) throw new Error("Delete was clicked, but " + SITE + " still shows the chat");
  }

  // The new chat without a page load: the site's own link to it (New chat, or the
  // project in the sidebar), else its "New chat" button. false: neither on the page.
  async function openHome(home, tk) {
    if (location.pathname === home) return true;
    const link = [...document.querySelectorAll("a[href]")].find((a) => a.origin === location.origin && a.pathname === home);
    const button = link || (home === "/" ? first(CHAT_SEL.newChat) || byText(/^new chat$/i).map(clickable).pop() : null);
    if (!button) return false;
    if (link) link.click(); else press(button);
    return !!(await waitFor(() => location.pathname === home, 5000, tk));
  }

  // The page around a new chat that did not work out, for the log.
  function chatDiag() {
    const id = chatId(location.pathname), entry = id ? sidebarEntry(id) : null;
    const shownIn = (list) => list.filter(visible).slice(0, 12).map(describe).join(" ") || "none";
    const texts = (sel) => [...document.querySelectorAll(sel)].filter(visible).map((m) => norm(m.innerText).slice(0, 80)).join(" | ") || "none";
    return [
      "script " + BUILD + ", " + SITE + " page " + location.pathname + ", " + innerWidth + " px wide",
      "buttons at the top: " + shownIn([...document.querySelectorAll("button, [role='button'], a[href]")].filter((b) => b.getBoundingClientRect().top < 70)),
      "sidebar entry for this chat: " + (entry ? describe(entry) + ", buttons there: " + ([...entry.parentElement.querySelectorAll("button, [role='button']")].slice(0, 6).map(describe).join(" ") || "none") : "not found") +
        ", links to chats: " + [...document.querySelectorAll("a[href]")].filter((a) => chatId(a.pathname)).length,
      "open menus: " + texts("[role='menu']"),
      "dialogs: " + texts("[role='dialog'], [role='alertdialog']"),
    ].join("\n");
  }

  // Sends your first message in a new chat and waits for ChatGPT's whole reply.
  async function firstMessage({ prompt, tk }) {
    const composer = await waitFor(() => first(SEL.composer), 15000, tk);
    if (!composer) throw new Error(SITE + "'s message box was not found in the new chat");
    if (stopButton() && !(await waitFor(() => !stopButton(), 30000, tk))) throw new Error(SITE + " is still answering an earlier message");
    const { t0, before, oldAnswers } = await sendText(composer, prompt, "", tk);
    // Done once it has started (its Stop button showed, its reply is on the page, or the
    // chat grew after your message showed) and then stopped: no Stop button and the chat
    // unchanged for a moment (shorter once the reply is marked complete; longer when no
    // Stop button was seen, e.g. on DeepSeek, to sit out a pause in its writing).
    const head = norm((prompt.split("\n").find((l) => l.trim()) || "")).slice(0, 40);
    let started = false, stopSeen = false, size = -1, base = -1, since = Date.now(), skipped = false, lastReport = 0;
    for (;; await sleep(150)) {
      if (tk.stopped) throw new Error("Stopped");
      const now = Date.now();
      if (now - t0 > 300000) throw new Error(SITE + " took too long to answer your first message");
      const users = document.querySelectorAll(SEL.user);
      const mine = users.length > before ? users[users.length - 1] : null;
      const answers = [...document.querySelectorAll(SEL.assistant)].filter((a) => !oldAnswers.has(a));
      const answer = answers[answers.length - 1] || null;
      const said = answer ? norm(answer.textContent) : "";
      const busy = !!stopButton();
      const page = (document.querySelector("main") || document.body).textContent;
      const n = page.length;
      if (base < 0 && head && norm(page).includes(head)) base = n;
      if (busy) stopSeen = true;
      if (busy || said || (base >= 0 && n > base + 10)) started = true;
      if (n !== size) { size = n; since = now; }
      if (started && !busy && now - since >= (answer && answer.hasAttribute("data-message-complete") ? 300 : stopSeen ? 1000 : 2500)) {
        return { ok: true, ms: now - t0, reply: said.slice(0, 120), path: location.pathname };
      }
      // Thinking: ChatGPT's own skip control, once.
      if (mine && !skipped && !said) {
        const skip = skipControl(mine, composerArea(first(SEL.composer)));
        if (skip) { skip.click(); skipped = true; }
      }
      if (!started && now - t0 > 60000) throw new Error(SITE + " has not answered your first message for a minute");
      if (now - lastReport >= 1000) {
        lastReport = now;
        progress(started ? SITE + " is answering your first message" : "sent your first message, waiting for " + SITE);
      }
    }
  }

  let chatJob = null;   // a new chat being made: the next ask waits for it
  function asJob(p) {
    chatJob = p;
    const done = () => { if (chatJob === p) chatJob = null; };
    p.then(done, done);
    return p;
  }
  // All of it here in the ChatGPT page, so it goes on even if the Freelancer page is left
  // meanwhile. { load: address }: the page has no link to the new chat; the panel loads
  // that address and then sends the first message (cgpt:first).
  async function newChat({ path, atLeast, prompt, from }) {
    const tk = newToken("chat:" + from);
    const home = homeOf(location.pathname);
    // how: { via: "menu" | "request", menuError, diag } (see deleteChat), for the log.
    const how = await deleteChat({ path, atLeast, tk });
    try {
      progress("opening a new chat");
      if (!(await openHome(home, tk))) return Object.assign({ ok: true, load: home }, how);
      return Object.assign(await firstMessage({ prompt, tk }), how);
    } catch (e) {
      e.deleted = true;   // the old chat is gone: the bid must not go on without the first message
      throw e;
    }
  }

  const handlers = {
    "cgpt:ping": async () => ({ ok: true, build: BUILD, visible: document.visibilityState === "visible" }),
    // The chat on screen: its address, whether it is a saved chat (not a new, empty one),
    // and how many bid prompts from the box it holds. Waits for a new chat being made.
    "cgpt:state": async () => {
      if (chatJob) await chatJob.catch(() => {});
      return { ok: true, path: location.pathname, chat: !!chatId(location.pathname), bids: bidRefs().size };
    },
    "cgpt:newChat": (msg) => asJob(newChat(msg)).catch((e) => { e.diag = e.diag || chatDiag(); throw e; }),
    "cgpt:first": (msg) => asJob(firstMessage({ prompt: msg.prompt, tk: newToken("chat:" + msg.from) })).catch((e) => { e.diag = diag(); throw e; }),
    "cgpt:ask": (msg) => ask(msg).catch((e) => { e.diag = diag(); throw e; }),
    "cgpt:wait": (msg) => {
      return waitAnswer({ marker: msg.marker, promptEnd: msg.promptEnd, timeoutMs: msg.timeoutMs, resume: true, until: msg.until, tk: newToken(msg.from) }).catch((e) => { e.diag = diag(); throw e; });
    },
    "cgpt:abort": async (msg) => {
      stopTokens(msg.from);
      const stop = stopButton();
      if (stop) stop.click();
      return { ok: true };
    },
    "cgpt:retire": async () => { retire(); return { ok: true }; },
  };
  const listener = (msg, _sender, reply) => {
    const h = handlers[msg && msg.type];
    if (!h) return false;
    h(msg).then(reply, (e) => reply({ ok: false, error: e && e.message ? e.message : String(e), diag: e && e.diag, deleted: !!(e && e.deleted) }));
    return true;
  };
  function retire() {
    stopTokens(null);
    try { chrome.runtime.onMessage.removeListener(listener); } catch (e) {}
    if (window.__flbidGpt === me) window.__flbidGpt = null;
  }
  const me = {
    build: BUILD,
    alive: () => { try { return !!chrome.runtime.id; } catch (e) { return false; } },
    retire,
  };
  window.__flbidGpt = me;
  chrome.runtime.onMessage.addListener(listener);
})();
