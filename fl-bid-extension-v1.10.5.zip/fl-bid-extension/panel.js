// The panel is both the interface and the runner. It lives in the small box that
// box.js puts on a Freelancer project page (as a frame, so it can use the extension
// APIs) and drives its own Freelancer tab and the AI chat tab (ChatGPT or DeepSeek, as
// chosen in Settings) through their content scripts, one step at a time. It works with
// the chat that is already open next to Freelancer (e.g. Chrome split view) and never
// opens a new tab for it.

const DEFAULT_PROMPT = `Write my bid for this Freelancer.com project, following my bid strategy in this chat. Also write the Clarification Board post: real questions about the client's requirements, no greeting, no self-promotion, no links or contact details.

{{PROJECT}}`;

// Freelancer's own limits for the proposal text (its bid form code): at most 1500
// characters, at least 100 unless the project's label says otherwise.
const MAX_PROPOSAL = 1500;
const MIN_PROPOSAL = 100;

// Always added at the end of the prompt, so editing the prompt cannot break the
// reply format the panel reads. The markers are described, never written out:
// only ChatGPT's answer may contain "[[PROPOSAL]]", so the page reader cannot
// mistake our own prompt (shown in the chat, maybe cut short) for the answer.
// The prompt's last line; the ChatGPT page reader skips our own prompt up to here.
// For speed: no web search (a link in the prompt made ChatGPT search the web first),
// and a short clarification post after the proposal (the box can take the proposal
// while the post is still being written), or none when the box will not post it.
const PROMPT_END = "Nothing before the PROPOSAL marker and nothing after the END marker.";
const FORMAT_HEAD = `ANSWER FORMAT (required, a tool reads your reply):
Answer at once from the text above: no web search, no opening links, no other tools.
Reply as plain chat text, not in a writing block, canvas, code block or JSON.`;
// post: "with" (the answer holds the clarification board post) or "none". Without a
// post the QUESTIONS line stays, so a post ChatGPT writes anyway can never end up in
// the proposal.
const POST_LINE = {
  with: "Write the proposal first, then the clarification board post. Keep the post short: at most 3 questions.",
  none: "Do not write a clarification board post, none is needed: after the QUESTIONS line write only the word none.",
};
const answerFormat = (minChars, post = "with") => `${FORMAT_HEAD}
Use three marker lines, each one word inside double square brackets: PROPOSAL on the line before the proposal, QUESTIONS on the line before the clarification board post, and END on the last line.
The proposal must be ${minChars} to ${MAX_PROPOSAL} characters long, spaces included (Freelancer refuses anything longer).
${POST_LINE[post] || POST_LINE.with}
${PROMPT_END}`;

const FL_PROJECT = /^https:\/\/([a-z0-9-]+\.)?freelancer\.com\/projects\//i;
// The AI chat sites (settings.ai). page: any page of the site (a split view pane may be
// a new, empty chat); chat: a saved chat (what is used outside split view).
// content/chatgpt.js works on both.
const AIS = {
  chatgpt: { name: "ChatGPT", origin: "https://chatgpt.com", tabs: "https://chatgpt.com/*",
    page: /^https:\/\/chatgpt\.com\//i, chat: /^https:\/\/chatgpt\.com\/(.*\/)?(c|g|uc)\//i },
  deepseek: { name: "DeepSeek", origin: "https://chat.deepseek.com", tabs: "https://chat.deepseek.com/*",
    page: /^https:\/\/chat\.deepseek\.com\//i, chat: /^https:\/\/chat\.deepseek\.com\/a\/chat\/s\//i },
};
const ai = () => AIS[settings.ai] || AIS.chatgpt;
const AI = () => ai().name;

const VERSION = chrome.runtime.getManifest().version;
// The content scripts' BUILD (content/freelancer.js, content/chatgpt.js): change all
// three together. A tab holding a copy with another build gets the current file.
const SCRIPT_BUILD = "1.10.5";
// waitNoBids / waitWithBids: Place Bid is clicked that many seconds after Start,
// by whether the project already has bids. rules: the Prices table (null = built-in).
// newChatAfter / firstPrompt: after that many bids in one chat it is deleted and a new
// chat starts with that first message (see renewChat; off while it is empty).
// ai: the AI chat the bids are written in, "chatgpt" or "deepseek" (see AIS).
// mySkills / skillMatch: auto bid bids on a new project when at least skillMatch % of
// its skills are in mySkills (see skillFit).
const settings = { prompt: DEFAULT_PROMPT, review: true, clarify: true, waitNoBids: 15, waitWithBids: 0, rules: null,
  upSponsored: false, upSealed: false, upHighlight: false, showMore: false, newChatAfter: 20, firstPrompt: "", ai: "chatgpt",
  mySkills: "", skillMatch: 70 };
const newChatOn = () => settings.newChatAfter > 0 && !!(settings.firstPrompt || "").trim();
// Panel checkbox id -> upgrade name on the bid form.
const UPGRADE_BOXES = { upSponsored: "sponsored", upSealed: "sealed", upHighlight: "highlight" };
// The start buttons next to Start: Sponsored and Highlight for that bid only, in place
// of the Settings checkboxes (Sealed still comes from Settings).
const START_UPGRADES = {
  startSponsored: { sponsored: true, highlight: false },
  startHighlight: { sponsored: false, highlight: true },
  startBoth: { sponsored: true, highlight: true },
};
const upgradeNames = (pick) => [pick.sponsored && "Sponsored", pick.highlight && "Highlight"].filter(Boolean).join(" + ");
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const secs = (ms) => (ms / 1000).toFixed(1);

let running = false;
let stopRequested = false;
let stopper = null;        // { promise, reject } for the current run: Stop rejects it
let gptTabBusy = null;     // AI chat tab id while it is generating (for Stop)
let gptStep = null;        // { label, at } while waiting for the AI (status line)
let continueWait = null;   // { resolve, reject } while paused for review
let myTabId = null;        // the Freelancer tab this panel's box is on

// ---------- interface ----------

function setStatus(text) { $("status").textContent = text; }
function log(text, kind) {
  const li = document.createElement("li");
  li.textContent = new Date().toLocaleTimeString() + "  " + text;
  if (kind) li.className = kind;
  const list = $("log");
  list.prepend(li);
  while (list.children.length > 500) list.lastChild.remove();
}
function setRunning(on) {
  running = on;
  $("start").disabled = on;
  for (const id in START_UPGRADES) $(id).disabled = on;
  for (const id of COPY_BUTTONS) $(id).disabled = on;
  $("stop").disabled = !on;
  if (!on) $("continue").hidden = true;
}
const COPY_BUTTONS = ["copyDetails", "copyProposal", "copyAll", "copyChatAll", "copyChatLast"];
function showLast(plan, bid) {
  const box = $("last");
  box.textContent = "";
  const add = (tag, text) => { const el = document.createElement(tag); el.textContent = text; box.append(el); };
  add("div", plan.summary);
  add("pre", bid.proposal);
  if (bid.questions) { add("div", "Clarification question:"); add("pre", bid.questions); }
  $("lastBox").open = true;
}

async function loadSettings() {
  Object.assign(settings, await chrome.storage.local.get(settings));
  $("prompt").value = settings.prompt;
  $("review").checked = settings.review;
  $("clarify").checked = settings.clarify;
  $("waitNoBids").value = settings.waitNoBids;
  $("waitWithBids").value = settings.waitWithBids;
  for (const id in UPGRADE_BOXES) $(id).checked = settings[id];
  $("newChatAfter").value = settings.newChatAfter;
  $("firstPrompt").value = settings.firstPrompt || "";
  showNewChat();
  for (const r of document.querySelectorAll("input[name='ai']")) r.checked = r.value === (AIS[settings.ai] ? settings.ai : "chatgpt");
  $("mySkills").value = settings.mySkills || "";
  $("skillMatch").value = settings.skillMatch;
  $("skillMatchTop").value = settings.skillMatch;
  showSkills();
  renderRules();
  showMore(settings.showMore);
}
function showNewChat() {
  $("newChatMsg").textContent = newChatOn()
    ? `On: after ${settings.newChatAfter} bids in one chat, that chat is deleted and a new one starts with this message.`
    : settings.newChatAfter > 0 ? "Off until this message is filled in." : "Off (0 bids).";
}
function showMore(on) {
  $("more").hidden = !on;
  $("toggleMore").setAttribute("aria-expanded", String(on));
}
function save(key, value) {
  settings[key] = value;
  chrome.storage.local.set({ [key]: value });
}

$("prompt").addEventListener("change", (e) => save("prompt", e.target.value));
$("review").addEventListener("change", (e) => save("review", e.target.checked));
$("clarify").addEventListener("change", (e) => { save("clarify", e.target.checked); showCheck(lastCheck); });
for (const id in UPGRADE_BOXES) $(id).addEventListener("change", (e) => save(id, e.target.checked));
for (const r of document.querySelectorAll("input[name='ai']")) r.addEventListener("change", (e) => { if (e.target.checked) save("ai", e.target.value); });
$("firstPrompt").addEventListener("input", (e) => { save("firstPrompt", e.target.value); showNewChat(); });
$("newChatAfter").addEventListener("change", (e) => {
  const n = Math.max(0, Math.min(500, parseInt(e.target.value, 10) || 0));
  e.target.value = n;
  save("newChatAfter", n);
  showNewChat();
});
for (const id of ["waitNoBids", "waitWithBids"]) {
  $(id).addEventListener("change", (e) => {
    const s = Math.max(0, Math.min(600, parseInt(e.target.value, 10) || 0));
    e.target.value = s;
    save(id, s);
    showCheck(lastCheck);
  });
}

// ---------- auto bid: which projects fit (Settings > Auto bid) ----------

// The same skill however it is written: case, spacing and "&" do not matter, nor a
// ".js" ending or a generic word ("C# Programming" = "C#", "Node.js" = "Node",
// "Laravel Framework" = "Laravel"). Different skills stay different ("Java" /
// "JavaScript", "SQL" / "MySQL").
const SKILL_WORDS = /\b(programming|development|developer|framework|language)\b/g;
const normSkill = (s) => {
  const t = String(s).toLowerCase().replace(/&/g, " and ").replace(/\.js\b|\bjs\b(?=\s*$)/g, " ").replace(/[^a-z0-9#+.]+/g, " ");
  const short = t.replace(SKILL_WORDS, " ").replace(/\s+/g, " ").trim();
  return short || t.replace(/\s+/g, " ").trim();
};
const mySkills = () => [...new Set(String(settings.mySkills || "").split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean))];
// { ok, matched: [...], missing: [...], pct } for the project's skills against yours.
function skillFit(projectSkills) {
  const mine = new Set(mySkills().map(normSkill));
  const list = [...new Set((projectSkills || []).map((s) => String(s).trim()).filter(Boolean))];
  const matched = list.filter((s) => mine.has(normSkill(s)));
  const missing = list.filter((s) => !mine.has(normSkill(s)));
  const pct = list.length ? Math.round((matched.length * 100) / list.length) : 0;
  return { ok: list.length > 0 && pct >= settings.skillMatch, matched, missing, pct, total: list.length };
}
function showSkills() {
  const n = mySkills().length;
  $("autoMsg").textContent = n ? `${n} skill${n === 1 ? "" : "s"} in your list. Auto bid bids when at least ${settings.skillMatch} % of a project's skills are among them.` :
    "Your list is empty: auto bid needs it to pick projects.";
}
$("mySkills").addEventListener("input", (e) => { save("mySkills", e.target.value); showSkills(); });
// The share of a project's skills that must be yours: set next to the Auto switch or in
// Settings > Auto bid (the same number). Saved as you type (1 to 100); the field is put
// right when you leave it.
const SKILL_MATCH_BOXES = ["skillMatch", "skillMatchTop"];
function setSkillMatch(value, from, tidy) {
  const typed = parseInt(value, 10);
  const n = Math.max(1, Math.min(100, isFinite(typed) ? typed : settings.skillMatch));
  if (isFinite(typed) && n !== settings.skillMatch) save("skillMatch", n);
  if (tidy && settings.skillMatch !== setSkillMatch.logged) {
    setSkillMatch.logged = settings.skillMatch;
    log(`Auto bid: at least ${settings.skillMatch} % of a project's skills must be yours`);
  }
  for (const id of SKILL_MATCH_BOXES) if (id !== from || tidy) $(id).value = settings.skillMatch;
  showSkills();
  showCheck(lastCheck);
}
for (const id of SKILL_MATCH_BOXES) {
  $(id).addEventListener("input", (e) => { if (e.target.value !== "") setSkillMatch(e.target.value, id, false); });
  $(id).addEventListener("change", (e) => setSkillMatch(e.target.value, id, true));
}
// Settings changed in the box of another tab (auto bid runs in every tab): taken over here
// at once, so all tabs bid by the same settings.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  let shown = false;
  for (const k in changes) {
    if (!(k in settings) || k === "showMore") continue;
    settings[k] = changes[k].newValue;
    shown = true;
    const el = document.getElementById(k);
    if (!el || el === document.activeElement) continue;
    if (el.type === "checkbox") el.checked = !!settings[k];
    else if (el.tagName === "TEXTAREA" || el.type === "number") el.value = settings[k] == null ? "" : settings[k];
  }
  if ("skillMatch" in changes) for (const id of SKILL_MATCH_BOXES) if ($(id) !== document.activeElement) $(id).value = settings.skillMatch;
  if (shown) { showSkills(); showNewChat(); if (typeof lastCheck !== "undefined") showCheck(lastCheck); }
});
$("addSkills").addEventListener("click", async () => {
  try {
    await ping({ id: myTabId, title: "Freelancer" }, "content/freelancer.js", "fl:ping");
    const r = await call(myTabId, { type: "fl:skills" }, 5000);
    const have = new Set(mySkills().map(normSkill));
    const add = (r.skills || []).filter((s) => !have.has(normSkill(s)));
    if (!(r.skills || []).length) { $("autoMsg").textContent = "No skill tags found on this page (open a project's Details)."; return; }
    const list = mySkills().concat(add);
    $("mySkills").value = list.join("\n");
    save("mySkills", $("mySkills").value);
    showSkills();
    $("autoMsg").textContent = add.length ? `Added: ${add.join(", ")}. ` + $("autoMsg").textContent : "All of this project's skills are in your list already.";
  } catch (e) {
    $("autoMsg").textContent = "Could not read the skills: " + e.message;
  }
});

// ---------- Prices (the tier table pricing.js uses) ----------

const RULE_FIELDS = ["from", "to", "price", "period"];
const rules = () => flCleanRules(settings.rules);

function ruleRow(type, r) {
  const tr = document.createElement("tr");
  for (const f of RULE_FIELDS) {
    const td = document.createElement("td");
    const input = document.createElement("input");
    input.type = "number";
    input.min = "0";
    input.step = "any";
    input.dataset.field = f;
    input.value = r[f] == null || r[f] === Infinity ? "" : r[f];
    if (f === "to") input.placeholder = "no limit";
    input.addEventListener("input", saveRules);
    td.append(input);
    tr.append(td);
  }
  const td = document.createElement("td");
  const del = document.createElement("button");
  del.textContent = "x";
  del.title = "Remove this tier";
  del.addEventListener("click", () => { tr.remove(); saveRules(); });
  td.append(del);
  tr.append(td);
  $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].append(tr);
  return tr;
}

function renderRules() {
  const table = rules();
  for (const type of ["fixed", "hourly"]) {
    $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].textContent = "";
    for (const r of table[type]) ruleRow(type, r);
  }
  $("rulesMsg").textContent = settings.rules ? "Your prices are in use." : "Built-in prices are in use.";
  $("rulesMsg").className = "small";
}

// Reads both tables; rows with a problem are marked and not saved (the others are).
function saveRules() {
  const out = {};
  let bad = 0;
  for (const type of ["fixed", "hourly"]) {
    out[type] = [];
    for (const tr of $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].rows) {
      const v = {};
      tr.querySelectorAll("input").forEach((i) => { v[i.dataset.field] = i.value.trim() === "" ? null : Number(i.value); });
      const ok = v.from != null && v.from >= 0 && (v.to == null || v.to > v.from) && v.price > 0 && v.period > 0;
      tr.querySelectorAll("input").forEach((i) => i.classList.toggle("bad", !ok));
      if (ok) out[type].push(v); else bad++;
    }
    if (!out[type].length) { bad++; out[type] = null; }
  }
  // A table with no good row keeps the built-in tiers for that type.
  const saved = { fixed: out.fixed || FL_RULES.fixed.map(toStored), hourly: out.hourly || FL_RULES.hourly.map(toStored) };
  save("rules", saved);
  $("rulesMsg").textContent = bad ? "Rows marked red are not used: \"from\" must be below \"to\", bid and days/hours above 0." : "Saved. Your prices are in use.";
  $("rulesMsg").className = bad ? "small err" : "small";
}
const toStored = (r) => ({ from: r.from, to: r.to === Infinity ? null : r.to, price: r.price, period: r.period });

$("addFixed").addEventListener("click", () => ruleRow("fixed", { from: "", to: "", price: "", period: "" }).querySelector("input").focus());
$("addHourly").addEventListener("click", () => ruleRow("hourly", { from: "", to: "", price: "", period: "" }).querySelector("input").focus());
$("resetRules").addEventListener("click", () => { save("rules", null); renderRules(); });

// ---------- notices: things that stop a bid, shown before Start ----------

// kind (from freelancer.js blocker()) -> short label for the box, red or amber.
const NOTICE = {
  already: { label: "Already bid", level: "warn" },
  verified: { label: "Verified only", level: "err" },
  preferred: { label: "Preferred only", level: "err" },
  restricted: { label: "Bidding restricted", level: "err" },
  sign: { label: "Sign agreement first", level: "err" },
  nobids: { label: "No bids left", level: "err" },
  noform: { label: "No bid form", level: "warn" },
  nda: { label: "NDA to sign", level: "warn" },
};
const NO_FORM_TEXT = "Freelancer shows no bid form on this project: you have probably bid on it already (your bid is in the bid list), or bidding is closed.";
const NDA_TEXT = "Freelancer takes a bid on this project only after you sign its Non-Disclosure Agreement. Start writes and fills the bid, opens the NDA in a new tab and waits: sign it, then click Place Bid yourself (or press Continue).";
function noticeText(b) {
  if (b.kind === "already") return "You already bid on this project.";
  if (b.kind === "noform") return NO_FORM_TEXT;
  if (b.kind === "nda") return NDA_TEXT;
  if (b.kind === "preferred") return "Only Preferred Freelancers can bid on this project.";
  if (b.kind === "verified") {
    const limit = (b.message.match(/projects\s+(.+?)\s+and over/i) || [])[1];
    return "You must be Verified by Freelancer to bid on this project" + (limit ? " (" + limit + " and over)" : "") + ".";
  }
  return b.message;
}
function showNotice(b) {
  const el = $("notice");
  const n = b && (NOTICE[b.kind] || { label: "Can't bid", level: "err" });
  // A short message from a copy button stays until it times out (see showToast).
  if (!n && el.dataset.toast === "1") {
    parent.postMessage({ flbidNotice: null }, location.ancestorOrigins[0] || "*");
    return;
  }
  el.dataset.toast = "";
  el.hidden = !n;
  if (n) {
    el.textContent = n.label;
    el.className = n.level;
    el.title = noticeText(b);
  }
  // The box's top bar shows it too, in the same colour.
  parent.postMessage({ flbidNotice: n ? { label: n.label, level: n.level, text: noticeText(b) } : null }, location.ancestorOrigins[0] || "*");
}

// Seconds after Start for the Place Bid click, by the project's bid count
// (unknown count: the longer, no-bids wait).
const bidWait = (bids) => (bids > 0 ? settings.waitWithBids : settings.waitNoBids);

let lastCheck = null;
// "No bid form" only once the project page has shown no form for 3 s, so a page
// that is still loading does not flash it.
let noForm = { url: null, since: null };
// The kind of page the box is on (fl:check): project pages get Start and the project
// copy buttons, chat pages the chat copy buttons.
let pageKind = "project";
function showPage(kind) {
  if (!kind || kind === pageKind) return;
  pageKind = kind;
  document.body.classList.remove("page-project", "page-messages", "page-other");
  document.body.classList.add("page-" + kind);
}
function showCheck(r) {
  if (!r) return;
  lastCheck = r;
  showPage(r.page);
  if (r.page && r.page !== "project") {
    showNotice(null);
    $("info").textContent = "";
    return;
  }
  if (r.url !== noForm.url) noForm = { url: r.url, since: null };
  // A "you cannot bid" text next to a bid form you can use does not stop a bid (see
  // blocker() in freelancer.js).
  const blocked = r.blocker && !r.blocker.formShown ? r.blocker : null;
  if (r.loaded && r.hasForm === false && !blocked) noForm.since = noForm.since || Date.now();
  else noForm.since = null;
  const missing = noForm.since && Date.now() - noForm.since >= 3000;
  const stop = blocked || (missing ? { kind: "noform", message: NO_FORM_TEXT } : null);
  showNotice(stop || (r.nda ? { kind: "nda" } : null));
  // The time is counted from the Start click (it includes ChatGPT and filling).
  const when = stop || r.bids == null ? "" : r.nda ? `Bids: ${r.bids}, Place Bid: you, after signing the NDA` : `Bids: ${r.bids}, Place Bid at ${bidWait(r.bids)} s`;
  // The clarification question, when it cannot go up: said before Start.
  const board = stop ? "" : !settings.clarify ? "Clarification question: off (Settings)" :
    r.board === "locked" ? "Clarification board: only Verified users can post" : "";
  // How many of the project's skills are in your list (what auto bid goes by).
  let fit = "";
  if (r.skills && r.skills.length && mySkills().length) {
    const f = skillFit(r.skills);
    fit = `Skills: ${f.matched.length} of ${f.total} yours (${f.pct} %` + (f.ok ? ")" : `, ${settings.skillMatch} % needed)`);
  }
  $("info").textContent = [when, board, fit].filter(Boolean).join(" · ");
  $("info").title = "Place Bid is clicked this many seconds after Start, counted from the Start click; reading the project, the AI chat and filling happen within that time. If they take longer, it clicks right away.";
}
// While idle, look at the page every few seconds (Freelancer changes pages without
// reloading, and the bid count arrives after the page). One look at a time.
let idleBusy = false;
async function idleCheck() {
  if (running || myTabId == null || idleBusy) return;
  idleBusy = true;
  try {
    const ask = () => quick(chrome.tabs.sendMessage(myTabId, { type: "fl:check" }), 5000);
    let r = await ask();
    if (!r || r.build !== SCRIPT_BUILD) {
      await load(myTabId, "content/freelancer.js", "fl", r);
      r = await ask();
    }
    if (r && r.ok && !running) showCheck(r);
    await warmChatGPT();
  } finally {
    idleBusy = false;
  }
}
// Load the ChatGPT script into the chat tab ahead of time, so Start goes straight
// to typing the prompt. Quiet: any problem shows up when Start runs.
async function warmChatGPT() {
  try {
    const { gpt } = await findTabs();
    const r = await quick(chrome.tabs.sendMessage(gpt.id, { type: "cgpt:ping" }), 3000);
    if (!r || r.build !== SCRIPT_BUILD) await load(gpt.id, "content/chatgpt.js", "cgpt", r);
  } catch (e) { /* no AI chat open yet */ }
}
// A message that may never be answered: its reply, or null after ms (or on an error).
function quick(promise, ms) {
  let timer;
  return Promise.race([promise.catch(() => null), new Promise((r) => { timer = setTimeout(() => r(null), ms); })])
    .finally(() => clearTimeout(timer));
}
// Injects a content script; an older copy that answered (r) is retired first, so it
// stops listening and only the current file answers.
async function load(tabId, file, prefix, r) {
  if (r) await quick(chrome.tabs.sendMessage(tabId, { type: prefix + ":retire" }), 2000);
  await chrome.scripting.executeScript({ target: { tabId }, files: [file] }).catch(() => {});
}
$("resetPrompt").addEventListener("click", () => { $("prompt").value = DEFAULT_PROMPT; save("prompt", DEFAULT_PROMPT); });

$("start").addEventListener("click", () => { if (!running) run(); });
for (const id in START_UPGRADES) $(id).addEventListener("click", () => { if (!running) run(START_UPGRADES[id]); });
$("stop").addEventListener("click", async () => {
  if (!running) return;
  stopRequested = true;
  setStatus("Stopping...");
  if (continueWait) continueWait.reject(new Error("Stopped"));
  const gpt = gptTabBusy;
  // Ends any wait for a page at once (except Post and Place Bid, whose result is
  // waited for: a click that happened cannot be undone, and the log must say so).
  if (stopper) stopper.reject(new Error("Stopped"));
  if (gpt) await quick(chrome.tabs.sendMessage(gpt, { type: "cgpt:abort", from: myTabId }), 2000);
});
$("continue").addEventListener("click", () => { if (continueWait) continueWait.resolve(); });
$("toggleMore").addEventListener("click", () => { const on = $("more").hidden; showMore(on); save("showMore", on); });
$("setShortcut").addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));

// ---------- keyboard shortcut ----------
// background.js picks the Freelancer tab and sends "panel:start" with its id; only
// that tab's panel answers. If none answers (the box was not loaded yet), it leaves
// a pendingStart note in session storage that the panel reads on load.
// The shortcut works like the main button: Start, or Continue while paused for review.

function shortcutPressed() {
  if (continueWait) continueWait.resolve();
  else if (!running) run();
}
async function takePendingStart(p) {
  if (!p || Date.now() - p.at > 10000 || p.tabId !== myTabId) return;
  await chrome.storage.session.remove("pendingStart");
  shortcutPressed();
}
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || msg.type !== "panel:start" || msg.tabId !== myTabId) return;
  reply({ ok: true });
  shortcutPressed();
});
chrome.storage.session.onChanged.addListener((changes) => {
  if (changes.pendingStart) takePendingStart(changes.pendingStart.newValue);
});
async function showShortcut() {
  const cmd = (await chrome.commands.getAll()).find((c) => c.name === "start-bid");
  const key = cmd && cmd.shortcut;
  $("startKey").textContent = key ? "(" + key + ")" : "";
  $("shortcut").textContent = key || "not set";
}
// The shortcut may have been changed in chrome://extensions/shortcuts meanwhile.
window.addEventListener("focus", showShortcut);
// Live status from the ChatGPT page while it is answering (every second), with the
// time since the prompt was sent, so a long wait never looks like a stop.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== "cgpt:progress" || !gptTabBusy || !gptStep) return;
  if (sender && sender.tab && sender.tab.id !== gptTabBusy) return;
  setStatus(`${gptStep.label}: ${msg.text} (${Math.round((Date.now() - gptStep.at) / 1000)} s)`);
  if (msg.diag) log(AI() + " page details:\n" + msg.diag, "warn");
});
$("copyLog").addEventListener("click", async () => {
  const lines = [...$("log").children].reverse().map((li) => li.textContent);
  await navigator.clipboard.writeText(lines.join("\n"));
  $("copyLog").textContent = "Copied";
  setTimeout(() => { $("copyLog").textContent = "Copy log"; }, 1500);
});

// ---------- tab helpers ----------

function checkStop() { if (stopRequested) throw new Error("Stopped"); }

// Pings the tab's content script, injecting it first if needed (or replacing a copy
// with another build, left from before an update). If the page still holds an old
// copy that cannot be replaced, the tab is reloaded once. The reply says whether the
// page is visible (in split view both panes are).
async function ping(tab, file, type) {
  const prefix = type.split(":")[0];
  const hello = async () => { const r = await quick(chrome.tabs.sendMessage(tab.id, { type }), 5000); return r && r.ok ? r : null; };
  const current = (r) => r && r.build === SCRIPT_BUILD;
  let r = await hello();
  if (current(r)) return r;
  await load(tab.id, file, prefix, r);
  if (current(r = await hello())) return r;
  // Reloading our own tab would end this run (the panel lives on that page).
  if (tab.id === myTabId) throw new Error("Reload this Freelancer page (F5), then press Start again.");
  log("Reloading the tab \"" + tab.title + "\" to load the updated extension", "warn");
  await chrome.tabs.reload(tab.id);
  await sleep(1000);
  await waitTabLoaded(tab.id);
  await load(tab.id, file, prefix, null);
  if (current(r = await hello())) return r;
  throw new Error("Could not connect to the tab \"" + tab.title + "\". Reload it and press Start again.");
}

// One step in a tab's content script. Each step has a time limit, so a page that
// never answers cannot leave the run hanging, and Stop ends the wait at once
// (unless stoppable is false: Post and Place Bid report what really happened).
async function call(tabId, msg, ms, stoppable = true) {
  let timer;
  const late = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`The page did not finish "${msg.type}" in ${Math.round(ms / 1000)} s. Reload the tab and try again.`)), ms);
  });
  try {
    const r = await Promise.race([chrome.tabs.sendMessage(tabId, msg), late, stoppable && stopper ? stopper.promise : late]);
    if (!r) throw new Error("No answer from the page. Reload the tab and try again.");
    if (!r.ok) {
      if (r.diag) log("Page details:\n" + r.diag, "warn");
      // page: the page's own error (it answered); deleted: a new ChatGPT chat failed after
      // the old chat was deleted.
      throw Object.assign(new Error(r.error || "Step failed"), { page: true }, r.deleted ? { deleted: true } : {});
    }
    return r;
  } finally {
    clearTimeout(timer);
  }
}
function newStopper() {
  let reject;
  const promise = new Promise((_, r) => { reject = r; });
  promise.catch(() => {});
  return { promise, reject };
}

async function focusTab(tab) {
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

async function waitTabLoaded(tabId) {
  for (const t0 = Date.now(); Date.now() - t0 < 30000; await sleep(300)) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === "complete") return t;
  }
  throw new Error("The tab did not finish loading");
}

// The Freelancer tab is the one this box is on. The chat of the chosen AI (ChatGPT or
// DeepSeek): with Chrome split view the two panes share a splitViewId, and that pane is
// used even as a new, empty chat (no chat address yet); otherwise the most recently
// used chat of that site in this window wins. Chats in other windows are the last resort.
async function findTabs() {
  if (myTabId == null) throw new Error("Reload this Freelancer page (F5), then press Start again.");
  const fl = await chrome.tabs.get(myTabId);
  if (!FL_PROJECT.test(fl.url || "")) throw new Error("Open a Freelancer project page in this tab, then press Start");
  const win = await chrome.tabs.query({ windowId: fl.windowId });
  const none = chrome.tabs.SPLIT_VIEW_ID_NONE !== undefined ? chrome.tabs.SPLIT_VIEW_ID_NONE : -1;
  const split = fl.splitViewId != null && fl.splitViewId !== none
    ? win.filter((t) => t.splitViewId === fl.splitViewId && t.id !== fl.id) : [];
  const recent = (list) => [...list].sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));

  const site = ai();
  const all = await chrome.tabs.query({ url: site.tabs });
  const gpt = split.find((t) => site.page.test(t.url || "")) ||
    [...recent(win), ...recent(all)].find((t) => t && site.chat.test(t.url || ""));
  if (!gpt) throw new Error("Open your " + AI() + " bid chat next to the Freelancer page, then press Start (Settings > AI chat: " + AI() + ")");
  return { fl, gpt };
}

// ---------- ChatGPT prompt and reply ----------

// Literal markers would look like an answer on the page: in the user's own
// instructions and in the project text (a client could write anything there).
const noMarkers = (s) => s.replace(/\[\[\s*(PROPOSAL|QUESTIONS|END)\s*\]\]/gi, "$1 marker");

// The project's name from its address ("wordpress-college-site"), not the link itself:
// ChatGPT would search the web for a link before answering.
const projectSlug = (url) => (url || "").replace(/[?#].*$/, "").replace(/\/details\/?$/, "").split("/").filter(Boolean).pop() || "";
// post: see answerFormat; none when the box posts no clarification question.
const defaultPost = () => (settings.clarify ? "with" : "none");
function buildPrompt(projectText, url, ref, minChars, post = defaultPost()) {
  const tpl = noMarkers(settings.prompt || DEFAULT_PROMPT);
  const project = noMarkers(projectText);
  // A function, so "$&" or "$'" in the project text is not read as a replace pattern.
  const body = tpl.includes("{{PROJECT}}") ? tpl.replace("{{PROJECT}}", () => project) : tpl + "\n\n" + project;
  // The first line carries a unique ref so the panel can find this exact message
  // in the chat even if ChatGPT collapses a long prompt.
  return `Freelancer project ${projectSlug(url)} (ref:${ref})\n\n${body}\n\n${answerFormat(minChars || MIN_PROPOSAL, post)}`;
}
// Follow-up in the same chat when the proposal is over Freelancer's limit: the proposal
// only (the clarification post of the first answer is kept).
function buildShorten(url, ref, length, minChars) {
  return `Freelancer project ${projectSlug(url)} (ref:${ref})\n\n` +
    `Your proposal above is ${length} characters, but Freelancer accepts at most ${MAX_PROPOSAL}. ` +
    `Please shorten it to under 1300 characters: the same message and tone, just shorter.\n\n` +
    answerFormat(minChars || MIN_PROPOSAL, "none");
}

// Follow-up in the same chat when the answer has no clarification board post although one
// was asked for (ChatGPT wrote "none", or nothing after its QUESTIONS line): the post only.
function buildQuestionOnly(url, ref) {
  return `Freelancer project ${projectSlug(url)} (ref:${ref})\n\n` +
    "Your answer above has no clarification board post. Now write only the clarification board post for this project: " +
    "real questions about the client's requirements, at most 3, no greeting, no self-promotion, no links or contact details.\n\n" +
    `${FORMAT_HEAD}\nUse three marker lines, each one word inside double square brackets: PROPOSAL on the first line followed by a line with only the word none, ` +
    `QUESTIONS on the line before the clarification board post, and END on the last line.\n${PROMPT_END}`;
}

// partial: the answer was taken at its QUESTIONS line (the proposal is complete, the
// clarification post still being written), so only the proposal is read from it.
// A post of just "none" is no post.
function parseReply(text, partial = false) {
  const starts = [...text.matchAll(/\[\[\s*PROPOSAL\s*\]\]/gi)];
  if (!starts.length) throw new Error(AI() + " did not answer in the [[PROPOSAL]] format. Its reply starts: " + text.slice(0, 160));
  const s = starts[starts.length - 1];
  const body = text.slice(s.index + s[0].length);
  const qm = body.match(/\[\[\s*QUESTIONS\s*\]\]/i);
  const em = body.match(/\[\[\s*END\s*\]\]/i);
  const qi = qm ? qm.index : -1;
  const ei = em ? em.index : -1;
  // A half answer is never used: it once put ChatGPT's own screen text into a bid.
  if (ei < 0 && !(partial && qi >= 0)) throw new Error(AI() + "'s answer has no [[END]] line (it was cut short), so it was not used. Press Start to try again.");
  const proposal = body.slice(0, qi >= 0 && (ei < 0 || qi < ei) ? qi : ei).trim();
  const post = qi >= 0 && qi < ei ? body.slice(qi + qm[0].length, ei).trim() : "";
  const questions = /^none\.?$/i.test(post) ? "" : post;
  const junk = (proposal + "\n" + questions).match(CHATGPT_SCREEN_TEXT);
  if (junk) throw new Error("The answer contains " + AI() + "'s screen text (\"" + junk[0].trim() + "\"), so it was not used. Press Start to try again.");
  return { proposal, questions };
}
const CHATGPT_SCREEN_TEXT = /you['’]re using the free version of chatgpt|chatgpt can make mistakes|ai-generated, for reference only|^\s*(latest response|response complete|try plus free)\s*$/im;
// Freelancer refuses a proposal with an email address in it.
const EMAIL = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i;

// What Freelancer would refuse in the proposal, before anything is filled.
function checkBid(bid, minChars) {
  const n = bid.proposal.length;
  if (n < minChars) throw new Error(`${AI()}'s proposal is ${n} characters; Freelancer needs at least ${minChars}. Nothing was filled.`);
  if (n > MAX_PROPOSAL) throw new Error(`${AI()}'s proposal is ${n} characters; Freelancer accepts at most ${MAX_PROPOSAL}. Nothing was filled.`);
  if (EMAIL.test(bid.proposal)) throw new Error(AI() + "'s proposal contains an email address, which Freelancer does not accept. Nothing was filled.");
}

// The content script gives up after 6 minutes; this limit only catches a page that never answers.
const GPT_LIMIT = 400000;
// label: the status line's step while ChatGPT writes. until "questions": the answer
// comes back as soon as its proposal is written (reply.partial, see restOfAnswer).
async function askChatGPT(gptTab, prompt, marker, label, until = "") {
  gptTabBusy = gptTab.id;
  gptStep = label ? { label, at: Date.now() } : null;
  try {
    return await call(gptTab.id, { type: "cgpt:ask", prompt, marker, promptEnd: PROMPT_END, until, from: myTabId }, GPT_LIMIT);
  } catch (e) {
    // The ChatGPT page reloaded after the prompt went out: pick the answer up there.
    if (!/message channel closed|message port closed/i.test(e.message || "")) throw e;
    log(AI() + " page reloaded, waiting for the answer there", "warn");
    await sleep(1500);
    checkStop();
    await waitTabLoaded(gptTab.id);
    await ping(gptTab, "content/chatgpt.js", "cgpt:ping");
    return await call(gptTab.id, { type: "cgpt:wait", marker, promptEnd: PROMPT_END, until, from: myTabId }, GPT_LIMIT);
  } finally {
    gptTabBusy = null;
    gptStep = null;
  }
}
// The whole answer of a prompt whose proposal came back early: ChatGPT goes on with the
// clarification post in that same answer, which is read on in the chat (no new message).
async function restOfAnswer(gptTab, marker) {
  gptTabBusy = gptTab.id;
  try {
    return await call(gptTab.id, { type: "cgpt:wait", marker, promptEnd: PROMPT_END, from: myTabId }, GPT_LIMIT);
  } finally {
    gptTabBusy = null;
  }
}

// The clarification post ChatGPT left out, asked for once in the same chat ("" if it still
// writes none or its answer cannot be read). A ChatGPT tab that is not on screen is
// brought to the front for it (a tab in the background may not show what ChatGPT
// writes) and the Freelancer tab back after.
async function askQuestion(gptTab, flTab, onScreen, url, label) {
  log(`${AI()}'s answer has no clarification question: asking ${AI()} for it`, "warn");
  if (!onScreen) await focusTab(gptTab);
  try {
    const ref = Date.now().toString(36);
    const r = await askChatGPT(gptTab, buildQuestionOnly(url, ref), "ref:" + ref, label);
    return parseReply(r.text).questions;
  } catch (e) {
    if (e.message === "Stopped") throw e;
    log(`${AI()} did not write the clarification question: ` + e.message, "warn");
    return "";
  } finally {
    if (!onScreen) { try { await focusTab(flTab); } catch (err) {} }
  }
}

// A step in the ChatGPT page that may take as long as an answer (Stop ends it).
async function chatCall(gptTab, msg, label) {
  gptTabBusy = gptTab.id;
  gptStep = { label, at: Date.now() };
  try {
    return await call(gptTab.id, Object.assign({ from: myTabId }, msg), GPT_LIMIT);
  } finally {
    gptTabBusy = null;
    gptStep = null;
  }
}
// Deletes the bid chat at path (the chat the last bid went to; it must hold the box's
// bid prompts), opens a new chat in the same place (its ChatGPT project or GPT, else the
// site's home) and sends your first message there. If the page has no link to the new
// chat, the tab loads its address. An error with deleted set: the old chat is gone but
// the new one did not get the first message.
async function renewChat(gptTab, path, label) {
  const r = await chatCall(gptTab, { type: "cgpt:newChat", path, atLeast: 1, prompt: settings.firstPrompt }, label);
  // ChatGPT's menu did not work, its delete request did: say why, for a fix.
  if (r.via === "request") {
    log(`${AI()}'s chat menu did not work (${r.menuError}); the old chat was deleted with ${AI()}'s own delete request instead`, "warn");
    if (r.diag) log("Page details:\n" + r.diag, "warn");
  }
  if (!r.load) return r;
  try {
    await chrome.tabs.update(gptTab.id, { url: ai().origin + r.load });
    await sleep(1000);
    await waitTabLoaded(gptTab.id);
    await ping(gptTab, "content/chatgpt.js", "cgpt:ping");
    return await chatCall(gptTab, { type: "cgpt:first", prompt: settings.firstPrompt }, label);
  } catch (e) {
    throw Object.assign(e, { deleted: true });
  }
}
// The box's own count of bids per chat (by its address), kept with the count read on the
// page: a page that does not show a long chat's older messages cannot hide bids. The
// last 30 chats are kept.
async function chatCounts() {
  return (await chrome.storage.local.get({ chatCounts: {} })).chatCounts || {};
}
async function countBid(path) {
  const all = await chatCounts();
  const n = (all[path] || 0) + 1;
  delete all[path];
  all[path] = n;
  const keys = Object.keys(all);
  for (const k of keys.slice(0, Math.max(0, keys.length - 30))) delete all[k];
  await chrome.storage.local.set({ chatCounts: all });
  return n;
}
// After a bid that made it settings.newChatAfter bids in the chat: a new chat for the next
// bids. The bid is done whatever happens here, so a problem is a warning.
async function newChatAfterBid(gptTab, flTab, path, count, onScreen) {
  const was = $("status").textContent;
  log(`${count} bids in this ${AI()} chat (new chat every ${settings.newChatAfter}): deleting it and starting a new chat`);
  setStatus(was + " Starting a new " + AI() + " chat...");
  let away = false;
  try {
    // A ChatGPT tab in the background may not draw its menus: brought to the front.
    if (!onScreen) { await focusTab(gptTab); away = true; }
    const r = await renewChat(gptTab, path, "New " + AI() + " chat");
    log(`New ${AI()} chat ready (the old one deleted): ${AI()} answered your first message in ${secs(r.ms)} s`, "ok");
    setStatus(was + " New " + AI() + " chat ready.");
  } catch (e) {
    const msg = e && e.message ? e.message : String(e);
    log("No new " + AI() + " chat: " + msg + (e.deleted ? ". The old chat is deleted; if the new chat is still empty, Start sends your first message there first." : ". The next bid goes to the same chat."), "warn");
    setStatus(msg === "Stopped" ? was + " New " + AI() + " chat stopped." : `${was} New ${AI()} chat not made: ${msg}`);
  } finally {
    if (away) { try { await focusTab(flTab); } catch (err) {} }
  }
}

// Under the status: where the last bid's ChatGPT time went.
function showTiming(reply) {
  const el = $("timing");
  // send = typing + sending, think = until its first words, write = the rest.
  const total = reply.typedMs + reply.sentMs + reply.answerMs;
  const parts = reply.firstMs != null
    ? `send ${secs(reply.typedMs + reply.sentMs)} + think ${secs(reply.firstMs)} + write ${secs(reply.answerMs - reply.firstMs)}`
    : `send ${secs(reply.typedMs + reply.sentMs)} + answer ${secs(reply.answerMs)}`;
  el.textContent = `${AI()} ${secs(total)} s = ${parts}` + (reply.skipped ? " (thinking skipped)" : "") + (reply.model ? ` · ${reply.model}` : "") +
    (newChatOn() ? ` · bid ${(reply.chatBids || 0) + 1} of ${settings.newChatAfter} in this chat` :
      reply.chatBids ? ` · ${reply.chatBids} earlier bid${reply.chatBids === 1 ? "" : "s"} in this chat` : "");
  el.title = "Last bid: how long " + AI() + " took to take the prompt (send), before it started writing (think) and to write the answer (write).";
  el.className = reply.firstMs > 8000 ? "warn" : "";
  el.hidden = false;
}

// ---------- what became of the clarification question ----------
// Each gives the end of the last status ("Done. Bid placed" + it, see doneText) and logs it.

// Why fl:clarifyFill found no box to type the question into (the board as the page
// showed it goes to the log, for a fix).
function boardWhy(f) {
  if (f.diag) log("Board details:\n" + f.diag, "warn");
  if (f.locked) return "Freelancer lets only users Verified by Freelancer post on its clarification board";
  if (f.qa) return f.panel ? "Freelancer's Q&A panel (its clarification board) shows no question box" : "Freelancer's Q&A panel (its clarification board) did not open";
  return "no clarification board on this page";
}
function notPosted(why) {
  why = String(why).replace(/[.\s]+$/, "");
  log("The clarification question was not posted: " + why, "warn");
  return "; the clarification question was not posted: " + why + ".";
}
// Clarification question on, but the answer had none (ChatGPT wrote "none" or nothing).
function noQuestion() {
  log(AI() + " wrote no clarification question (its answer has nothing after the QUESTIONS line); nothing posted", "warn");
  return "; " + AI() + " wrote no clarification question.";
}
// p: the fl:clarifyPost reply.
// Posted means the question shows on the board under your name (other bidders often post
// nearly the same question, so theirs never count).
function postedText(p, startedAt) {
  const who = p.who ? " under @" + p.who : "";
  if (p.already) {
    log("Your clarification question is already on the board" + who + " (you posted it): not posted again", "ok");
    return ", your clarification question is already on the board.";
  }
  if (p.retyped) log("The board's box was empty or gone before Post (Freelancer emptied it, or its Q&A panel was closed): typed the question again", "warn");
  if (p.diag && !p.shown) log("Board details:\n" + p.diag, "warn");
  if (p.resent && p.shown) log("Freelancer's form started over after the first Post (nothing was sent): typed the question again and posted it", "warn");
  if (!p.shown && p.reset) {
    return notPosted("Freelancer's form started over before the question was sent (its page updated)" + (p.resent ? ", also after one more try" : ""));
  }
  if (!p.shown && !p.confirmed) {
    log("Clicked Post, but the box did not clear (Freelancer did not take the question). " + (p.errors || []).join(" | "), "warn");
    return ". Clicked Post, but Freelancer did not take the clarification question: check the board.";
  }
  if (!p.shown) {
    log("Clicked Post and Freelancer sent the question, but it does not show on the board" + (who || " (who you are is not known on this page)") + ": check it on the page", "warn");
    return ". Clicked Post, but the clarification question does not show on the board: check it.";
  }
  log(`Clarification question posted${who}, ${secs(Date.now() - startedAt)} s after Start` + (p.qa ? " (Freelancer's Q&A panel)" : ""), "ok");
  if (p.qa && p.closed === false) log("Freelancer's Q&A panel did not close after the post: close it yourself", "warn");
  return ", clarification question posted.";
}
const doneText = (end) => "Done. Bid placed" + (end || ".");

// Types the clarification question into the board's box and posts it. later: when it is
// tried again if nothing could be sent now ("Continue", "after the bid"; "" = last try).
// { state, end, note }: state "done" (posted, already up, or not possible: the board takes
// none from you, or Post was clicked and the question does not show, never sent twice) or
// "retry" (it could not be typed, or the page stopped before Post: nothing was sent);
// end: the end of the last status (see doneText); note: the same, for the pause.
async function postQuestion(flTab, text, startedAt, label, later) {
  const done = (end) => ({ state: "done", end, note: " " + end.replace(/^[,;.]\s*/, "").replace(/^./, (c) => c.toUpperCase()) });
  const failed = (why) => {
    why = String(why).replace(/[.\s]+$/, "");
    if (!later) return done(notPosted(why));
    log("Could not post the clarification question yet: " + why + (later === "Continue" ? ". Continue tries again." : ". It is tried again " + later + "."), "warn");
    return { state: "retry", end: "; the clarification question was not posted: " + why + ".", note: " The question could not be posted yet (" + why + "): " + later + " tries again." };
  };
  setStatus(label + "Posting the clarification question...");
  let f;
  try {
    f = await call(flTab.id, { type: "fl:clarifyFill", text }, 30000);
  } catch (e) {
    if (e.message === "Stopped") throw e;
    return failed(e.message);
  }
  // No board on the page at all (qa not set) or not Verified: nothing to try again.
  if (!f.found) return f.locked || f.qa === undefined ? done(notPosted(boardWhy(f))) : failed(boardWhy(f));
  if (f.already) return done(postedText(f));
  if (f.tries > 1) log(`Freelancer emptied the board's box after the question was typed; typed it again (${f.tries} tries)`, "warn");
  checkStop();
  try {
    // retype: a box Freelancer emptied (or a Q&A panel that closed) gets it typed again.
    return done(postedText(await call(flTab.id, { type: "fl:clarifyPost", text, retype: text }, 60000, false), startedAt));
  } catch (e) {
    // The page's own errors come before its Post button is clicked (nothing was sent).
    return e.page ? failed(e.message) : done(notPosted(e.message));
  }
}

// Review off: how long Place Bid waits past its time for a clarification question ChatGPT
// is still writing (so it goes up before the bid rather than about 7 s after it).
const QUESTION_GRACE = 3000;

// Waits until time at: Place Bid is clicked no earlier than its seconds after Start (a run
// that already took longer goes ahead at once). Stop works while waiting. until: a promise
// that ends the wait early (the clarification question ChatGPT is writing): false then.
async function waitForBidTime(at, until = null) {
  let cut = false;
  const early = until ? until.then(() => { cut = true; }, () => { cut = true; }) : null;
  while (Date.now() < at) {
    checkStop();
    if (cut) return false;
    setStatus(`7/7 Placing the bid in ${Math.ceil((at - Date.now()) / 1000)} s...`);
    const nap = sleep(Math.min(250, at - Date.now()));
    await (early ? Promise.race([nap, early]) : nap);
  }
  checkStop();
  return true;
}

// The project's page without "/details" or a query: the bid must go to the project read.
const projectPage = (u) => (u || "").replace(/[?#].*$/, "").replace(/\/(details\/?)?$/, "");

// The project's Non-Disclosure Agreement in a new tab, to sign: the address of
// Freelancer's own link on the page (opened by the box: a script click on the page's
// new-tab link can be stopped by Chrome's pop-up blocker).
async function openNda(flTab, ex) {
  const url = ex.nda.href || (ex.projectId ? `https://www.freelancer.com/ajax/project/contract/initialize-nda-contract.php?project_id=${ex.projectId}&type=nda` : "");
  if (url) await chrome.tabs.create({ url, windowId: flTab.windowId, openerTabId: flTab.id, active: true });
  else await call(flTab.id, { type: "fl:openNda" }, 5000);
  log("This project needs its NDA signed before a bid: opened Freelancer's Non-Disclosure Agreement in a new tab", "warn");
}

// Paused (review on, or an NDA to sign): Continue goes on with Post and Place Bid, Stop
// ends the run, and a bid you place yourself on the page ends the wait too. Returns
// { byHand, boardText, boardValue } (byHand: you placed the bid; boardText: the
// clarification box still holds text; boardValue: the last text seen in that box while
// paused, so a question you changed is the one posted after your own Place Bid).
async function pause(flTab, text) {
  setStatus(text);
  $("continue").hidden = false;
  let over = false, goneSince = 0, boardValue = "";
  const pressed = new Promise((resolve, reject) => { continueWait = { resolve, reject }; }).then(() => ({ byHand: false }));
  const never = new Promise(() => {});
  const own = (async () => {
    for (;;) {
      await sleep(1000);
      if (over) return never;
      const r = await quick(chrome.tabs.sendMessage(flTab.id, { type: "fl:ownBid" }), 3000);
      if (over) return never;
      if (!r || !r.ok) continue;
      if (projectPage(r.url) !== projectPage(flTab.url)) throw new Error("The Freelancer tab moved to another page");
      if (r.boardValue) boardValue = r.boardValue;
      // Freelancer closes the bid form once the bid is in (your card may be further down).
      goneSince = r.formGone ? goneSince || Date.now() : 0;
      if (r.placed || (goneSince && Date.now() - goneSince >= 3000)) return { byHand: true, boardText: r.boardText, boardValue };
      setStatus(r.failed ? `${text} Freelancer said: ${r.failed}` : text);
    }
  })();
  try {
    return await Promise.race([pressed, own]);
  } finally {
    over = true;
    continueWait = null;
    $("continue").hidden = true;
  }
}

// ---------- the run ----------

// Auto bid's own check of a project: why it leaves it alone ({ text, fatal }), or null
// when it is a real new project you can bid on that fits your skills; from there the bid
// is the same as with Start (see run). fatal: no project can be bid on now (no bids
// left), so auto bid stops. An NDA to sign is not a reason: Start handles it (opens the
// NDA and waits for you), and so does auto bid.
function autoSkip(ex) {
  if (ex.blocker) return { text: ex.blocker.kind === "already" ? "you already bid on it" : noticeText(ex.blocker).replace(/[.\s]+$/, ""), fatal: ex.blocker.kind === "nobids" };
  if (!ex.hasProposal && !ex.nda) return { text: "no bid form (you bid on it already, or bidding is closed)" };
  const fit = skillFit(ex.skills);
  if (!fit.total) return { text: "no skill tags found on the project" };
  log(`Auto: ${fit.matched.length} of ${fit.total} of its skills are yours (${fit.pct} %, at least ${settings.skillMatch} % needed)` +
    (fit.matched.length ? ": " + fit.matched.join(", ") : "") + (fit.missing.length ? "; not yours: " + fit.missing.join(", ") : ""), fit.ok ? "ok" : "");
  if (!fit.ok) return { text: `${fit.pct} % of its skills are yours, ${settings.skillMatch} % needed` };
  return null;
}
// Errors after which auto bid stops (nothing else would work either).
const AUTO_FATAL = /open your (chatgpt|deepseek) bid chat|could not connect to the tab|reload this freelancer page|used all of your bids|no bids left/i;

// pick: { sponsored, highlight } from a start button, in place of the Settings checkboxes.
// opts.auto: a bid that auto bid started: a project you already bid on, or whose skills
// are not yours enough, is skipped (autoSkip); everything after that is exactly what
// Start does, Settings included ("Pause for review" on: it waits for your Continue).
// Returns { placed, skipped, error, stopped, fatal, title }.
async function run(pick = null, opts = {}) {
  const startedAt = Date.now();
  const autoRun = !!opts.auto;
  const review = settings.review;
  const outcome = { placed: false, skipped: "", error: "", stopped: false, fatal: false, title: "" };
  stopRequested = false;
  stopper = newStopper();
  setRunning(true);
  log("-- Start (v" + VERSION + ")" + (autoRun ? ", auto bid" : "") + (pick ? ", " + upgradeNames(pick) : "") + " --", "sep");
  let flTab = null, gptTab = null;
  let switched = false;
  // One message to ChatGPT per bid: the proposal and the clarification post come in one
  // answer. The post goes up as soon as it is written. With review off the proposal is
  // taken as soon as ChatGPT has written it and the bid is filled while the same answer
  // goes on with the post; the post goes up the moment it is there (also during the wait
  // for the Place Bid time), or right after the bid if the bid comes first. With review on
  // the whole answer comes first, and the post goes up before the pause.
  const postEarly = settings.clarify && !review;
  let rest = null, restDone = false;   // the rest of that answer (the post), still being written
  // Review off: the clarification question while ChatGPT still writes it (the rest of the
  // answer, or one follow-up when it has none): "" for none.
  let qWait = null, qWaitDone = false;
  let ended = false;   // the run is over (no follow-up question is asked after that)
  // The box's bid prompts in the ChatGPT chat after this bid, and the chat's address.
  let chatCount = 0, chatPath = "", gptOnScreen = true;
  let chatNote = "";   // a new chat that did not work out before the bid, for the last status
  try {
    const tabs = await findTabs();
    flTab = tabs.fl;
    gptTab = tabs.gpt;
    log("Freelancer: " + flTab.title);
    log(AI() + ": " + gptTab.title + " (" + gptTab.url + ")");
    // Your own Start while Auto is on: auto bid leaves this project alone afterwards.
    if (autoOn && !autoRun) { markSeen(pathOf(flTab.url)); autoVisit.done = pathOf(flTab.url); }

    // 1) project details
    setStatus("1/7 Reading the project...");
    const flPing = await ping(flTab, "content/freelancer.js", "fl:ping");
    if (!flPing.visible) await focusTab(flTab);
    const ex = (await call(flTab.id, { type: "fl:extract" }, 30000)).data;
    log(`Read the project in ${secs(Date.now() - startedAt)} s`);
    // Freelancer leaves its bid form out when you may not bid: a "you cannot bid" text
    // next to a form you can use is not this project's (see blocker() in freelancer.js).
    if (ex.blocker && ex.blocker.formShown) {
      log(`The page shows "${ex.blocker.message}", but Freelancer's bid form is there to use: going on (Freelancer refuses the bid if it really cannot be placed)`, "warn");
      ex.blocker = null;
    }
    showCheck({ bids: ex.bids, blocker: ex.blocker, url: ex.url, nda: !!ex.nda, page: "project" });
    outcome.title = ex.title;
    if (autoRun) {
      const skip = autoSkip(ex);
      if (skip) {
        outcome.skipped = skip.text;
        outcome.fatal = !!skip.fatal;
        log(`Auto: skipped "${ex.title}": ${skip.text}`, "warn");
        setStatus(`Auto: skipped "${ex.title}" (${skip.text}).`);
        return outcome;
      }
    }
    if (ex.blocker) throw new Error(noticeText(ex.blocker));
    if (!ex.hasProposal) {
      if (ex.nda) {
        await openNda(flTab, ex);
        throw Object.assign(new Error("Sign the NDA in the new tab. This page shows no bid form before that: then reload it and press Start."), { plain: true });
      }
      if (ex.idRequired) throw new Error("Verify your ID on this project first");
      showNotice({ kind: "noform", message: NO_FORM_TEXT });
      throw new Error(NO_FORM_TEXT);
    }
    const minChars = ex.minChars || MIN_PROPOSAL;
    const budget = flParseBudget(ex.budget);
    const type = ex.formType || (budget.hourly ? "hourly" : "fixed");
    const plan = flPlanBid(budget, type, rules());
    if (plan.error) throw new Error(plan.error + ". Budget text: " + (ex.budget || "not found"));
    plan.summary = type === "hourly"
      ? `${plan.price} ${plan.currency}/hour, ${plan.period} hrs/week${plan.note}`
      : `${plan.price} ${plan.currency}, ${plan.period} days${plan.note}`;
    log(`${ex.title} | ${ex.budget} | ${type}`);
    log("Bid: " + plan.summary);
    checkStop();

    // 2) proposal and clarification post from ChatGPT, in the chat that is open
    setStatus("2/7 Connecting to " + AI() + "...");
    const gptPing = await ping(gptTab, "content/chatgpt.js", "cgpt:ping");
    gptOnScreen = gptPing.visible;
    if (!gptPing.visible) { await focusTab(gptTab); switched = true; }
    // New chat every newChatAfter bids (made after the bid that fills a chat, see the end):
    // a new, empty chat gets your first message before the bid, and a full chat that was
    // not renewed after its last bid is renewed now.
    if (newChatOn()) {
      const st = await chatCall(gptTab, { type: "cgpt:state" }, "2/7 " + AI());
      if (!st.chat) {
        log("The " + AI() + " pane is a new, empty chat: sending your first message there before the bid");
        const f = await chatCall(gptTab, { type: "cgpt:first", prompt: settings.firstPrompt }, "2/7 New " + AI() + " chat");
        log(`${AI()} answered your first message in ${secs(f.ms)} s`, "ok");
      } else {
        const bids = Math.max(st.bids, (await chatCounts())[st.path] || 0);
        if (bids >= settings.newChatAfter) {
          log(`This ${AI()} chat already holds ${bids} bids (new chat every ${settings.newChatAfter}): a new chat before this bid`, "warn");
          try {
            const f = await renewChat(gptTab, st.path, "2/7 New " + AI() + " chat");
            log(`New ${AI()} chat ready (the old one deleted): ${AI()} answered your first message in ${secs(f.ms)} s`, "ok");
          } catch (e) {
            // Not deleted: the bid goes to the same chat. Deleted: the new chat may not have
            // your first message, so nothing is sent there.
            if (e.message === "Stopped" || e.deleted) throw e.deleted ? new Error("The old " + AI() + " chat is deleted, but the new chat is not ready: " + e.message + ". Nothing was filled; press Start again.") : e;
            log("No new " + AI() + " chat: " + e.message + ". This bid goes to the same chat.", "warn");
            chatNote = ` (New ${AI()} chat not made: ${e.message})`;
          }
        }
      }
      checkStop();
    }
    let ref = Date.now().toString(36);
    const marker = "ref:" + ref;
    // The proposal early only while the ChatGPT pane is on screen. A ChatGPT tab brought
    // to the front for this bid gives its whole answer first, so the box goes there and
    // back once (a tab in the background may not show what ChatGPT writes).
    const early = postEarly && gptPing.visible;
    const askedAt = Date.now();
    log(`Prompt ready ${secs(askedAt - startedAt)} s after Start`);
    const reply = await askChatGPT(gptTab, buildPrompt(ex.text, ex.url, ref, minChars), marker, "2/7 " + AI(), early ? "questions" : "");
    // Bids in this chat, this one included: the page's count, or the box's own if higher.
    chatPath = reply.path || "";
    chatCount = (reply.chatBids || 0) + 1;
    if (newChatOn() && chatPath) chatCount = Math.max(chatCount, await countBid(chatPath));
    reply.chatBids = chatCount - 1;
    if (reply.typedMs != null) {
      const writing = reply.firstMs != null
        ? `started writing ${secs(reply.firstMs)} s after sending, done ${secs(reply.answerMs - reply.firstMs)} s later`
        : `answer in ${secs(reply.answerMs)} s`;
      log(`${AI()}: prompt typed in ${secs(reply.typedMs)} s, sent in ${secs(reply.sentMs)} s (${reply.sentBy}), ${writing}` +
        (reply.via ? `, read from the ${reply.via}` : "") + (reply.model ? `, model "${reply.model}"` : "") + (reply.skipped ? ", its thinking skipped" : ""));
      showTiming(reply);
      // The rest of the time is ChatGPT's own; say what makes it faster.
      if (reply.firstMs > 8000) log(`${AI()} needed ${secs(reply.firstMs)} s before writing. ` + (settings.ai === "deepseek" ? "With DeepThink off, DeepSeek starts sooner." : "A ChatGPT model without \"Thinking\" starts sooner."), "warn");
    }
    checkStop();
    let bid = parseReply(reply.text, reply.partial);
    if (reply.partial) {
      rest = restOfAnswer(gptTab, marker);
      rest.then(() => { restDone = true; }, () => { restDone = true; });
    }
    // Over Freelancer's limit: ChatGPT shortens it once, in the same chat. The first
    // answer is finished before that message, and its post is kept.
    if (bid.proposal.length > MAX_PROPOSAL) {
      log(`The proposal is ${bid.proposal.length} characters, Freelancer accepts at most ${MAX_PROPOSAL}: asking ${AI()} to shorten it`, "warn");
      let questions = bid.questions;
      // A post that could not be read is no post (the bid goes on without it).
      if (rest) { questions = await rest.then((r) => { try { return parseReply(r.text).questions; } catch (e) { return ""; } }, () => ""); rest = null; }
      checkStop();
      ref = Date.now().toString(36);
      const shorter = await askChatGPT(gptTab, buildShorten(ex.url, ref, bid.proposal.length, minChars), "ref:" + ref, "2/7 " + AI() + " (shortening)");
      chatCount++;
      chatPath = shorter.path || chatPath;
      checkStop();
      bid = parseReply(shorter.text);
      bid.questions = questions || bid.questions;
    }
    // Clarification question on, but the answer has none: asked for once in the same chat.
    // Now when the ChatGPT tab is in front for this bid anyway (review on, or a ChatGPT tab
    // brought to the front); review off with its pane on screen: while the bid goes on (qWait).
    let asked = false;
    if (settings.clarify && !rest && !bid.questions && (review || switched)) {
      bid.questions = await askQuestion(gptTab, flTab, true, ex.url, "2/7 " + AI() + " (clarification question)");
      chatCount++;
      asked = true;
      checkStop();
    }
    if (switched) { await focusTab(flTab); switched = false; }
    checkBid(bid, minChars);
    if (!settings.clarify) bid.questions = "";
    if (postEarly && (rest || (!bid.questions && !asked))) {
      // The rest of the answer (a part that cannot be read is no question), then one
      // follow-up if it has none.
      const fromRest = !rest ? Promise.resolve("") : rest.then((r) => {
        try { return parseReply(r.text).questions; }
        catch (e) {
          // The advice in these messages is for a bid that was not filled; this one is.
          log("The clarification part of " + AI() + "'s answer could not be used: " + e.message.replace(/\s*(nothing was filled|press start)[\s\S]*$/i, ""), "warn");
          return "";
        }
      }, (e) => {
        if (e.message === "Stopped") throw e;
        log("The clarification part of " + AI() + "'s answer could not be used: " + e.message.replace(/\s*(nothing was filled|press start)[\s\S]*$/i, ""), "warn");
        return "";
      });
      qWait = fromRest.then((t) => (t || stopRequested || ended ? t :
        askQuestion(gptTab, flTab, true, ex.url, "").then((q) => { chatCount++; return q; })));
      qWait.then(() => { qWaitDone = true; }, () => { qWaitDone = true; });
    }
    showLast(plan, bid);
    log(`Proposal: ${bid.proposal.length} chars` + (bid.questions ? ", 1 clarification post" :
      qWait ? ", " + AI() + (rest ? " goes on with the clarification post" : " writes the clarification post") + " (posted as soon as it is written)" : "") +
      `, ${AI()} took ${secs(Date.now() - askedAt)} s`);

    // The bid must go to the project we read ("/details" is the same page).
    if (projectPage((await chrome.tabs.get(flTab.id)).url) !== projectPage(flTab.url)) throw new Error("The Freelancer tab moved to another page");

    // 3+4) proposal, price, timeline
    setStatus("3-4/7 Filling the bid form...");
    const fillAt = Date.now();
    const filled = await call(flTab.id, { type: "fl:fill", proposal: bid.proposal, price: plan.price, period: plan.period }, 20000);
    log(`Filled in ${secs(Date.now() - fillAt)} s: proposal ${filled.chars} chars, ` + (filled.tabbed ? "Tab pressed" : "Tab blocked by the page") +
      `, price ${filled.price}, timeline ${filled.period}`);
    if (filled.retried) log("Freelancer did not take the proposal the first time; entered it again, now accepted", "warn");
    // Freelancer's own messages under the fields (e.g. a bid over what a new account
    // may bid): the bid would be refused, so it is not placed.
    if (filled.errors && filled.errors.length) {
      const why = "Freelancer shows: " + filled.errors.join(" | ");
      if (!review) throw new Error(why + ". Nothing was submitted.");
      log(why + ". Fix it on the page before Continue.", "warn");
    }
    checkStop();

    // 4) optional upgrades: each one on the page is ticked or unticked as in the panel
    setStatus("4/7 Setting the bid upgrades...");
    const want = {};
    for (const id in UPGRADE_BOXES) want[UPGRADE_BOXES[id]] = settings[id];
    if (pick) Object.assign(want, pick);
    const up = await call(flTab.id, { type: "fl:upgrades", want }, 15000);
    const wanted = Object.keys(want).filter((k) => want[k]);
    if (!up.found) {
      if (wanted.length) log("No Optional Upgrades on this page; " + wanted.join(", ") + " not added", "warn");
    } else {
      const name = (u) => u.name[0].toUpperCase() + u.name.slice(1);
      log("Upgrades: " + up.list.map((u) => name(u) + " " + (!u.found ? "not offered" : (u.on ? "on" : "off") + (u.cost ? " (" + u.cost + ")" : ""))).join(", "));
      for (const u of up.list) {
        if (!u.found) { if (want[u.name]) log(name(u) + " is not offered on this project, not added", "warn"); continue; }
        if (u.on === want[u.name]) continue;
        if (u.on) throw new Error(name(u) + " is ticked on the page and could not be unticked. Nothing was submitted.");
        log(name(u) + " could not be ticked" + (u.disabled ? " (disabled on this project)" : "") + (review ? "; tick it by hand before Continue" : ""), "warn");
      }
    }
    checkStop();

    // 5+6) the clarification question goes up as soon as it is written: now when it is
    // (review on: always), else the moment ChatGPT has it while the box waits for the
    // Place Bid time, or right after the bid when that comes first (step 8). A board problem
    // never stops the bid: it is said in the log, while paused and in the last status, and
    // when nothing could be sent it is tried once more (at Continue, or after the bid).
    const paused = review || !!ex.nda;
    let qText = bid.questions;   // the question, once written ("" for none)
    let qState = "";             // "done" (posted, already up, none, not possible) or "retry"
    let boardDone = "";          // what became of the question, for the last status (see doneText)
    let pauseNote = "";          // the question's state, shown while paused
    const takeQuestion = async () => { qText = await qWait; qWait = null; checkStop(); };
    const putUp = async (label, later) => {
      if (!qText) { boardDone = noQuestion(); pauseNote = " " + AI() + " wrote no clarification question."; qState = "done"; return; }
      bid.questions = qText;
      showLast(plan, bid);
      const r = await postQuestion(flTab, qText, startedAt, label, later);
      qState = r.state;
      boardDone = r.end;
      pauseNote = r.note;
      checkStop();
    };
    if (settings.clarify) {
      // Paused (an NDA to sign, review off): ChatGPT is about done with the question, and
      // the wait for you may be long, so it goes up first.
      if (qWait && (qWaitDone || paused)) {
        if (!qWaitDone) setStatus("5-6/7 " + AI() + ": finishing the clarification question...");
        await takeQuestion();
      }
      if (!qWait) await putUp("5-6/7 ", paused ? "Continue" : "after the bid");
    }

    // An NDA to sign: Freelancer refuses the bid until it is signed, so the box does not
    // click Place Bid; it opens the NDA and waits for you, like Pause for review.
    if (ex.nda) await openNda(flTab, ex);
    let mine = { byHand: false };
    if (paused) {
      // Auto bid waits here as Start does (other tabs wait for this bid).
      if (autoRun) showAuto(ex.nda ? "Auto: waiting for you to sign the NDA and place the bid (or press Continue)" : "Auto: waiting for your review: press Continue (or click Place Bid yourself)", true);
      mine = await pause(flTab, (ex.nda ? "Sign the NDA in the new tab, then click Place Bid (or press Continue)." : "Check the bid, then press Continue (or click Place Bid yourself).") + pauseNote);
      checkStop();
    }

    // 6) at Continue, a question that could not be posted before the pause: what its box
    // holds now (you may have changed it), typed again first when the box is empty or gone.
    // Whatever happens, the bid goes on.
    if (qState === "retry" && paused && !mine.byHand) {
      setStatus("6/7 Posting the clarification question...");
      try {
        const posted = await call(flTab.id, { type: "fl:clarifyPost", retype: qText }, 60000, false);
        boardDone = postedText(posted, startedAt);
      } catch (e) {
        boardDone = notPosted(e.message);
      }
      qState = "done";
      await sleep(200);
      checkStop();
    }

    // 7) Place Bid, after the wait for this project's bid count (read again now if
    // it was still loading at Start). Not when you placed it yourself while paused.
    let placed;
    let bidsBefore = ex.bids;   // the bid count before this bid (see fl:afterBid)
    // The clarification question goes up after the bid (step 8): ChatGPT had not written it
    // by the Place Bid time, or nothing could be sent before the bid (review off), or you
    // placed the bid yourself while paused before it could be posted.
    const afterBidPost = () => settings.clarify && (!!qWait || (qState === "retry" && (!paused || mine.byHand)));
    if (mine.byHand) {
      placed = { confirmed: true };
      log(`You placed the bid, ${secs(Date.now() - startedAt)} s after Start`, "ok");
      if (!afterBidPost()) setStatus(doneText(boardDone));
    } else {
      if (bidsBefore == null) bidsBefore = (await call(flTab.id, { type: "fl:check" }, 10000)).bids;
      const bids = bidsBefore;
      const waitSec = bidWait(bids);
      log(bids == null ? `Bid count not found, so Place Bid ${waitSec} s after Start` : `Bids: ${bids}, so Place Bid ${waitSec} s after Start`);
      const at = startedAt + (waitSec || 0) * 1000;
      let waitSaid = false;
      const sayWait = () => {
        if (waitSaid || Date.now() >= at) return;
        waitSaid = true;
        log(`Waiting ${Math.ceil((at - Date.now()) / 1000)} s so Place Bid is clicked ${waitSec} s after Start`);
      };
      // Review off: the question goes up the moment ChatGPT has it, also during this wait
      // (a post under way finishes before Place Bid).
      if (qWait && !qWaitDone && Date.now() < at) {
        sayWait();
        await waitForBidTime(at, qWait);
      }
      // The Place Bid time came while ChatGPT still writes the question: it gets a few
      // seconds more (it usually needs well under one), so the question still goes up
      // first; a post after the bid must wait for Freelancer's update (up to about 7 s).
      if (qWait && !qWaitDone) {
        setStatus("6/7 " + AI() + ": finishing the clarification question...");
        await Promise.race([qWait.then(() => {}, () => {}), sleep(QUESTION_GRACE), stopper.promise]);
        checkStop();
        if (!qWaitDone) log(`${AI()} had not finished the clarification question ${QUESTION_GRACE / 1000} s after the Place Bid time: the bid goes first, the question right after it`);
      }
      if (qWait && qWaitDone) {
        await takeQuestion();
        await putUp("6/7 ", "after the bid");
      }
      sayWait();
      await waitForBidTime(at);
      setStatus("7/7 Placing the bid...");
      // The values go along: Freelancer can reset its form while we wait (its data
      // reloads), and then they are filled in again right before the click. In review
      // mode the page is left as the user checked it (they may have changed it by hand).
      const expect = review ? {} : { proposal: bid.proposal, price: plan.price, period: plan.period };
      placed = await call(flTab.id, Object.assign({ type: "fl:placeBid" }, expect), 90000, false);
      if (placed.restored && placed.restored.length) log("Freelancer had reset the bid form (" + placed.restored.join(", ") + "); filled it again before Place Bid", "warn");
      log("Clicked \"" + placed.button + "\"");
      if (placed.attempts > 1) log("First Place Bid click failed (" + placed.firstError + "); saved the proposal again and clicked once more", "warn");
      if (placed.confirmed) {
        log(`Bid placed, ${secs(Date.now() - startedAt)} s after Start`, "ok");
        if (!afterBidPost()) setStatus(doneText(boardDone));
      } else {
        const why = [placed.dialog, ...(placed.errors || [])].filter(Boolean).join(" | ");
        log("Clicked Place Bid but could not confirm it. " + why, "warn");
        setStatus("Clicked Place Bid. Check the page to confirm it went through.");
      }
    }

    outcome.placed = !!placed.confirmed;
    // 8) the clarification post right after the bid (see afterBidPost). The bid is in
    // whatever happens here, so a problem is a warning, not an error.
    if (afterBidPost() && !placed.confirmed) log("The clarification question was not posted, as the bid could not be confirmed", "warn");
    else if (afterBidPost()) {
      try {
        // Freelancer updates the project after a bid, and that starts the board's form
        // over (text typed into it a moment earlier is lost): wait for it while ChatGPT
        // finishes the question.
        const settled = call(flTab.id, { type: "fl:afterBid", bids: bidsBefore }, 15000);
        settled.catch(() => {});
        if (qWait) {
          if (!qWaitDone) setStatus("Bid placed. " + AI() + ": finishing the clarification question...");
          await takeQuestion();
        } else if (mine.byHand && mine.boardValue) {
          // Your own Place Bid while paused: what the board's box held then (you may have
          // changed it).
          qText = mine.boardValue;
        }
        if (!qText) boardDone = noQuestion();
        else {
          bid.questions = qText;
          showLast(plan, bid);
          setStatus("Bid placed. Waiting for Freelancer to update the page...");
          const s = await settled.catch(() => null);
          checkStop();
          if (s && !s.noBoard) log((s.countUp ? "Freelancer updated the page after the bid (bid count up)" : "The bid count did not change on the page") +
            `; typing the question ${secs(s.ms)} s after the bid`);
          boardDone = (await postQuestion(flTab, qText, startedAt, "Bid placed. ", "")).end;
        }
        setStatus(doneText(boardDone));
      } catch (e) {
        const msg = e && e.message ? e.message : String(e);
        if (msg === "Stopped") {
          log("Stopped after the bid was placed; no clarification question posted", "warn");
          setStatus("Stopped after the bid was placed; no clarification question posted.");
        } else setStatus(doneText(notPosted(msg)));
      }
    }
  } catch (e) {
    const msg = e && e.message ? e.message : String(e);
    log(msg, e && e.plain ? "warn" : "err");
    setStatus(msg === "Stopped" ? "Stopped." : e && e.plain ? msg : "Error: " + msg);
    outcome.error = msg;
    outcome.plain = !!(e && e.plain);
    outcome.stopped = msg === "Stopped";
    outcome.fatal = AUTO_FATAL.test(msg);
    // Back to the Freelancer page if ChatGPT was brought to the front for this run.
    if (switched && flTab) { try { await focusTab(flTab); } catch (err) {} }
  } finally {
    ended = true;
    // A clarification post still being written when the run ended early: stop it, so
    // it never runs alongside the next bid.
    if ((rest && !restDone) || (qWait && !qWaitDone)) {
      await quick(chrome.tabs.sendMessage(gptTab.id, { type: "cgpt:abort", from: myTabId }), 2000);
      await quick(qWait || rest, 3000);
    }
    // The bid that fills the chat (newChatAfter bids): a new chat for the next bids, ready
    // before the next Start. Not after Stop.
    if (chatNote) setStatus($("status").textContent + chatNote);
    if (gptTab && newChatOn() && chatCount >= settings.newChatAfter && !stopRequested) {
      await newChatAfterBid(gptTab, flTab, chatPath, chatCount, gptOnScreen);
    }
    stopper = null;
    setRunning(false);
  }
  return outcome;
}

// ---------- copy buttons ----------

// The text of the last copy (also what "Click to copy" copies).
let lastCopy = "";
let copying = false;
// Copies text to the clipboard. After a long step (the chat loads its older messages)
// the browser may want a fresh click for that: then "Click to copy" shows.
async function copyText(text) {
  lastCopy = text;
  $("copyAgain").hidden = true;
  try { await navigator.clipboard.writeText(text); return true; } catch (e) { /* below */ }
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.cssText = "position:fixed;left:-9999px;top:0;width:10px;height:10px";
  document.body.append(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand("copy"); } catch (e) {}
  ta.remove();
  if (!ok) $("copyAgain").hidden = false;
  return ok;
}
$("copyAgain").addEventListener("click", async () => {
  const ok = await copyText(lastCopy);
  setStatus(ok ? "Copied." : "The browser did not let the box copy: try once more.");
});
// Between the project's details and your proposal in "Copy all" (the details text uses
// the same line between its own parts).
const COPY_SEP = "------------------------------------------------------------";
// kind: "details", "proposal", "all" (details + proposal), "chatAll" or "chatLast".
async function copyFromPage(kind) {
  if (running || copying || myTabId == null) return;
  copying = true;
  for (const id of COPY_BUTTONS) $(id).disabled = true;
  const what = { details: "the project details", proposal: "your proposal", all: "the project details", chatAll: "the whole chat", chatLast: "the client's latest messages" }[kind];
  setStatus(`Copying ${what}...` + (kind === "chatAll" ? " (loading older messages first)" : ""));
  try {
    await ping({ id: myTabId, title: "Freelancer" }, "content/freelancer.js", "fl:ping");
    const msg = kind === "details" || kind === "all" ? { type: "fl:details" } : kind === "proposal" ? { type: "fl:proposal" } : { type: "fl:chat", mode: kind === "chatAll" ? "all" : "last" };
    const r = await call(myTabId, msg, kind === "chatAll" ? 600000 : 60000);
    if (r.none) {
      setStatus(r.why);
      showToast(r.why);
      return;
    }
    let text = r.text, said;
    if (kind === "all") {
      // Then your proposal (each step opens the tab it needs and goes back after).
      setStatus("Copying your proposal...");
      const p = await call(myTabId, { type: "fl:proposal" }, 60000);
      if (p.none) {
        said = `the details of "${r.title}" only: ` + p.why.replace(/[.\s]+$/, "").replace(/^./, (c) => c.toLowerCase());
        showToast(p.why);
      } else {
        text += "\n\n" + COPY_SEP + "\n\nMY PROPOSAL\n\n" + p.text;
        said = `the details of "${r.title}" and your proposal (${p.text.length} characters)`;
      }
    } else {
      said = kind === "details" ? `the details of "${r.title}"` : kind === "proposal" ? `your proposal (${r.text.length} characters)` :
        `${r.count} message${r.count === 1 ? "" : "s"}` + (kind === "chatLast" ? " from the client after your last message" : "") +
        (r.top === false ? " (the chat's oldest messages did not load)" : "");
    }
    const ok = await copyText(text);
    setStatus((ok ? "Copied " : "Ready: ") + said + (ok ? "." : ". Click \"Click to copy\"."));
    if (r.noTime) log(`${r.noTime} message${r.noTime === 1 ? "" : "s"} without a time (only the day): Freelancer shows "Read on ..." for your last message instead of its time`);
  } catch (e) {
    setStatus("Error: " + e.message);
  } finally {
    copying = false;
    for (const id of COPY_BUTTONS) $(id).disabled = running;
  }
}
$("copyDetails").addEventListener("click", () => copyFromPage("details"));
$("copyProposal").addEventListener("click", () => copyFromPage("proposal"));
$("copyAll").addEventListener("click", () => copyFromPage("all"));
$("copyChatAll").addEventListener("click", () => copyFromPage("chatAll"));
$("copyChatLast").addEventListener("click", () => copyFromPage("chatLast"));
// Progress from the page while the chat loads its older messages.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== "fl:progress" || !copying || !sender.tab || sender.tab.id !== myTabId) return;
  setStatus("Copying: " + msg.text + "...");
});
// A notice that goes away by itself (e.g. no proposal of yours on this project).
function showToast(text) {
  const el = $("notice");
  if (!el.hidden && el.dataset.toast !== "1") return;   // a notice about the project stays
  el.hidden = false;
  el.textContent = text;
  el.className = "warn";
  el.dataset.toast = "1";
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { if (el.dataset.toast === "1") { el.hidden = true; el.dataset.toast = ""; } }, 6000);
}

// ---------- auto bid ----------

// The Manual / Auto switch is the same in every tab. While it is on (session storage
// autoTab: the tab it was switched on in; it ends with the browser):
// - every box looks at its own page: a project page opened after Auto was switched on,
//   that auto bid has not looked at yet, is checked and bid on when it fits (run with
//   auto: skipped when you bid on it already, it needs an NDA, or too few of its skills
//   are yours). One bid at a time across tabs (autoLock): they share the AI chat.
// - the tab it was switched on in also watches Freelancer's Updates counter and opens
//   each new project in its list there (that page is then checked like any other).
// Projects looked at are remembered (autoSeen), so none is bid on or skipped twice.
let autoOn = false;          // Auto is on (in any tab)
let autoWatch = false;       // this tab watches Freelancer's Updates
let autoLoopRunning = false;
let autoSeen = [];
let autoSeeded = false;      // the Updates list was read once since Auto was switched on
let autoMore = false;        // something was done: look again at once (no pause)
let autoFeedAgain = false;   // a project was looked at: read the Updates list again (more may wait)
let autoStarting = null;     // the switch-on in progress (startAuto runs once at a time)
let autoErrors = 0;          // errors in a row (3 stop auto bid)
let autoStats = { bids: 0, skipped: 0 };
// The project page this tab shows: its address, project ID and what it showed (sig) since
// when; done: the address whose visit auto bid has handled (see autoCheckPage).
let autoVisit = { path: "", id: "", sig: "", since: 0, done: "" };
let autoSoon = false;        // a page is settling: look again in half a second
const SEEN_MAX = 500;
// A project page's address without "/details" / "/proposals", a query or a trailing slash.
const pathOf = (url) => { try { return new URL(url).pathname.replace(/\/(details|proposals)\/?$/i, "").replace(/\/+$/, ""); } catch (e) { return ""; } };

function showAuto(text, warn) {
  $("autoLabel").textContent = autoOn ? "Auto" : "Manual";
  $("auto").checked = autoOn;
  const el = $("autoInfo");
  el.hidden = !text;
  el.textContent = text || "";
  el.className = warn ? "warn" : "";
}
const autoSummary = () => `${autoStats.bids} bid${autoStats.bids === 1 ? "" : "s"}, ${autoStats.skipped} skipped`;
const autoWaiting = () => (autoWatch ? "Auto: waiting for new projects" : "Auto: a new project opened in this tab is bid on when it fits") + ` · ${autoSummary()}`;
async function setAuto(on, why) {
  if (on && !mySkills().length) {
    showAuto("Auto bid needs your skills: Settings > Auto bid.", true);
    showMore(true);
    $("autoBox").open = true;
    $("auto").checked = false;
    return;
  }
  if (on) {
    log("Auto bid on: new projects (from Freelancer's Updates, or opened in any tab) are bid on when they fit your skills", "sep");
    await chrome.storage.session.set({ autoTab: myTabId, autoStopWhy: "" });
    await startAuto(true);
  } else {
    await chrome.storage.session.set({ autoStopWhy: why || "" });
    await chrome.storage.session.remove(["autoTab", "autoJob", "autoLock"]);
    stopAuto(why);
  }
}
// here: Auto was switched on just now, so the page this box shows is not new. Runs once
// at a time (the switch and the storage change both call it), and everything is ready
// before the loop starts.
function startAuto(here) {
  if (!autoStarting) autoStarting = doStartAuto(here).finally(() => { autoStarting = null; });
  return autoStarting;
}
async function doStartAuto(here) {
  const s = await chrome.storage.session.get({ autoTab: null });
  if (s.autoTab == null) return;
  autoWatch = s.autoTab === myTabId;
  if (!autoOn) {
    const seen = (await chrome.storage.local.get({ autoSeen: [] })).autoSeen || [];
    const t = here ? await chrome.tabs.get(myTabId).catch(() => null) : null;
    autoSeen = seen;
    const p = t ? pathOf(t.url) : "";
    // The page you are on when you switch Auto on is not a new one.
    if (/^\/projects\//.test(p)) { markSeen(p); autoVisit.done = p; }
    autoErrors = 0;
    autoSeeded = false;
    autoFeedAgain = false;
    autoStats = { bids: 0, skipped: 0 };
    autoOn = true;
  }
  showAuto(autoWaiting() + "...");
  autoLoop();
}
function stopAuto(why) {
  if (!autoOn) return;
  autoOn = false;
  autoWatch = false;
  log(why ? "Auto bid off: " + why : "Auto bid off (" + autoSummary() + ")", why ? "warn" : "sep");
  showAuto(why ? "Auto bid stopped: " + why : "", !!why);
}
$("auto").addEventListener("change", (e) => setAuto(e.target.checked));
// The switch moved in another tab (or auto bid stopped there).
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "session" || !changes.autoTab) return;
  if (changes.autoTab.newValue != null) startAuto(!autoOn);
  else if (autoOn) chrome.storage.session.get({ autoStopWhy: "" }).then((s) => stopAuto(s.autoStopWhy));
});
function markSeen(path) {
  if (!path || autoSeen.includes(path)) return;
  autoSeen.push(path);
  autoSeen = autoSeen.slice(-SEEN_MAX);
  chrome.storage.local.set({ autoSeen });
}
async function autoLoop() {
  if (autoLoopRunning) return;
  autoLoopRunning = true;
  let lastFeed = 0;
  try {
    while (autoOn) {
      if (!running && !copying && !continueWait) {
        const did = await autoCheckPage();
        if (!did && autoWatch && autoOn && !running) lastFeed = await autoWatchTick(lastFeed);
      }
      // A page still settling is looked at again in half a second.
      for (let i = 0; i < (autoSoon ? 1 : 6) && autoOn && !autoMore; i++) await sleep(500);
      autoMore = false;
      autoSoon = false;
    }
  } catch (e) {
    if (autoOn) await setAuto(false, e.message);
  } finally {
    autoLoopRunning = false;
  }
}
// This tab's page: each time a project page is arrived at (a new visit), it is checked
// once it has settled, and bid on when it fits. Settled: the same project, bid form and
// notices for 1.5 s (Freelancer swaps a project in place, and for a moment the page can
// still show parts of the last one: a "Preferred Freelancers only" text from it once got
// a project you could bid on skipped), and the bid form there, or a reason not to bid, or
// 8 s gone by. A visit is checked once; coming back to a project checks it again (one
// you bid on, or whose skills are not yours, is skipped again at once, before any AI).
async function autoCheckPage() {
  const r = await quick(chrome.tabs.sendMessage(myTabId, { type: "fl:check" }), 4000);
  if (!r || !r.ok || r.build !== SCRIPT_BUILD) {
    await ping({ id: myTabId, title: "Freelancer" }, "content/freelancer.js", "fl:ping").catch(() => {});
    return false;
  }
  if (r.page !== "project" || !r.loaded) return false;
  const path = pathOf(r.url);
  if (!path || autoVisit.done === path) return false;
  // A new address that still shows the last project: Freelancer is still changing the page.
  if (path !== autoVisit.path && r.projectId && r.projectId === autoVisit.id) { autoSoon = true; return false; }
  const b = r.blocker;
  const sig = [r.projectId, b ? b.kind + (b.formShown ? "+form" : "") : "", r.hasForm, (r.skills || []).length].join("|");
  if (path !== autoVisit.path || sig !== autoVisit.sig) {
    autoVisit = { path, id: r.projectId, sig, since: Date.now(), done: autoVisit.done };
    autoSoon = true;
    return false;
  }
  const settled = Date.now() - autoVisit.since;
  if (settled < 1500 || (!r.hasForm && !b && settled < 8000)) { autoSoon = true; return false; }
  autoVisit.done = path;
  markSeen(path);
  // A project the Updates watcher opened shows now (maybe at another address).
  const { autoJob } = await chrome.storage.session.get({ autoJob: null });
  if (autoJob && autoJob.tabId === myTabId) { markSeen(autoJob.path); await chrome.storage.session.remove("autoJob"); }
  log(`Auto: new project on this page: ${r.title || path}`);
  await autoBid(r);
  autoMore = true;
  autoFeedAgain = true;
  return true;
}
// The tab Auto was switched on in: Freelancer's Updates counter, and its list when it
// has new projects.
async function autoWatchTick(lastFeed) {
  const u = await quick(chrome.tabs.sendMessage(myTabId, { type: "fl:updates" }), 3000);
  if (!u || !u.ok) return lastFeed;
  if (!u.button) {
    showAuto("Auto: Freelancer's Updates button (the folder icon) is not on this page; a project you open is still bid on when it fits.", true);
    return lastFeed;
  }
  // A project it opened that never showed: given up after 40 s.
  const { autoJob } = await chrome.storage.session.get({ autoJob: null });
  if (autoJob && autoJob.tabId === myTabId) {
    if (Date.now() - autoJob.at < 40000) return lastFeed;
    log(`Auto: the project did not open: ${autoJob.title}`, "warn");
    markSeen(autoJob.path);
    autoFeedAgain = true;
    await chrome.storage.session.remove("autoJob");
  }
  showAuto(`${autoWaiting()} (Updates: ${u.count || 0}) · checked ${new Date().toLocaleTimeString()}`);
  // The counter, the first look after switching on, something just done (more may be
  // waiting), and a look every 10 minutes in case a count was missed.
  if (u.count > 0 || !autoSeeded || autoFeedAgain || Date.now() - lastFeed > 600000) {
    lastFeed = Date.now();
    autoFeedAgain = false;
    await autoFeed();
  }
  return lastFeed;
}
async function autoFeed() {
  let f;
  try { f = await call(myTabId, { type: "fl:feed" }, 15000); } catch (e) { log("Auto: could not read Freelancer's Updates: " + e.message, "warn"); return; }
  if (f.none) { showAuto("Auto: " + f.why + "; waiting...", true); return; }
  const entries = f.entries || [];
  // Once per switch-on: the list did not open or holds no projects (page details for a fix).
  if (!entries.length && !autoFeed.said) { autoFeed.said = true; log("Auto: Freelancer's Updates list shows no projects (" + (f.diag || "") + ")", "warn"); }
  if (entries.length) autoFeed.said = false;
  if (!autoSeeded) {
    // What was there (and read) before Auto was switched on is not new; unread entries are.
    for (const e of entries) if (!e.highlighted) markSeen(e.path);
    autoSeeded = true;
  }
  const next = entries.find((e) => !autoSeen.includes(e.path));
  if (!next || !autoOn) { await quick(chrome.tabs.sendMessage(myTabId, { type: "fl:feedClose" }), 3000); return; }
  log(`Auto: new project in Updates: ${next.title}`);
  showAuto(`Auto: opening "${next.title.slice(0, 60)}"...`);
  // Kept in session storage: if the page loads, the next page's box knows it.
  await chrome.storage.session.set({ autoJob: { tabId: myTabId, path: next.path, title: next.title, at: Date.now() } });
  const g = await call(myTabId, { type: "fl:goto", path: next.path }, 45000).catch((e) => ({ error: e.message }));
  // This page goes away (the project loads in it); the box on the next page goes on.
  if (g.how === "load" || /message (channel|port) closed|receiving end does not exist/i.test(g.error || "")) return;
  if (g.error) { log(`Auto: the project did not open (${g.error}): ${next.title}`, "warn"); markSeen(next.path); autoFeedAgain = true; await chrome.storage.session.remove("autoJob"); return; }
  autoMore = true;   // the page is checked at once
}
// One bid at a time in all tabs (they share the AI chat). false: Auto went off meanwhile.
async function autoLock() {
  for (let said = false; autoOn; ) {
    const { autoLock: l } = await chrome.storage.session.get({ autoLock: null });
    // A lock not renewed for 3 minutes belongs to a tab that went away (see autoBid).
    if (!l || l.tabId === myTabId || Date.now() - l.at > 180000) {
      await chrome.storage.session.set({ autoLock: { tabId: myTabId, at: Date.now() } });
      await sleep(150);
      const { autoLock: m } = await chrome.storage.session.get({ autoLock: null });
      if (m && m.tabId === myTabId) return true;
    }
    if (!said) { said = true; showAuto("Auto: waiting for the bid in another tab to finish..."); }
    await sleep(1000);
  }
  return false;
}
async function autoUnlock() {
  const { autoLock: l } = await chrome.storage.session.get({ autoLock: null });
  if (l && l.tabId === myTabId) await chrome.storage.session.remove("autoLock");
}
async function autoBid(page) {
  if (!(await autoLock())) return;
  let r;
  // The lock is renewed while the bid runs: it may wait for you (Pause for review, an NDA).
  const beat = setInterval(() => { chrome.storage.session.set({ autoLock: { tabId: myTabId, at: Date.now() } }).catch(() => {}); }, 60000);
  try {
    showAuto(`Auto: checking "${(page.title || "").slice(0, 60)}"...`);
    r = await run(null, { auto: true });
  } finally {
    clearInterval(beat);
    await autoUnlock();
  }
  if (r.placed) { autoStats.bids++; autoErrors = 0; }
  else if (r.skipped) { autoStats.skipped++; autoErrors = 0; }
  // What to do next (e.g. "Sign the NDA in the new tab ...") is not an error.
  else if (r.error && !r.stopped && !r.plain) autoErrors++;
  if (r.stopped) await setAuto(false, "you pressed Stop");
  else if (r.fatal) await setAuto(false, r.skipped || r.error);
  else if (autoErrors >= 3) await setAuto(false, "3 bids in a row ended in an error (last: " + r.error + ")");
  else showAuto(autoWaiting() + (r.skipped ? ` (last: skipped, ${r.skipped})` : r.placed ? " (last: bid placed)" : ""));
}

// The box on the Freelancer page sizes its frame to what this page needs: the
// narrow button column, or a wider area while Settings is open.
function reportSize() {
  const w = $("more").hidden ? Math.ceil(document.querySelector(".main").getBoundingClientRect().width) + 16 : 340;
  const h = Math.ceil(document.body.getBoundingClientRect().height);
  parent.postMessage({ flbidSize: { w, h } }, location.ancestorOrigins[0] || "*");
}
new ResizeObserver(reportSize).observe(document.body);

$("ver").textContent = "v" + VERSION;
showShortcut();
loadSettings().then(async () => {
  const me = await chrome.tabs.getCurrent();
  myTabId = me ? me.id : null;
  takePendingStart((await chrome.storage.session.get("pendingStart")).pendingStart);
  idleCheck();
  setInterval(idleCheck, 2500);
  // Auto bid is on (switched on here or in another tab): this page is a new one.
  startAuto(false);
});
