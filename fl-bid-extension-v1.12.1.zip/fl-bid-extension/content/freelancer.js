// Injected into the Freelancer project tab by the panel. Reads the project,
// fills the bid form and clarification board, and clicks Post / Place Bid.
(() => {
  // Change with every update of this file: the panel replaces a copy whose build
  // differs (one left in the page from before an update). After an extension reload
  // the old copy's runtime is dead, so a fresh one registers.
  const BUILD = "1.12.1";
  const prev = window.__flbidFl;
  if (prev && prev.alive()) {
    if (prev.build === BUILD) return;
    prev.retire();
  } else if (!prev && window.__flbidAlive && window.__flbidAlive()) {
    // A live copy from before v1.7 cannot be retired; the panel asks for a page reload.
    return;
  }

  const PROPOSAL_LABEL = /describe your proposal/i;
  const PRICE_LABEL = /^\s*(bid amount|hourly rate)\s*$/i;
  const PERIOD_LABEL = /^\s*(this project will be delivered in|weekly limit)\s*$/i;
  const HOURLY_LABEL = /^\s*(hourly rate|weekly limit)\s*$/i;
  const BOARD_LABEL = /^\s*clarification board\s*$/i;
  // With a paid upgrade ticked the button reads "Place Bid and Pay $0.42 USD".
  const PLACE_BID = /^place bid(\s+(and|&)\s+pay\b[\s\S]*)?$/i;
  const FIELD = "input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])";
  const CODES = "USD|EUR|GBP|AUD|CAD|NZD|SGD|HKD|INR|PHP|IDR|MXN|ZAR|SEK|PLN|JPY|BRL|CLP";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const visible = (el) => !!el && el.getClientRects().length > 0;
  const getText = (el) => (el ? (el.innerText || el.textContent || "").trim() : "");
  const cleanText = (t) => (t || "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const follows = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

  // First visible element holding a text node that matches re.
  function findText(re, from) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (from && !follows(from, n)) continue;
      if (re.test(n.nodeValue) && visible(n.parentElement)) return n.parentElement;
    }
    return null;
  }
  // First visible element matching selector that comes after anchor in the page.
  function after(anchor, selector) {
    for (const el of document.querySelectorAll(selector)) {
      if (visible(el) && follows(anchor, el)) return el;
    }
    return null;
  }
  function buttonByText(re, from) {
    for (const b of document.querySelectorAll("button, [role='button'], input[type='submit']")) {
      if (from && !follows(from, b)) continue;
      if (re.test((b.innerText || b.value || "").trim()) && visible(b)) return b;
    }
    return null;
  }
  const isDisabled = (b) => b.disabled || b.getAttribute("aria-disabled") === "true";
  function inputAfterLabel(re) {
    const label = findText(re);
    return label ? after(label, FIELD) : null;
  }
  // Freelancer's text boxes save their text into the bid form only on a "blur"
  // event: the proposal box (fl-textarea, dynamicValidation "blur") switches its
  // form control to updateOn "blur", and its handleBlur() runs
  // control.setValue(textarea.value). But when the page itself does not have focus
  // (Start was clicked in the panel's frame), Chrome moves focus WITHOUT firing
  // focus/blur events, so the text never reaches the form ("Please enter your
  // proposal"). So fire the focus/blur events on the element ourselves.
  function fireFocus(el) {
    el.focus({ preventScroll: true });
    el.dispatchEvent(new FocusEvent("focus"));
    el.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
  }
  function fireBlur(el) {
    el.dispatchEvent(new FocusEvent("blur"));
    el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    el.blur();
  }

  // Angular listens for input/change/blur, so set the value the way typing would.
  function setValue(el, value, keepFocus) {
    fireFocus(el);
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      document.execCommand("insertText", false, value);
    } else {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    if (!keepFocus) fireBlur(el);
  }
  // Checks right away, then every 50 ms: a wait ends as soon as its condition holds.
  async function waitFor(fn, ms) {
    for (const t0 = Date.now(); ; await sleep(50)) {
      const v = fn();
      if (v) return v;
      if (Date.now() - t0 >= ms) return null;
    }
  }
  // Angular updates the page within the same task as the event, so a short pause
  // between form steps is enough.
  const STEP = 60;
  const valueOf = (el) => (el.isContentEditable ? el.innerText : el.value);

  // Insert text through the browser's own editing command, which fires the same
  // beforeinput/input events as typing; fall back to the value setter. The text is
  // only saved into Freelancer's form by the blur that follows (see fireBlur).
  function typeText(el, text) {
    fireFocus(el);
    el.select();
    let ok = false;
    try { ok = document.execCommand("insertText", false, text); } catch (e) {}
    if (!ok || el.value !== text) {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
    el.dispatchEvent(new KeyboardEvent("keyup", { key: "End", code: "End", bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  // Second try: empty the box, then paste the text (falls back to typeText).
  function retypeText(el, text) {
    fireFocus(el);
    el.select();
    try { document.execCommand("delete"); } catch (e) {}
    const dt = new DataTransfer();
    dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    if (el.value !== text) typeText(el, text);
  }
  // Freelancer shows this under the box when its form has no proposal.
  const PROPOSAL_ERROR = /please (enter|write|add) (your|a) proposal|proposal is required/i;
  const proposalRejected = (box, text) => box.value !== text || !!findText(PROPOSAL_ERROR, box);
  // Freelancer's messages under the bid form's fields (fl-validation-error, shown in
  // red for a value its form refuses: "Your proposal must not be greater than 1500
  // characters", "You must have at least 3 reviews ... to place a bid greater than
  // ...", "Please enter at least 1 day", ...). Warnings (amber) are not counted.
  function formErrors() {
    const box = proposalBox();
    const btn = buttonByText(PLACE_BID);
    // The bid form: the smallest box holding both the proposal and Place Bid.
    let form = box;
    while (form && btn && !form.contains(btn)) form = form.parentElement;
    const out = [];
    for (const el of (form || document).querySelectorAll("fl-validation-error .text-error, fl-validation-error .ErrorText:not(.text-warning)")) {
      const t = getText(el).replace(/\s+/g, " ");
      if (t && visible(el) && out.indexOf(t) === -1) out.push(t);
    }
    return out.slice(0, 5);
  }

  // Press Tab on el: the same events a real Tab produces, in the same order
  // (keydown, blur/focusout on el, focus/focusin on the next field, keyup), with
  // the blur fired explicitly because it is what saves the proposal (see fireFocus).
  // If the page cancels the keydown, nothing moves, as with a real Tab.
  function pressTab(el) {
    const key = { key: "Tab", code: "Tab", keyCode: 9, which: 9, bubbles: true, cancelable: true };
    if (!el.dispatchEvent(new KeyboardEvent("keydown", key))) return false;
    const next = [...document.querySelectorAll("input, textarea, select, button, a[href], [tabindex]")]
      .find((x) => visible(x) && !x.disabled && x.tabIndex >= 0 && follows(el, x));
    fireBlur(el);
    if (next) fireFocus(next);
    (next || el).dispatchEvent(new KeyboardEvent("keyup", key));
    return true;
  }
  // The proposal box: Freelancer gives it id "descriptionTextArea".
  function proposalBox() {
    const byId = document.querySelector("textarea#descriptionTextArea, #descriptionTextArea textarea");
    if (byId && visible(byId)) return byId;
    const label = findText(PROPOSAL_LABEL);
    return label ? after(label, "textarea") : null;
  }
  // Your own bid: the edit form ("Update Bid", maybe "... and Pay $0.12 USD"), or
  // your card in the bid list. Freelancer gives only your own card the "Retract"
  // and "Edit" actions (or "Request Edit" / "Edit request submitted"); other
  // people's bids get "Report Bid". Once you have bid, the bid form is gone.
  // (findText, not the page's innerText: that lays out the whole page and is slow.)
  const OWN_BID_ACTION = /^\s*(retract|retract bid|request edit|edit request submitted)\s*$/i;
  function ownBidCard() {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!OWN_BID_ACTION.test(n.nodeValue)) continue;
      const el = n.parentElement;
      if (visible(el) && el.closest("app-bid-card, app-bid-card-actions-pattern, button, a, fl-button, fl-link, [role='button']")) return true;
    }
    return false;
  }
  function alreadyBid() {
    return !!buttonByText(/^(update bid(\s+(and|&)\s+pay\b[\s\S]*)?|retract bid)$/i) || !!findText(/edit your bid on this project/i) || ownBidCard();
  }

  // "Bids 6" in the project header: Freelancer's app-project-summary has a "Bids"
  // label with the count under it (a loading placeholder until it arrives).
  // null while loading or when the page has no count.
  const NAV = "header, nav, [role='navigation'], fl-navigation, [class*='Navigation' i], [class*='navbar' i]";
  function bidCount() {
    const num = (s) => parseInt(s.replace(/,/g, ""), 10);
    const val = document.querySelector("app-project-summary .ContentWrapper:not(.Bid) .text-body-24");
    const own = val && getText(val).match(/^\d[\d,]*$/);
    if (own) return num(own[0]);
    // Other layouts: a "Bids" label whose box reads "Bids 6".
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!/^\s*bids:?\s*$/i.test(n.nodeValue) || !visible(n.parentElement) || n.parentElement.closest(NAV)) continue;
      for (let el = n.parentElement.parentElement, up = 0; el && up < 3; el = el.parentElement, up++) {
        const m = getText(el).match(/^\s*bids:?\s*(\d[\d,]*)\s*(\n|$)/i);
        if (m) return num(m[1]);
      }
    }
    const out = findText(/\d[\d,]* freelancers are bidding/i); // logged-out page
    return out ? num(getText(out).match(/(\d[\d,]*) freelancers/i)[1]) : null;
  }

  // Banners that stop a bid. Titles and messages are Freelancer's own (its bid form
  // code): "You must be a Preferred Freelancer", "Bidding on this project is
  // restricted" + "You must be Verified by Freelancer to bid on projects $2,500.00
  // USD and over...", "You have already bid on this project.", and a few rarer ones.
  // Not here: "You must sign the IP Agreement to work on this project" (a bid goes
  // through without it) and the NDA banner (see ndaLink: the box opens it to sign).
  const BLOCKERS = [
    { kind: "already", re: /you have already bid on this project/i },
    { kind: "preferred", re: /^\s*(you must be a preferred freelancer|only preferred freelancers can bid)/i },
    { kind: "verified", re: /^\s*you must be verified by freelancer to bid/i },
    { kind: "restricted", re: /^\s*(bidding on this project is restricted|you have a negative balance|this project is open to select freelancers only|this project requires a facebook certification|you must complete your profile to quote)/i },
    { kind: "nobids", re: /^\s*you have used all of your bids/i },
    { kind: "sign", re: /^\s*the client requires you to sign an agreement/i },
  ];
  // "You must sign the Non-Disclosure Agreement to work on this project. By signing the
  // Non-Disclosure Agreement ...": Freelancer refuses a bid until it is signed. The
  // banner's link opens the signing page in a new tab (initialize-nda-contract.php).
  function ndaLink() {
    const byHref = [...document.querySelectorAll("a[href*='initialize-nda-contract']")].find(visible);
    if (byHref) return byHref;
    return [...document.querySelectorAll("a, fl-link")].find((l) => /^\s*non[-\s]?disclosure agreement\s*$/i.test(getText(l)) && visible(l) &&
      /sign the\s+non[-\s]?disclosure agreement/i.test(getText(l.closest("fl-banner-alert, fl-card, [role='alert']") || l.parentElement))) || null;
  }
  // { href } of the NDA link (only a freelancer.com address), or null when there is none.
  function nda() {
    const l = ndaLink();
    if (!l) return null;
    const a = l.matches("a") ? l : l.querySelector("a");
    const href = a && /^https:\/\/([a-z0-9-]+\.)?freelancer\.com\//i.test(a.href) ? a.href : "";
    return { href };
  }
  // The banner's whole text: the first box around the matched line that adds more.
  function bannerText(el) {
    const own = getText(el).replace(/\s+/g, " ");
    for (let p = el.parentElement, up = 0; p && up < 4; p = p.parentElement, up++) {
      const t = getText(p).replace(/\s+/g, " ");
      if (t.length > 500) break;
      if (t.length > own.length + 15) return t;
    }
    return own;
  }
  // Freelancer's bid form ready to use: the proposal box and a Place Bid button that is on.
  const usableForm = () => { const b = buttonByText(PLACE_BID); return !!proposalBox() && !!b && !isDisabled(b); };
  // { kind, message, formShown } for the first reason (in BLOCKERS order) this project
  // cannot be bid on, or null. One pass over the page's text for all banners.
  // formShown: such a text is on the page, but so is the bid form, ready to use.
  // Freelancer leaves the form out when you may not bid, so the text is from somewhere
  // else: the last project, still being swapped out as Freelancer changes the page in
  // place (auto bid once skipped a project you could bid on with "Only Preferred
  // Freelancers can bid on this project"), or a tip. Then the bid goes ahead (Freelancer
  // refuses it if it really cannot be placed). "You have used all of your bids" stays.
  function blocker() {
    if (alreadyBid()) return { kind: "already", message: "You have already bid on this project." };
    const found = BLOCKERS.map(() => null);
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const v = n.nodeValue;
      if (v.length < 12) continue;
      BLOCKERS.forEach((b, i) => { if (!found[i] && b.re.test(v) && visible(n.parentElement)) found[i] = n.parentElement; });
    }
    const i = found.findIndex(Boolean);
    if (i < 0) return null;
    const message = bannerText(found[i]);
    const kind = BLOCKERS[i].kind === "restricted" && /you must be verified by freelancer to bid/i.test(message) ? "verified" : BLOCKERS[i].kind;
    return { kind, message, formShown: kind !== "nobids" && kind !== "already" && usableForm() };
  }
  function errorTexts() {
    const out = [];
    for (const el of document.querySelectorAll("[class*='error' i], [role='alert']")) {
      const t = getText(el);
      if (t && t.length < 200 && visible(el) && out.indexOf(t) === -1) out.push(t);
    }
    return out.slice(0, 5);
  }

  // ---------- 1) read the project ----------

  function findTitle() {
    const sel = ["fl-heading[size='xlarge']", "fl-heading[size='large']", "h1.PageTitle", "h1[class*='title' i]", ".ProjectViewDetails-title", "[class*='project-title']", "h1"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 4) return t;
    }
    return (document.title || "").replace(/\s*[-|].*$/, "").trim() || "Freelancer Project";
  }

  // The budget is a short text like "$30.00 – 250.00 USD", or "$50.00+ AUD per hour"
  // when the client gave only a minimum (Freelancer's currency pipe writes "+" then;
  // recruiter projects often have one). Freelancer's own budget box first
  // (app-project-details-budget), then the project card, and never the top bar (it
  // shows the account balance, "£0.00 GBP").
  function findBudget(card) {
    const AMOUNT = "\\d[\\d,]*(?:\\.\\d+)?";
    const RANGE = new RegExp(AMOUNT + "(?:\\s*[–—-]\\s*\\D{0,3}" + AMOUNT + "|\\s*\\+)\\s*(" + CODES + ")\\b");
    const SINGLE = new RegExp(AMOUNT + "\\+?\\s*(" + CODES + ")\\b");
    const SKIP = /paid to you|fee|average|avg|bids?\b|balance/i;
    for (const el of document.querySelectorAll("app-project-details-budget p, .ProjectViewDetails-budget p")) {
      const t = getText(el).replace(/\s+/g, " ");
      if (SINGLE.test(t) && /[1-9]/.test(t) && visible(el)) return t;
    }
    const scan = (root, re) => {
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (!/\d/.test(n.nodeValue) || !n.parentElement || n.parentElement.closest(NAV)) continue;
        let el = n.parentElement;
        for (let up = 0; up < 3 && el; up++, el = el.parentElement) {
          // textContent first (no page layout); innerText only for the match.
          const t = el.textContent.replace(/\s+/g, " ").trim();
          if (t.length > 80) break;
          if (re.test(t) && /[1-9]/.test(t) && !SKIP.test(t) && visible(el)) return getText(el).replace(/\s+/g, " ");
        }
      }
      return "";
    };
    return (card && scan(card, RANGE)) || scan(document.body, RANGE) || (card && scan(card, SINGLE)) || "";
  }

  // The card that holds the description, the skill tags and "Project ID: ...".
  function projectCard() {
    const pid = findText(/project id/i);
    for (let el = pid && pid.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      if (getText(el).length > 150) return el;
    }
    return null;
  }

  const STATUS_TAG = /^(open|closed|awarded|featured|urgent|nda|sealed|full ?time|recruiter|ip agreement|private|qualified|guaranteed)$/i;

  function findSkills(card) {
    // Skill tags link to /jobs/<skill>; status tags like "Open" do not.
    const sel = ["fl-tag", ".TagsList-tag", "[class*='SkillTag']", "[class*='skill-tag']", "[data-cy='skill-tag']"].join(", ");
    for (const scope of [card, document]) {
      if (!scope) continue;
      const all = [...scope.querySelectorAll(sel)];
      const linked = all.filter((el) => el.querySelector("a[href*='/jobs/']"));
      const list = [];
      for (const el of linked.length ? linked : all) {
        const t = getText(el);
        if (t && t.length < 60 && !STATUS_TAG.test(t) && list.indexOf(t) === -1) list.push(t);
      }
      if (list.length) return list;
    }
    // Fallback: the short leaf texts between "Skills Required" and "Project ID".
    const label = findText(/^\s*skills required\s*$/i);
    if (!label) return [];
    const box = label.parentElement && label.parentElement.parentElement;
    const list = [];
    if (box) {
      for (const el of box.querySelectorAll("*")) {
        if (el.children.length || !follows(label, el)) continue;
        const t = getText(el);
        if (/^project id/i.test(t)) break;
        if (t && t.length < 60 && list.indexOf(t) === -1) list.push(t);
      }
    }
    return list.slice(0, 30);
  }

  function findDescription(title, pageText, card, skills) {
    if (card) {
      // Card text up to "Skills Required", the skill tag list or "Project ID".
      const t = cleanText(getText(card));
      const cuts = [t.search(/\n\s*skills required\s*\n/i), t.search(/\n\s*project id/i)];
      if (skills.length > 1) cuts.push(t.indexOf("\n" + skills[0] + "\n" + skills[1]));
      else if (skills.length === 1) cuts.push(t.lastIndexOf("\n" + skills[0] + "\n"));
      const cut = Math.min(...cuts.filter((i) => i > 0));
      const desc = (isFinite(cut) ? t.slice(0, cut) : t).trim();
      if (desc.length > 100) return desc.slice(0, 15000);
    }
    const sel = ["app-project-description", "fl-text[class*='description' i]", "[class*='ProjectDescription']", "[class*='project-description']", ".NDAProject-description", "[data-cy='project-description']"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 30) return cleanText(t);
    }
    const head = findText(/^\s*project (description|details)\s*$/i);
    for (let el = head && head.parentElement, up = 0; el && up < 5; el = el.parentElement, up++) {
      const t = cleanText(getText(el));
      if (t.length > 100 && t.length < 15000) return t;
    }
    // Fallback: the page text between the title and "Skills Required".
    const start = title ? pageText.indexOf(title) : -1;
    const end = pageText.search(/\n\s*skills required\s*\n/i);
    if (start >= 0 && end > start) return pageText.slice(start + title.length, end).trim();
    const cut = pageText.search(/place a bid on this project/i);
    return (cut > 0 ? pageText.slice(0, cut) : pageText).slice(0, 8000).trim();
  }

  function findClient() {
    const sel = ["app-client-details", "[class*='ClientDetails']", "[class*='client-details']", "app-employer-info", "[class*='EmployerInfo']", "[class*='AboutClient']", "[class*='about-client']", "[data-cy='client-info']"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 10) return cleanText(t);
    }
    const head = findText(/about\s+the\s+client/i);
    for (let el = head && head.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      const t = cleanText(getText(el));
      if (t.length > 60 && t.length < 2000) return t;
    }
    return "";
  }

  // A badge of the client's "Client Verification" list (Freelancer's app-user-verifications):
  // true / false, or null when it is not on the page. Each row has a tooltip that says it
  // ("Verified to have a valid payment method" / "Not verified to have a valid payment
  // method", "Client made a deposit" / "Client has not made a deposit"; kept on the page as
  // the row's mattooltip attribute and its aria description); else its icon is green
  // (data-color "success") when it is.
  const GREEN = /^(success|aqua-light|blue-xdark)$/;
  function badge(label) {
    const el = findText(new RegExp("^\\s*" + label + "\\s*$", "i"));
    if (!el) return null;
    for (let row = el, up = 0; row && up < 6; row = row.parentElement, up++) {
      const ids = (row.getAttribute("aria-describedby") || "").split(/\s+/).filter(Boolean);
      const tip = row.getAttribute("mattooltip") || ids.map((id) => getText(document.getElementById(id))).join(" ");
      if (tip && tip.trim()) return !/\bnot\b|has not|hasn['’]t/i.test(tip);
    }
    for (let row = el, up = 0; row && up < 8; row = row.parentElement, up++) {
      const icon = row.querySelector("[data-color]");
      if (icon) return GREEN.test(icon.getAttribute("data-color") || "");
    }
    return null;
  }
  function findVerifications() {
    const out = [];
    for (const label of ["Identity verified", "Payment verified", "Deposit made", "Email verified", "Profile completed", "Phone verified"]) {
      const v = badge(label);
      if (v != null) out.push(label + ": " + (v ? "YES" : "NO"));
    }
    return out;
  }
  // The client as the "About the Client" card shows it (Freelancer's app-employer-info):
  // the country next to its flag (fl-flag), whether its payment method is verified and
  // whether it made a deposit. A part not on the page (yet) is null.
  function clientInfo() {
    let country = null;
    const card = document.querySelector("app-employer-info");
    const flag = [...(card || document).querySelectorAll("fl-flag")].find((f) => visible(f) && !f.closest(NAV + ", app-bid-card, fl-bid-pattern-card"));
    if (flag) {
      const row = flag.parentElement;
      const p = row && [...row.querySelectorAll("p, span")].find((x) => !x.closest("fl-flag") && getText(x));
      const t = flat(getText(p) || getText(row) || flag.getAttribute("title") || "");
      if (t && t.length < 60) country = t;
    }
    return { country, payment: badge("Payment verified"), deposit: badge("Deposit made") };
  }

  async function extract() {
    // Normally the form is already there and this returns at once. It waits while
    // Freelancer is still building the page, and once the project is shown, at most
    // 3 s more for a form (none when you have bid already or bidding is closed).
    // Not for the page's load event: the project and its form are on the page long
    // before Freelancer's images and trackers finish loading (that took up to 15 s).
    await waitFor(() => proposalBox() || projectCard() || blocker(), 15000);
    if (!proposalBox()) await waitFor(() => proposalBox() || blocker(), 3000);
    return { ok: true, data: readProject() };
  }

  // The project as the page shows it now: what the prompt gets (text, no link) and the
  // parts the panel uses.
  function readProject() {
    const stop = blocker();
    const pageText = cleanText(document.body.innerText);
    const title = findTitle();
    const card = projectCard();
    const budget = findBudget(card);
    const tl = pageText.match(/(?:bidding\s+)?ends\s+in[^\n]{0,40}/i);
    const skills = findSkills(card);
    const desc = findDescription(title, pageText, card, skills);
    const client = findClient();
    const verifications = findVerifications();
    const projectId = (pageText.match(/project id:?\s*(\d+)/i) || [])[1] || "";
    const formType = findText(HOURLY_LABEL) ? "hourly" : findText(PRICE_LABEL) ? "fixed" : "";
    // "Describe your proposal (minimum 100 characters)": the project's own minimum.
    const minLabel = getText(findText(PROPOSAL_LABEL)).match(/minimum\s+(\d+)\s+characters/i);

    const SEP = "------------------------------------------------------------";
    // No link in the text: ChatGPT would search the web for it before answering.
    const lines = ["=== " + title + " ==="];
    if (projectId) lines.push("Project ID: " + projectId);
    if (budget) lines.push("Budget: " + budget);
    if (tl) lines.push("Timeline: " + tl[0].replace(/\s+/g, " ").trim());
    if (skills.length) lines.push("Skills: " + skills.join(", "));
    lines.push(SEP, "", "PROJECT DESCRIPTION", "", desc || "(description not found)");
    if (client || verifications.length) {
      lines.push("", SEP, "", "CLIENT INFORMATION", "");
      if (client) lines.push(client);
      if (verifications.length) lines.push("", verifications.join("\n"));
    }

    return {
      title, budget, formType, projectId, url: location.href, skills, client: clientInfo(),
      minChars: minLabel ? parseInt(minLabel[1], 10) : null,
      hasProposal: !!(proposalBox() || findText(PROPOSAL_LABEL)),
      alreadyBid: !!stop && stop.kind === "already",
      blocker: stop,
      // May still be loading (null); the panel reads it again before Place Bid.
      bids: bidCount(),
      nda: nda(),
      idRequired: /identity verification|verify your identity|id verification/i.test(pageText),
      text: lines.join("\n"),
    };
  }

  // ---------- copy buttons: the project, your proposal ----------

  // The project page's tabs (the redesigned page): "Details" and "Proposals" (maybe with
  // a count). The details card shows only on Details, your proposal only on Proposals.
  const DETAILS_TAB = /^\s*details\s*$/i;
  const PROPOSALS_TAB = /^\s*proposals\b/i;
  function tabItem(re) {
    return [...document.querySelectorAll("fl-tab-item, [role='tab']")].find((t) => visible(t) && re.test(getText(t))) || null;
  }
  // Clicks the tab (its link) and waits until ready() holds.
  async function showTab(re, ready, ms) {
    const t = tabItem(re);
    if (!t) return false;
    (t.querySelector("a[href], button") || t).click();
    return !!(await waitFor(ready, ms));
  }
  // "Average bid $994 USD" next to the bid count (not on every project).
  function averageBid() {
    const el = document.querySelector("app-project-summary .ContentWrapper.Bid .text-body-24");
    return el ? getText(el).replace(/\s+/g, " ") : "";
  }

  // The project's details as text, bid on or not. On the Proposals tab (where Freelancer
  // shows a project once you have bid) the Details tab is opened for it, and the
  // Proposals tab again after.
  async function details() {
    await waitFor(() => projectCard() || tabItem(DETAILS_TAB), 6000);
    let switched = false;
    if (!projectCard() && tabItem(DETAILS_TAB)) switched = await showTab(DETAILS_TAB, projectCard, 8000);
    if (!projectCard()) return { ok: true, none: true, why: "The project details are not on this page." };
    const p = readProject();
    const bids = p.bids, avg = averageBid();
    const head = [bids != null ? "Bids: " + bids : "", avg ? "Average bid: " + avg : ""].filter(Boolean).join(" · ");
    const text = p.text.replace(/\n/, "\n" + (head ? head + "\n" : "") + "Link: " + location.href.replace(/[?#].*$/, "") + "\n");
    if (switched) await showTab(PROPOSALS_TAB, () => !projectCard(), 3000);
    return { ok: true, text, title: p.title, switched };
  }

  // Your own bid card: the one with Retract / Edit (see OWN_BID_ACTION).
  function ownCardEl() {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!OWN_BID_ACTION.test(n.nodeValue)) continue;
      const el = n.parentElement;
      if (!visible(el) || !el.closest("button, a, fl-button, fl-link, [role='button']")) continue;
      const card = el.closest("fl-bid-pattern-card, app-bid-card");
      if (card) return card;
    }
    return null;
  }
  // The proposal text in your card: Freelancer shows a few lines and a "more" button
  // (its flMaxLines cuts the text itself), so "more" is clicked first.
  async function myProposal() {
    await waitFor(() => ownCardEl() || tabItem(PROPOSALS_TAB) || projectCard(), 6000);
    let card = ownCardEl(), switched = false;
    if (!card && tabItem(PROPOSALS_TAB)) {
      switched = await showTab(PROPOSALS_TAB, ownCardEl, 8000);
      card = ownCardEl();
    }
    if (!card) return { ok: true, none: true, why: "You have no proposal on this project." };
    const descOf = (c) => c.querySelector(".BidCardBody .DescriptionContainer") || c.querySelector(".DescriptionContainer") ||
      c.querySelector("[class*='Description' i]") || [...c.querySelectorAll("p, div")].sort((a, b) => getText(b).length - getText(a).length)[0];
    // The card (and its text) may be drawn again once it is expanded: looked up each time.
    const textOf = () => { const c = ownCardEl() || card, d = c && descOf(c); return (d ? getText(d) : "").replace(/\s*(?:…|\.\.\.)?\s*\b(?:read |show )?(?:more|less)\s*$/i, "").trim(); };
    const desc = descOf(card);
    const more = desc && [...desc.querySelectorAll("button, .ReadMoreButton, [role='button']")].find((b) => visible(b) && /^\s*(read |show )?more\s*$/i.test(getText(b)));
    if (more) {
      const before = textOf().length;
      more.click();
      await waitFor(() => textOf().length > before + 3, 3000);
      await sleep(150);
    }
    const text = textOf();
    if (switched) await showTab(DETAILS_TAB, () => !ownCardEl(), 3000);
    if (!text) return { ok: true, none: true, why: "Your bid card shows no proposal text." };
    return { ok: true, text, expanded: !!more, switched };
  }

  // ---------- auto bid: Freelancer's Updates (new projects for your skills) ----------

  // The folder icon in Freelancer's top bar ("Updates", its RecentProjectsButton) with
  // the count of unread updates; its list holds the new projects that match your skills.
  function updatesButton() {
    return [...document.querySelectorAll("[fltrackinglabel='RecentProjectsButton'], [title='Updates']")].find(visible) || null;
  }
  function updatesCount() {
    const b = updatesButton();
    if (!b) return null;
    for (let el = b, up = 0; el && up < 4; el = el.parentElement, up++) {
      const c = el.querySelector("[label='Unread updates']");
      if (c) { const n = parseInt(getText(c).replace(/\D+/g, ""), 10); return isFinite(n) ? n : 0; }
    }
    return 0;
  }
  const updatesList = () => document.querySelector("app-updates-list") || document.querySelector("app-updates");
  const projectPath = (href) => {
    try { return new URL(href, location.href).pathname.replace(/\/(details|proposals)\/?$/i, "").replace(/\/+$/, ""); } catch (e) { return ""; }
  };
  // The projects in the open Updates list, newest first: { path, title, highlighted }
  // (highlighted: still unread).
  function feedEntries() {
    const root = updatesList();
    if (!root) return null;
    const out = [];
    for (const it of root.querySelectorAll("app-project-item, app-feed-item")) {
      if (it.matches("app-feed-item") && it.closest("app-project-item")) continue;
      const a = [...it.querySelectorAll("a[href]")].find((x) => /\/projects\//.test(x.getAttribute("href") || ""));
      if (!a) continue;
      const path = projectPath(a.getAttribute("href"));
      if (!path || out.some((e) => e.path === path)) continue;
      const hl = !!it.querySelector("[data-highlighted='true']") || it.getAttribute("data-highlighted") === "true";
      out.push({ path, title: flat(getText(a) || getText(it)).slice(0, 140), highlighted: hl });
    }
    return out;
  }
  // A click on the button itself (its inner button, if any: a click there reaches the
  // outer element too).
  const press = (el) => (el.matches("button, a[href]") ? el : el.querySelector("button, a[href]") || el).click();
  // Opens the Updates list (left open, so a project in it can be clicked).
  async function feed() {
    if (!updatesList()) {
      const b = updatesButton();
      if (!b) return { ok: true, none: true, why: "Freelancer's Updates button (the folder icon in the top bar) is not on this page" };
      press(b);
    }
    const list = await waitFor(() => { const e = feedEntries(); return e && e.length ? e : null; }, 6000);
    const entries = list || feedEntries() || [];
    const d = (el) => !el ? "none" : el.tagName.toLowerCase() + (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).slice(0, 2).join(".") : "");
    return { ok: true, entries, open: !!updatesList(),
      diag: entries.length ? undefined : "Updates button " + d(updatesButton()) + ", list " + (updatesList() ? "open, " + updatesList().querySelectorAll("a[href]").length + " links" : "not open") + ", unread " + updatesCount() };
  }
  async function feedClose() {
    if (!updatesList()) return { ok: true };
    const b = updatesButton();
    if (b) press(b);
    if (await waitFor(() => !updatesList(), 1500)) return { ok: true };
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    return { ok: true, closed: !!(await waitFor(() => !updatesList(), 1500)) };
  }
  const shownProjectId = () => { const c = projectCard(); const m = c && getText(c).match(/project id:?\s*(\d+)/i); return m ? m[1] : ""; };
  // Opens a project from the Updates list in this tab and waits until a project other
  // than the one before is shown, whatever its address turns out to be (Freelancer may
  // redirect the list's link). First the list's own link, as a click does (the page
  // changes in place); if the page does not move (the link opened elsewhere, or a
  // preview), the address is put in the tab's history and Freelancer's router told, as
  // Back / Forward do; last, the page is loaded (how "load": the panel goes on after it).
  async function gotoProject({ path }) {
    const beforePath = location.pathname, beforeId = shownProjectId();
    const shown = () => location.pathname !== beforePath && shownProjectId() && shownProjectId() !== beforeId;
    const a = [...document.querySelectorAll("app-updates-list a[href], app-updates a[href]")].find((x) => projectPath(x.getAttribute("href") || "") === path);
    if (a) {
      a.removeAttribute("target");
      a.click();
      if (await waitFor(shown, 4000)) return { ok: true, how: "link", url: location.href };
      if (location.pathname !== beforePath && (await waitFor(shown, 15000))) return { ok: true, how: "link", url: location.href };
    }
    if (location.pathname === beforePath || !shown()) {
      await feedClose();
      history.pushState({}, "", path);
      window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
      if (await waitFor(shown, 10000)) return { ok: true, how: "history", url: location.href };
    }
    setTimeout(() => location.assign(path), 50);
    return { ok: true, how: "load" };
  }

  // ---------- copy buttons: the chat ----------

  // A message is Freelancer's app-messaging-message-item: a date line on the first one of
  // a day ("Nov 03, 2026", or "Today"), and the bubble (Message-bubble) on your side
  // (Message-bubbleActionsAnchor--fromLoggedInUser) or the other's (--fromOtherUser). Its
  // time is the bubble's tooltip ("Nov 03 • 1:21 PM"; your last message may say "Read on
  // ..." instead), which the page also keeps as hidden text (aria-describedby).
  const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  const monthOf = (s) => MONTHS.findIndex((m) => m.startsWith(String(s).toLowerCase().slice(0, 3)));
  function parseDay(t) {
    if (/^\s*today\s*$/i.test(t)) { const d = new Date(); return { y: d.getFullYear(), m: d.getMonth(), d: d.getDate() }; }
    if (/^\s*yesterday\s*$/i.test(t)) { const d = new Date(Date.now() - 864e5); return { y: d.getFullYear(), m: d.getMonth(), d: d.getDate() }; }
    const m = t.match(/([a-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})/i) || [];
    const mo = monthOf(m[1] || "");
    return mo >= 0 ? { y: +m[3], m: mo, d: +m[2] } : null;
  }
  function bubbleTime(bubble) {
    const ids = (bubble.getAttribute("aria-describedby") || "").split(/\s+/).filter(Boolean);
    const own = [bubble.getAttribute("title") || "", bubble.getAttribute("aria-label") || ""];
    for (const t of ids.map((id) => getText(document.getElementById(id))).concat(own)) {
      const m = t.match(/([a-z]{3,9})\.?\s+(\d{1,2})\s*[•·,-]?\s*(\d{1,2}):(\d{2})\s*([ap])\.?m/i);
      if (!m || /^\s*(read on|seen)/i.test(t)) continue;
      let h = +m[3] % 12;
      if (/p/i.test(m[5])) h += 12;
      return { m: monthOf(m[1]), d: +m[2], h, mi: +m[4] };
    }
    return null;
  }
  const pad2 = (n) => String(n).padStart(2, "0");
  const Month = (i) => MONTHS[i][0].toUpperCase() + MONTHS[i].slice(1);
  function whenText(day, time) {
    if (time && time.m >= 0) {
      // The tooltip has no year: it is the day line's (the first message of each day has
      // one; "Today" is this year).
      const y = day ? day.y : new Date().getFullYear();
      return `${time.d} ${Month(time.m)}, ${y} ${pad2(time.h)}:${pad2(time.mi)}`;
    }
    return day ? `${day.d} ${Month(day.m)}, ${day.y}` : "";
  }
  // The text you see in the bubble: without the quoted message it replies to, the time
  // and the edit marks; an attachment as [attachment: name].
  function bubbleText(item, bubble) {
    if (item.querySelector("app-messaging-message-removed")) return "[message removed]";
    const parts = [];
    const texts = [...bubble.querySelectorAll("fl-interactive-text, .Message-bubble-text")].filter((el) => !el.closest("app-messaging-message-quote") && !el.parentElement.closest("fl-interactive-text, .Message-bubble-text"));
    for (const el of texts) { const t = getText(el); if (t) parts.push(t); }
    if (!parts.length) {
      const c = bubble.cloneNode(true);
      c.querySelectorAll("app-messaging-message-quote, app-messaging-message-details, .Message-editedMarkerRow, .Message-error, button, fl-icon").forEach((x) => x.remove());
      const t = (c.textContent || "").trim();
      if (t) parts.push(t);
    }
    for (const at of item.querySelectorAll("app-messaging-message-attachment, .Message-attachments [title], .Message-attachments img[alt]")) {
      const name = flat(at.getAttribute("title") || at.getAttribute("alt") || getText(at));
      if (name && !parts.some((p) => p.includes(name))) parts.push("[attachment: " + name + "]");
    }
    return parts.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  const chatItems = () => [...document.querySelectorAll("app-messaging-message-item")];
  function readMessages() {
    const out = [];
    let day = null;
    for (const it of chatItems()) {
      const head = it.querySelector(".Message-headerText, .Message-headerText--firstMessage");
      if (head) day = parseDay(getText(head)) || day;
      const bubble = it.querySelector(".Message-bubble");
      if (!bubble) continue;
      const mine = !!it.querySelector(".Message-bubbleActionsAnchor--fromLoggedInUser, .Message-history--fromLoggedInUser");
      const theirs = !!it.querySelector(".Message-bubbleActionsAnchor--fromOtherUser");
      let me = mine && !theirs;
      if (!mine && !theirs) {
        // No side class: yours sit on the right.
        const r = bubble.getBoundingClientRect(), list = (it.parentElement || it).getBoundingClientRect();
        me = r.left + r.width / 2 > list.left + list.width / 2;
      }
      const text = bubbleText(it, bubble);
      if (!text) continue;
      out.push({ me, text, when: whenText(day, bubbleTime(bubble)) });
    }
    return out;
  }
  // The box that scrolls the messages (Freelancer loads older ones at its top).
  function chatScroller() {
    const item = chatItems()[0];
    for (let el = item && item.parentElement; el && el !== document.body; el = el.parentElement) {
      const cs = getComputedStyle(el);
      if (/(auto|scroll|overlay)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 10) return el;
    }
    return null;
  }
  const say = (text) => { try { chrome.runtime.sendMessage({ type: "fl:progress", text }); } catch (e) {} };
  // Scrolls to the top until no older messages come (or enough() holds), then back down.
  async function loadOlder(enough) {
    const sc = chatScroller();
    if (!sc) return { top: true, rounds: 0 };
    let still = 0, rounds = 0;
    const firstKey = () => { const it = chatItems()[0]; return it ? (it.closest("[data-message-id]") || it).getAttribute("data-message-id") || getText(it).slice(0, 60) : ""; };
    for (; rounds < 600 && still < 3; rounds++) {
      if (enough && enough()) break;
      const n = chatItems().length, first = firstKey(), h = sc.scrollHeight;
      sc.scrollTop = 1;
      sc.scrollTop = 0;
      sc.dispatchEvent(new Event("scroll"));
      const grew = await waitFor(() => chatItems().length > n || firstKey() !== first || sc.scrollHeight > h + 5, 2500);
      still = grew ? 0 : still + 1;
      if (rounds % 3 === 0) say(`loading older messages: ${chatItems().length} so far`);
    }
    await sleep(300);
    sc.scrollTop = sc.scrollHeight;
    return { top: still >= 3, rounds };
  }
  // The chat as text. mode "all": every message (older ones loaded first); "last": the
  // client's messages after your latest one.
  async function chatCopy({ mode }) {
    if (!(await waitFor(() => chatItems().length, 5000))) return { ok: true, none: true, why: "No chat messages on this page: open a chat first." };
    let loaded;
    if (mode === "all") loaded = await loadOlder();
    else if (!readMessages().some((m) => m.me)) loaded = await loadOlder(() => readMessages().some((m) => m.me));
    const msgs = readMessages();
    let pick = msgs;
    if (mode !== "all") {
      const i = msgs.map((m) => m.me).lastIndexOf(true);
      pick = msgs.slice(i + 1).filter((m) => !m.me);
      if (!pick.length) return { ok: true, none: true, why: "No messages from the client after your last message." };
    }
    const line = (m) => `${m.me ? "I" : "client"} said "${m.text}"` + (m.when ? " : " + m.when : "");
    return { ok: true, text: "{\n" + pick.map(line).join("\n") + "\n}", count: pick.length, total: msgs.length, top: loaded ? loaded.top : null, noTime: pick.filter((m) => !/\d:\d\d$/.test(m.when)).length };
  }

  // ---------- 3+4) proposal, price, timeline ----------

  async function fill({ proposal, price, period }) {
    const box = proposalBox();
    if (!box) throw new Error("Proposal box not found");
    if (box.maxLength > 0 && proposal.length > box.maxLength) {
      throw new Error("Proposal is " + proposal.length + " characters, the box allows " + box.maxLength);
    }
    const priceIn = inputAfterLabel(PRICE_LABEL);
    const periodIn = inputAfterLabel(PERIOD_LABEL);
    if (!priceIn) throw new Error("Price input (Bid Amount / Hourly Rate) not found");
    if (!periodIn || periodIn === priceIn) throw new Error("Timeline input (Delivered in / Weekly Limit) not found");

    box.scrollIntoView({ block: "center" });
    typeText(box, proposal);
    await sleep(STEP);
    const tabbed = pressTab(box);
    await sleep(STEP);
    setValue(priceIn, String(price));
    await sleep(STEP);
    setValue(periodIn, String(period));
    await sleep(STEP);
    // Leaving the box once more saves its text into the form again (handleBlur),
    // so a proposal the form dropped meanwhile is restored or shows its error now.
    fireFocus(box);
    fireBlur(box);
    await sleep(150);

    // Make sure Freelancer took the proposal; one retry, else stop before Place Bid.
    let retried = false;
    if (proposalRejected(box, proposal)) {
      retried = true;
      retypeText(box, proposal);
      await sleep(STEP);
      pressTab(box);
      await sleep(300);
      if (proposalRejected(box, proposal)) {
        throw new Error("Freelancer did not accept the proposal text (it shows \"Please enter your proposal\"). Nothing was submitted.");
      }
    }
    return { ok: true, price: priceIn.value, period: periodIn.value, chars: box.value.length, tabbed, retried, errors: formErrors() };
  }

  // Right before Place Bid: Freelancer resets its bid form when some of its data
  // reloads (empty proposal, its default price and days), which can happen while the
  // box waits for the Place Bid time. Whatever no longer holds our value is filled
  // again. Returns the names of the fields that were refilled.
  // ifEmpty (review mode: you may have changed the bid by hand): only a form whose
  // proposal box is empty (Freelancer started it over) is filled again.
  const amount = (v) => parseFloat(String(v).replace(/[^\d.]/g, ""));
  const sameAmount = (el, v) => Math.abs(amount(el.value) - Number(v)) < 0.005;
  async function restoreForm({ proposal, price, period, ifEmpty }) {
    const restored = [];
    if (proposal == null) return restored;
    const box = proposalBox();
    if (ifEmpty && (!box || box.value.trim())) return restored;
    const priceIn = inputAfterLabel(PRICE_LABEL);
    const periodIn = inputAfterLabel(PERIOD_LABEL);
    if (box && box.value !== proposal) {
      typeText(box, proposal);
      await sleep(STEP);
      fireBlur(box);
      await sleep(STEP);
      restored.push("proposal");
    }
    if (priceIn && price != null && !sameAmount(priceIn, price)) {
      setValue(priceIn, String(price));
      await sleep(STEP);
      restored.push("price");
    }
    if (periodIn && periodIn !== priceIn && period != null && !sameAmount(periodIn, period)) {
      setValue(periodIn, String(period));
      await sleep(STEP);
      restored.push("timeline");
    }
    if (restored.length && box) {
      fireFocus(box);
      fireBlur(box);
      await sleep(150);
      if (proposalRejected(box, proposal)) throw new Error("Freelancer had reset the bid form and did not take the proposal again. Place Bid was not clicked.");
    }
    return restored;
  }

  // ---------- 4) optional upgrades ----------

  // Each upgrade row has a tag ("SPONSORED", maybe uppercase only through CSS) and
  // a description; the description is the fallback if the tag is not found.
  const UPGRADES = {
    sponsored: [/^\s*sponsored\s*$/i, /sponsoring will boost|sponsor(ed)? (your )?bid/i],
    sealed: [/^\s*sealed\s*$/i, /sealed entry|hide your bid from other/i],
    highlight: [/^\s*highlight(ed)?\s*$/i, /highlight your bid/i],
  };
  const COST = new RegExp("[$€£₹]?\\s*\\d[\\d,]*(?:\\.\\d+)?\\s*(?:" + CODES + ")\\b|\\bfree\\b", "i");
  const isChecked = (box) => (box instanceof HTMLInputElement ? box.checked : box.getAttribute("aria-checked") === "true");

  // The upgrade's row: the smallest box around its tag holding exactly one checkbox.
  function upgradeRow(tag) {
    for (let el = tag.parentElement, up = 0; el && up < 8; el = el.parentElement, up++) {
      const inputs = el.querySelectorAll("input[type=checkbox]");
      const boxes = inputs.length ? inputs : el.querySelectorAll("[role=checkbox]");
      if (boxes.length > 1) return null;
      if (boxes.length === 1) return { row: el, box: boxes[0] };
    }
    return null;
  }

  // want: { sponsored: true, sealed: false, ... }. Each upgrade found on the page is
  // ticked or unticked to match.
  async function upgrades({ want }) {
    // Part of the bid form: if the form is there, so is this section (when offered).
    const head = await waitFor(() => findText(/^\s*optional upgrades\s*$/i), 600);
    if (!head) return { ok: true, found: false, list: [] };
    const placeBtn = buttonByText(PLACE_BID);
    const list = [];
    for (const name of Object.keys(UPGRADES)) {
      if (!(name in want)) continue;
      let parts = null;
      for (const re of UPGRADES[name]) {
        const tag = findText(re, head);
        if (tag && (!placeBtn || follows(tag, placeBtn))) parts = upgradeRow(tag);
        if (parts) { parts.tag = tag; break; }
      }
      if (!parts) { list.push({ name, found: false }); continue; }
      const { row, box, tag } = parts;
      const item = { name, found: true, cost: (getText(row).replace(/\s+/g, " ").match(COST) || [""])[0] };
      if (isChecked(box) !== !!want[name]) {
        if (isDisabled(box)) item.disabled = true;
        else {
          row.scrollIntoView({ block: "center" });
          // The real box is often hidden behind a styled one; if a click on it does
          // not change it, click its label, the styled box next to it, then the tag.
          const label = box.id ? document.querySelector("label[for='" + CSS.escape(box.id) + "']") : null;
          for (const target of [box, label, box.closest("label"), box.nextElementSibling, tag]) {
            if (!target) continue;
            target.click();
            await sleep(120);
            if (isChecked(box) === !!want[name]) { item.changed = true; break; }
          }
        }
      }
      item.on = isChecked(box);
      list.push(item);
    }
    return { ok: true, found: true, list };
  }

  // ---------- 5+6) clarification board ----------

  // Freelancer shows the board in one of two ways (its project page code):
  // - the older page: a "Clarification Board" card with the question box in it;
  // - the redesigned page: a "Q&A" card in the side column (on a narrow page a "Q&A (2)"
  //   tag) that opens a side panel ("drawer", moved to the end of the page) holding the
  //   box ("Ask a question...") and Post. The box is there only while that panel is open.
  // Either way the box is Freelancer's comment form: its Post button shows once the box
  // is clicked or focused, and stays disabled while the box is empty. Only users Verified
  // by Freelancer get a box ("Users who are Verified by Freelancer can leave a question").
  const QA_LABEL = /^\s*q\s*&\s*a(\s*\(\d+\))?\s*$/i;
  const flat = (s) => (s || "").replace(/\s+/g, " ").trim();
  const visibleIn = (root, sel) => [...root.querySelectorAll(sel)].find(visible) || null;
  const buttonIn = (root, re) => [...root.querySelectorAll("button, [role='button']")].find((b) => re.test((b.innerText || "").trim()) && visible(b)) || null;
  const BOX = "textarea, [contenteditable='true']";
  // The board's question box in scope: the box of Freelancer's comment form (any box as
  // the fallback), never the bid's proposal box.
  function boxIn(scope, head) {
    const ok = (el) => visible(el) && (!head || follows(head, el)) && el.id !== "descriptionTextArea" && !el.closest("#descriptionTextArea");
    return [...scope.querySelectorAll("fl-comments-form textarea, fl-comments-form [contenteditable='true']")].find(ok) ||
      [...scope.querySelectorAll(BOX)].find(ok) || null;
  }
  // The open Q&A panel: the part with the questions and the box.
  const qaPanel = () => visibleIn(document, ".CommentsDrawerContainer");
  // What opens the Q&A panel. The page holds the Q&A card twice: in the header row for a
  // narrow page (where its "Q&A (2)" tag shows) and in the side column for a wide one
  // (where its card shows); the one on screen is used.
  function qaOpener() {
    for (const board of document.querySelectorAll("app-project-clarification-board-redesign")) {
      const own = visibleIn(board, "fl-card, fl-tag");
      if (own) return own;
    }
    const t = findText(QA_LABEL);
    return (t && t.closest("fl-card, fl-tag")) || null;
  }
  // "Users who are Verified by Freelancer can leave a question" (the words are split over
  // a few elements): you may not post.
  function boardLocked(root) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!/can leave a question/i.test(n.nodeValue) || !visible(n.parentElement)) continue;
      for (let el = n.parentElement, up = 0; el && up < 3; el = el.parentElement, up++) {
        if (/verified by freelancer\s*can leave a question/i.test(flat(el.textContent))) return true;
      }
    }
    return false;
  }

  // { scope, input, post, qa, opener, locked }, or null when the page has no board.
  // input: the question box (null while the Q&A panel is closed: opener opens it);
  // scope: the board's own card (or the open panel), so no other box on the page (e.g.
  // Freelancer's chat) is ever used.
  function boardParts() {
    const panel = qaPanel();
    if (panel) {
      const input = boxIn(panel);
      return { scope: panel, qa: true, input, post: input ? buttonIn(panel, /^post$/i) : null, locked: !input && boardLocked(panel) };
    }
    const head = findText(BOARD_LABEL);
    if (head) {
      const scope = head.closest("app-project-clarification-board, fl-card, section") || head.parentElement.parentElement || head.parentElement;
      const input = boxIn(scope, head);
      return { scope, input, post: input ? buttonIn(scope, /^post$/i) : null, locked: !input && boardLocked(scope) };
    }
    const opener = qaOpener();
    if (opener) return { scope: opener, qa: true, opener, input: null, post: null, locked: boardLocked(opener) };
    return null;
  }

  // After a bid Freelancer shows the project's Proposals tab, and on a wide page the Q&A
  // card is only in the Details tab's side column: with no board on the page, the Details
  // tab is opened for it. True when it was opened and shows the board.
  async function boardTab() {
    const t = tabItem(DETAILS_TAB);
    if (!t || boardParts()) return false;
    const a = t.querySelector("a[href]");
    if (a && new URL(a.getAttribute("href"), location.href).pathname.replace(/\/+$/, "") === location.pathname.replace(/\/+$/, "")) return false;
    return showTab(DETAILS_TAB, () => boardParts(), 6000);
  }

  // The board with its box ready: the Q&A panel opened (its card clicked), or a box that
  // shows only after an "Ask a question" button. Never clicks while the panel is open.
  async function openBoard(ms) {
    const parts = boardParts();
    if (!parts || parts.input || parts.locked) return parts;
    const opener = parts.opener || buttonIn(parts.scope, /ask a question|post a (question|message)|add a (question|message)/i);
    if (!opener) return parts;
    opener.scrollIntoView({ block: "center" });
    opener.click();
    return (await waitFor(() => { const p = boardParts(); return p && !p.opener && (p.input || p.locked) ? p : null; }, ms)) || boardParts();
  }

  // The box holds the question (its start: the page may change the line breaks).
  const holds = (input, text) => flat(valueOf(input)).startsWith(flat(text).slice(0, 80));

  // The questions on the board are Freelancer's fl-comment elements: the poster's avatar,
  // a header with "@name" (linked to /u/name), the text (p.CommentContent, a long one cut
  // short with "more") and the replies (fl-comment elements inside it). Other bidders
  // often post nearly the same question (their AI read the same project), so a question
  // counts as yours only when it is under your name and has your whole text.
  const boardComments = () => [...document.querySelectorAll("fl-comment")];
  // The first element in comment c that is its own, not a reply's.
  const ownPart = (c, sel) => [...c.querySelectorAll(sel)].find((el) => el.closest("fl-comment") === c) || null;
  const nameIn = (href) => {
    const m = (href || "").match(/^(?:https?:\/\/[^/]+)?\/u\/([^/?#]+)/i);
    if (!m) return "";
    try { return decodeURIComponent(m[1]).toLowerCase(); } catch (e) { return m[1].toLowerCase(); }
  };
  const titleOf = (el) => (el && (el.getAttribute("title") || "").trim().toLowerCase()) || "";
  // Who posted comment c: the "@name" in its header (its link, else its text), else the
  // name on its avatar picture (Freelancer puts the username in the picture's title).
  function commentUser(c) {
    const head = ownPart(c, "fl-comment-header");
    if (head) {
      for (const a of head.querySelectorAll("a[href]")) { const n = nameIn(a.getAttribute("href")); if (n) return n; }
      const m = flat(head.textContent).match(/@([\w.-]+)/);
      if (m) return m[1].toLowerCase();
    }
    return titleOf(ownPart(c, "fl-comments-user-avatar [title], fl-user-avatar [title]"));
  }
  // The text of comment c. Freelancer cuts a long one to a few lines (its flMaxLines cuts
  // the text itself and adds "… more"), so that ending is taken off.
  function commentText(c) {
    const p = ownPart(c, "fl-comment-content .CommentContent") || ownPart(c, "fl-comment-content");
    return p ? flat(p.textContent).replace(/\s*(?:…|\.\.\.)?\s*(?:read |show )?(?:more|less)$/i, "").replace(/\s*(?:…|\.\.\.)$/, "") : "";
  }
  // Comment text c (maybe cut short) is question t (both flattened).
  const sameText = (c, t) => !!c && !!t && (c === t || c.startsWith(t) || (t.startsWith(c) && c.length >= Math.min(t.length, 40)));
  // You: the username on your avatar next to the board's box (Freelancer's comment form
  // shows the viewing user's picture, its title the username; the form's @-mention
  // suggestions show other people's, so those are skipped), else the one on your bid in
  // the bid list. "" while not known (no picture, form not open, no bid yet).
  let myName = "";
  function whoAmI() {
    if (myName) return myName;
    for (const el of document.querySelectorAll("fl-comments-form fl-comments-user-avatar [title], fl-comments-form fl-user-avatar [title]")) {
      if (el.closest("fl-auto-complete, fl-auto-complete-suggestion-template")) continue;
      if (titleOf(el)) return (myName = titleOf(el));
    }
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!OWN_BID_ACTION.test(n.nodeValue)) continue;
      const card = n.parentElement.closest("app-bid-card");
      const name = card && [...card.querySelectorAll("a[href]")].map((a) => nameIn(a.getAttribute("href"))).find(Boolean);
      if (name) return (myName = name);
    }
    return "";
  }
  // How many of the board's questions are question text: yours (null while it is not
  // known who you are) and anyone's.
  function tally(text) {
    const t = flat(text), who = whoAmI();
    let all = 0, yours = 0;
    for (const c of boardComments()) {
      if (!sameText(commentText(c), t)) continue;
      all++;
      if (who && commentUser(c) === who) yours++;
    }
    return { all, yours: who ? yours : null };
  }
  // Is question text on the board already (you posted it, e.g. by hand while paused)? By
  // your name; while it is not known who you are, only a copy that came up after the
  // question was first typed here counts (one there before is someone else's).
  const firstCount = new Map();
  function alreadyUp(text) {
    const key = flat(text);
    if (!key) return false;
    const n = tally(text);
    if (n.yours != null) return n.yours > 0;
    if (!firstCount.has(key)) { firstCount.set(key, n.all); return false; }
    return n.all > firstCount.get(key);
  }

  // Types the question into the board's box. When the project's data reloads (right after
  // a bid, for one) Freelancer can start the form over or close the Q&A panel, and what
  // was just typed is gone. So the text must still be in the box a moment after typing;
  // if not, the panel is opened again if needed and the text typed again (three tries).
  // found false: no board you can post on (locked: you are not Verified; qa: the board is
  // the Q&A panel, panel: it opened but shows no box). A Q&A panel opened for nothing is
  // closed again. already: your question is on the board already (you posted it; see
  // alreadyUp): nothing typed, so it is never posted twice. Checked with the board open
  // (the Q&A panel holds all its questions and your avatar).
  async function clarifyFill({ text }) {
    const wasOpen = !!qaPanel();
    await boardTab();
    let parts = await openBoard(4000);
    if (!parts) return { ok: true, found: false, diag: boardInfo() };
    if (parts.locked || !parts.input) {
      const diag = boardInfo();
      const panel = !!qaPanel();
      if (panel && !wasOpen) await closeQa();
      return { ok: true, found: false, locked: !!parts.locked, qa: !!parts.qa, panel, diag };
    }
    if (alreadyUp(text)) {
      const closed = parts.qa && !wasOpen ? await closeQa() : null;
      return { ok: true, found: true, already: true, qa: !!parts.qa, closed, who: whoAmI() };
    }
    const gone = (qa) => new Error("Clarification board: the question box went away" + (qa ? " (Freelancer's Q&A panel closed and did not open again)" : ""));
    for (let tries = 1; ; tries++) {
      const box = parts.input;
      box.scrollIntoView({ block: "center" });
      // The click (and the focus while typing) is what shows Freelancer's Post button.
      box.click();
      // Text already in the box (typed before, but Freelancer's form did not take it) is
      // deleted first, so typing the same text again is a change its form sees.
      if (box instanceof HTMLTextAreaElement && box.value) {
        fireFocus(box);
        box.select();
        try { document.execCommand("delete"); } catch (e) {}
      }
      if (box instanceof HTMLTextAreaElement) typeText(box, text);
      else setValue(box, text, true);
      await sleep(700);
      const now = await openBoard(3000);
      if (now && now.input && holds(now.input, text)) {
        if (!(await activePost(3000))) throw new Error("Clarification board: the Post button did not become active");
        return { ok: true, found: true, tries, qa: !!now.qa };
      }
      if (tries === 3) throw now && now.input ? new Error("Clarification board: Freelancer emptied the box after the question was typed (3 tries)") : gone(parts.qa);
      // A Q&A panel that closed and did not open at once gets one more chance.
      const qa = !!parts.qa;
      parts = now && now.input ? now : await openBoard(3000);
      if (!parts || !parts.input) throw gone(qa);
    }
  }

  // Right after a bid Freelancer reloads the project (its bid count goes up), and that
  // can start the board's form over (see clarifyFill). Wait for it (at most 6 s; without
  // a count, 3 s), then a little longer, before the question is typed. No board you can
  // post on (none on the page, or you are not Verified): nothing to wait for.
  async function afterBid({ bids }) {
    const t0 = Date.now();
    const ready = () => { const p = boardParts(); return p && (p.input || p.opener || p.locked) ? p : null; };
    let parts = await waitFor(ready, 1000);
    // On the Proposals tab (where Freelancer goes after a bid) the board may be on Details.
    if (!parts && await boardTab()) parts = ready();
    if (!parts || parts.locked) return { ok: true, noBoard: true, locked: !!(parts && parts.locked), ms: Date.now() - t0 };
    let countUp = false;
    if (bids == null) await sleep(3000);
    else countUp = !!(await waitFor(() => { const n = bidCount(); return n != null && n > bids; }, 6000));
    await sleep(800);
    return { ok: true, countUp, ms: Date.now() - t0 };
  }

  // The Post button shows once the box has focus, so focus it first.
  async function activePost(ms) {
    const parts = boardParts();
    if (parts && parts.input) fireFocus(parts.input);
    return waitFor(() => {
      const p = boardParts();
      return p && p.post && !isDisabled(p.post) ? p.post : null;
    }, ms);
  }

  // Closes the Q&A panel the way its X does. Only once: Freelancer's panel closes by going
  // back one step in the tab's history (it added one when it opened), so a second close
  // while it slides away would go back a page.
  async function closeQa() {
    const panel = qaPanel();
    if (!panel) return true;
    const x = visibleIn(panel.closest(".DrawerContainer") || document, ".DrawerCloseButton");
    if (x) x.click();
    else {
      const host = document.querySelector("fl-drawer.IsActive");
      if (!host) return false;
      host.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true }));
    }
    return !!(await waitFor(() => !qaPanel(), 2500));
  }

  // text: the question the box filled; it must still be in the box right before Post.
  // Review mode sends retype instead (the question as ChatGPT wrote it): you may have
  // changed the question in its box, so text in the box is posted as it is; a box that is
  // empty or gone (Freelancer emptied it, or the Q&A panel was closed) gets the question
  // typed again first (retyped). After Post (see sendQuestion): shown = your question is
  // on the board under your name; confirmed = Freelancer sent it; reset = the box emptied
  // without it being sent (Freelancer's form started over), and that happened again after
  // one more try (resent). The Q&A panel is closed after a question that shows.
  async function clarifyPost({ text, retype } = {}) {
    let parts = boardParts();
    let retyped = false;
    if (retype && parts && !parts.locked && (!parts.input || !valueOf(parts.input).trim())) {
      const f = await clarifyFill({ text: retype });
      if (f.already) {
        // The Q&A panel is closed as after a post (once: clarifyFill may have closed it).
        const closed = f.closed != null ? f.closed : qaPanel() ? await closeQa() : null;
        return { ok: true, confirmed: true, shown: true, already: true, qa: !!(f.qa || parts.qa), closed, who: whoAmI() };
      }
      if (f.found) { text = retype; parts = boardParts(); retyped = true; }
      else if (f.locked) throw new Error("Freelancer lets only users Verified by Freelancer post on its clarification board");
    }
    if (!parts || !parts.input) throw new Error(parts && parts.qa ? "Freelancer's Q&A panel (its clarification board) did not open" : "Clarification board not found");
    if (!valueOf(parts.input).trim()) throw new Error("Clarification board box is empty");
    if (text && !holds(parts.input, text)) throw new Error("Clarification board box no longer holds the question (Freelancer cleared it)");
    // The same question already up under your name (you posted it while paused): the
    // box's copy is not posted again.
    if (alreadyUp(valueOf(parts.input))) {
      const closed = parts.qa ? await closeQa() : null;
      return { ok: true, confirmed: true, shown: true, already: true, qa: !!parts.qa, closed, who: whoAmI() };
    }
    let post = await activePost(3000);
    if (!post && retype && !retyped) {
      // Text in the box, but Post stays off: Freelancer's form did not take that text.
      const f = await clarifyFill({ text: retype });
      if (f.found) { text = retype; parts = boardParts(); retyped = true; post = await activePost(3000); }
    }
    if (!post || !parts || !parts.input) throw new Error("Clarification board: the Post button did not become active");
    const qa = !!parts.qa;
    let r = await sendQuestion(post, parts);
    let resent = false;
    if (r.cleared && !r.sent && !r.shown) {
      // The box emptied but Freelancer never sent the question: its form started over (the
      // project's data reloaded). Typed again and posted once more.
      resent = true;
      try {
        const f = await clarifyFill({ text: r.text });
        if (f.already) r = { cleared: true, sent: true, shown: true };
        else if (f.found) {
          parts = boardParts();
          post = await activePost(3000);
          if (post && parts && parts.input) r = await sendQuestion(post, parts);
        }
      } catch (e) {}
    }
    const diag = r.shown ? undefined : boardInfo();
    if (!r.cleared && !r.shown) return { ok: true, confirmed: false, qa, retyped, resent, errors: r.errors, diag };
    const closed = qa && r.shown ? await closeQa() : null;
    return { ok: true, confirmed: !!r.sent, shown: !!r.shown, reset: !r.sent, qa, closed, retyped, resent, diag, who: whoAmI() };
  }

  // One Post click. Freelancer's Post button is busy (its fl-button data-busy="true", the
  // button disabled) while the question is sent; on success the box empties and the
  // question shows under your name. A box that empties without the button going busy
  // means Freelancer's form started over and nothing was sent.
  // { cleared, sent, shown, text, errors }.
  async function sendQuestion(post, parts) {
    const box = parts.input, text = valueOf(box);
    const before = tally(text);
    const host = post.closest("fl-button");
    const busy = () => (!!host && host.getAttribute("data-busy") === "true") || (post.isConnected && isDisabled(post) && box.isConnected && !!valueOf(box).trim());
    const formErrors = () => [...((boardParts() || parts).scope).querySelectorAll("fl-comments-form-error")].filter(visible).map(getText).filter(Boolean);
    const mine = () => { const n = tally(text); return n.yours != null ? n.yours > before.yours : n.all > before.all; };
    let sent = false;
    post.click();
    const end = await waitFor(() => {
      if (busy()) { sent = true; return null; }
      const now = boardParts();
      if (!now || !now.input || !valueOf(now.input).trim()) return "cleared";
      return formErrors().length ? "error" : null;
    }, 10000);
    if (end !== "cleared") {
      const shown = mine();
      return { cleared: false, sent: sent || shown, shown, text, errors: [...formErrors(), ...errorTexts()].slice(0, 5) };
    }
    const shown = !!(await waitFor(mine, sent ? 10000 : 6000));
    return { cleared: true, sent: sent || shown, shown, text };
  }

  // What the board looks like, for the log when the question does not go up: so the
  // next fix can follow Freelancer's page.
  function boardInfo() {
    const d = (el) => !el ? "none" : el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") +
      (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).slice(0, 3).join(".") : "") +
      (visible(el) ? "" : "[hidden]") + (isDisabled(el) || el.getAttribute("disabled") === "true" ? "[disabled]" : "");
    const cards = [...document.querySelectorAll("app-project-clarification-board-redesign")];
    let p = null;
    try { p = boardParts(); } catch (e) {}
    return [
      "page " + location.pathname + ", " + innerWidth + " px wide" + (document.hasFocus() ? "" : ", page not focused") + (document.visibilityState === "visible" ? "" : ", tab hidden"),
      "Clarification Board heading: " + (findText(BOARD_LABEL) ? "shown" : "none") + ", older board: " + document.querySelectorAll("app-project-clarification-board").length +
        ", Q&A boards: " + cards.length + (cards.length ? " (" + cards.map((c) => [...c.querySelectorAll("fl-card, fl-tag")].slice(0, 2).map(d).join(" ")).join(" | ") + ")" : ""),
      "Q&A panel open: " + (qaPanel() ? "yes" : "no") + ", 'Verified by Freelancer can leave a question' shown: " + (boardLocked(document.body) ? "yes" : "no"),
      "board found: " + (p ? (p.qa ? "Q&A" : "card") + ", box " + d(p.input) + (p.input ? " holding " + valueOf(p.input).length + " chars" : "") + ", Post " + d(p.post) + (p.opener ? ", opener " + d(p.opener) : "") : "nothing"),
      "comment forms: " + document.querySelectorAll("fl-comments-form").length + ", text boxes on screen: " + ([...document.querySelectorAll("textarea")].filter(visible).slice(0, 6).map(d).join(" ") || "none"),
      "you: " + (whoAmI() ? "@" + whoAmI() : "not known (no avatar picture by the box, no bid card)") + ", questions on the board: " + boardComments().length +
        " (last by " + (boardComments().slice(-3).map((c) => "@" + (commentUser(c) || "?")).join(", ") || "nobody") + ")",
    ].join("\n");
  }

  // ---------- 7) Place Bid ----------

  const FAILED = /failed to create bid/i;
  // Placed: your own bid card is on the page (its Retract / Edit actions), or
  // Freelancer says so. (findText, not the page's innerText: that is slow on a long bid list.)
  // Freelancer's own sign of a new bid: right after it, it takes the page to the project's
  // Proposals tab with the bid's id in the address ("?bidCreated=<id>").
  const bidCreated = () => /[?&]bidCreated=\d/.test(location.search);
  const bidPlaced = () => bidCreated() || ownBidCard() || !!buttonByText(/^(update bid|retract bid)$/i) ||
    !!findText(/your bid (has been|was) (placed|submitted)|bid (placed|submitted) successfully/i);
  const failureText = (el) => getText(el.parentElement || el).replace(/\s+/g, " ").slice(0, 200);
  const openDialog = () => [...document.querySelectorAll("[role='dialog'], fl-modal")].find(visible);

  // Waits for the result of one Place Bid click. oldFailure is a "Failed to create
  // bid" banner already on the page before the click, so it is not mistaken for a new one.
  async function bidResult(oldFailure) {
    const path = location.pathname;
    let goneSince = 0;
    for (const t0 = Date.now(); Date.now() - t0 < 20000; ) {
      await sleep(200);
      if (bidPlaced()) return { confirmed: true };
      const f = findText(FAILED);
      if (f && f !== oldFailure) return { confirmed: false, failed: true, errors: [failureText(f), ...errorTexts()] };
      // Freelancer removes the bid form once the bid is in (your card may be further
      // down a long bid list). Same page, no dialog, form gone for 1.5 s: placed.
      const gone = location.pathname === path && !proposalBox() && !buttonByText(PLACE_BID) && !openDialog();
      if (!gone) goneSince = 0;
      else if (!goneSince) goneSince = Date.now();
      else if (Date.now() - goneSince >= 1500) return { confirmed: true, how: "the bid form closed" };
    }
    const f = findText(FAILED);
    const dialog = openDialog();
    return { confirmed: false, failed: !!f, errors: f ? [failureText(f)] : [...formErrors(), ...errorTexts()].slice(0, 5), dialog: dialog ? getText(dialog).slice(0, 300) : "" };
  }

  // msg: { proposal, price, period } as filled (none in review mode: the page is
  // left as the user checked it).
  async function placeBid(msg) {
    if (alreadyBid()) throw new Error("This project already has your bid");
    // The bid form is on the project's Details tab (you may have opened Proposals while
    // the box waited for you): that tab is opened first.
    if (!buttonByText(PLACE_BID) && tabItem(DETAILS_TAB)) await showTab(DETAILS_TAB, () => buttonByText(PLACE_BID), 8000);
    const restored = await restoreForm(msg);
    let first = null;
    // A second click only after Freelancer itself answered "Failed to create bid".
    for (let attempt = 1; attempt <= 2; attempt++) {
      const btn = buttonByText(PLACE_BID);
      if (!btn) throw new Error("Place Bid button not found");
      const label = getText(btn).replace(/\s+/g, " ");
      if (isDisabled(btn)) throw new Error("Place Bid is disabled. " + [...formErrors(), ...errorTexts()].slice(0, 5).join(" | "));
      // Save the proposal into the form right before submitting: this blur is what
      // a manual Tab or click elsewhere does (see fireFocus).
      const box = proposalBox();
      if (box) { fireFocus(box); fireBlur(box); await sleep(150); }
      const proposalErr = findText(PROPOSAL_ERROR);
      if (proposalErr) throw new Error("Freelancer shows \"" + getText(proposalErr) + "\". Place Bid was not clicked.");
      // A value Freelancer refuses (shown in red under its field): the bid would fail.
      const errs = formErrors();
      if (errs.length) throw new Error("Freelancer shows: " + errs.join(" | ") + ". Place Bid was not clicked.");
      btn.scrollIntoView({ block: "center" });
      await sleep(STEP);
      const oldFailure = findText(FAILED);
      btn.click();
      const r = await bidResult(oldFailure);
      if (r.confirmed || !r.failed || attempt === 2) return Object.assign({ ok: true, attempts: attempt, firstError: first, button: label, restored }, r);
      first = (r.errors || []).join(" | ");
      await sleep(400);
    }
  }

  const handlers = {
    "fl:ping": async () => ({ ok: true, build: BUILD, visible: document.visibilityState === "visible" }),
    "fl:extract": extract,
    // Quick look for the box while idle: bid count and anything that blocks a bid.
    // loaded + !hasForm (and no blocker) lets the box say "No bid form".
    // board: "locked" when only Verified users may post there (the box says so before Start).
    "fl:check": async () => {
      const b = boardParts();
      // page: which buttons the box shows ("project", "messages" or "other").
      const page = /^\/projects\//.test(location.pathname) ? "project" : /^\/messages(\/|$)/.test(location.pathname) ? "messages" : "other";
      if (page !== "project") return { ok: true, build: BUILD, url: location.href, page };
      const card = projectCard();
      return {
        ok: true, build: BUILD, bids: bidCount(), blocker: blocker(), url: location.href, nda: !!ndaLink(), page,
        loaded: !!card, hasForm: !!(proposalBox() || findText(PROPOSAL_LABEL)),
        board: !b ? "none" : b.locked ? "locked" : b.qa ? "qa" : "card",
        // Which project the page shows (auto bid: a new address may still show the last
        // one for a moment), its title and skills (the box shows how many are yours).
        projectId: shownProjectId(), title: card ? findTitle() : "", skills: card ? findSkills(card) : [], client: card ? clientInfo() : null,
      };
    },
    "fl:details": details,
    "fl:proposal": myProposal,
    "fl:chat": chatCopy,
    "fl:skills": async () => ({ ok: true, skills: findSkills(projectCard()) }),
    "fl:updates": async () => ({ ok: true, count: updatesCount(), button: !!updatesButton(), url: location.href }),
    "fl:feed": feed,
    "fl:feedClose": feedClose,
    "fl:goto": gotoProject,
    // While the box waits for you (review, an NDA to sign): did you place the bid?
    // formGone: the bid form closed (your card may be further down a long bid list);
    // failed: Freelancer's "Failed to create bid" message (e.g. the NDA is not signed yet).
    "fl:ownBid": async () => {
      const f = findText(FAILED);
      const parts = boardParts();
      return {
        ok: true, url: location.href, placed: bidPlaced(),
        formGone: !proposalBox() && !buttonByText(PLACE_BID) && !openDialog(),
        failed: f ? failureText(f) : "",
        boardText: !!(parts && parts.input && valueOf(parts.input).trim()),
        // What the board's box holds (you may have changed the question), for the post
        // after your own Place Bid.
        boardValue: parts && parts.input ? valueOf(parts.input).trim().slice(0, 8000) : "",
      };
    },
    // Last resort when the NDA link has no address the box can open itself.
    "fl:openNda": async () => {
      const l = ndaLink();
      if (!l) throw new Error("The Non-Disclosure Agreement link is not on the page");
      l.click();
      return { ok: true };
    },
    "fl:fill": fill,
    "fl:upgrades": upgrades,
    // A board step that fails says what the board looked like (diag, for the log).
    "fl:clarifyFill": (m) => clarifyFill(m).catch((e) => { e.diag = boardInfo(); throw e; }),
    "fl:clarifyPost": (m) => clarifyPost(m).catch((e) => { e.diag = boardInfo(); throw e; }),
    "fl:afterBid": afterBid,
    "fl:placeBid": placeBid,
    "fl:retire": async () => { retire(); return { ok: true }; },
  };
  const listener = (msg, _sender, reply) => {
    const h = handlers[msg && msg.type];
    if (!h) return false;
    h(msg).then(reply, (e) => reply({ ok: false, error: e && e.message ? e.message : String(e), diag: e && e.diag }));
    return true;
  };
  function retire() {
    try { chrome.runtime.onMessage.removeListener(listener); } catch (e) {}
    if (window.__flbidFl === me) window.__flbidFl = null;
  }
  const me = {
    build: BUILD,
    alive: () => { try { return !!chrome.runtime.id; } catch (e) { return false; } },
    retire,
  };
  window.__flbidFl = me;
  chrome.runtime.onMessage.addListener(listener);
})();
