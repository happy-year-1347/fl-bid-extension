# FL Bid Assistant

Chrome extension that bids on a Freelancer project from a small box on the project page:

1. reads the project details
2. sends them to your ChatGPT bid chat and waits for the proposal
3. fills "Describe your proposal", then presses Tab
4. fills price and timeline from your Prices table, then ticks the bid upgrades chosen in the panel
5. clicks Place Bid: 15 seconds after Start if the project has no bids yet, right away if it already has bids (both set in the panel)
6. fills the Clarification Board box with the question ChatGPT wrote meanwhile, and clicks Post

On a project whose NDA must be signed first, step 5 is yours: see "NDA projects" below.

One message to ChatGPT per bid: it writes the proposal and then the clarification question in one answer. That is the order with "Pause for review" off, the fastest: the box takes the proposal as soon as ChatGPT has written it (its QUESTIONS line follows) and fills and places the bid while ChatGPT is still writing the question in that same answer; the question is posted right after the bid. With "Pause for review" on, the box waits for the whole answer, everything is filled, you check it, and Continue posts the question first and then places the bid.

If the ChatGPT chat is not on screen (another tab, no split view), the box brings it to the front once, waits for the whole answer there and goes back to the Freelancer page: one trip, not two.

## Install

1. Open `chrome://extensions`, turn on **Developer mode**.
2. **Load unpacked** and pick this `fl-bid-extension` folder.
3. Pin the extension; clicking its icon shows or hides the box on the Freelancer page.

After editing any file, press the reload icon on the extension card. Open Freelancer tabs get the new box by themselves; if one does not, reload that tab.

## Use

1. Put the Freelancer project and your ChatGPT bid chat side by side (Chrome split view), or at least in the same window.
2. Press **Start** in the box (top right of every Freelancer project page). It bids on that page, uses that ChatGPT chat (in split view also a new, empty one) and never opens a new ChatGPT tab (a new chat every 20 bids, if set up, opens in that same tab). In split view nothing switches; if ChatGPT is a hidden tab, it is brought to the front while it writes, then Freelancer comes back.
   Under Start, **Sponsored**, **Highlight** and **Sponsored + Highlight** start the same bid with those bid upgrades: Sponsored only, Highlight only, or both (the other one off). Start itself uses the upgrades ticked in Settings; Sealed always comes from Settings.
3. **Stop** cancels at any point (it also stops ChatGPT mid-answer). It cannot undo a Post or Place Bid that already happened.

Keyboard shortcut: **Alt+S** works like the Start button (and like Continue while paused for review). It works anywhere in the window, also with the ChatGPT pane focused: it goes to the Freelancer project tab (the active one, its split view partner, or the most recent one), and shows the box if it was hidden. Change it in `chrome://extensions/shortcuts` (or Settings > Change in the box). If the box shows "Shortcut: not set", another extension already uses Alt+S: pick a different key there.

The box shows only Start, the three upgrade start buttons, Stop and Settings; **Settings** widens it with the options below, the last bid, the ChatGPT instructions and the log. Drag the box by its blue top bar (the position is remembered); "-" or the toolbar icon hides it. Hiding does not stop a bid in progress. The bid runs inside the Freelancer page, so reloading that page during a bid ends the bid.

Speed: every step goes on as soon as the page is ready (no fixed pauses). The project is read as soon as it shows on the page, without waiting for Freelancer's images and trackers to finish loading. While the box is idle it loads its ChatGPT helper into the chat tab in advance. The log (Settings > Log) times each step: "Read the project in 0.1 s", "Prompt ready 0.2 s after Start", "ChatGPT: prompt typed in 0.1 s, sent in 0.1 s (send button), started writing 4.2 s after sending, done 3.1 s later, read from the page", "Filled in 0.4 s". If "sent" says "Enter key" or takes about 1 s, ChatGPT's Send button was not recognised: send that log line.

Almost all of the time is ChatGPT's own: how long it takes before it starts writing, and how long it writes. The log says so in amber when it is long: "ChatGPT needed 12.0 s before writing" (a "Thinking" model or a busy ChatGPT; a model without Thinking starts sooner).

Every bid goes into the ChatGPT chat you have open next to Freelancer. **New ChatGPT chat** (Settings > New ChatGPT chat): paste your bid creation prompt there and set "New chat after" (default 20 bids). After the bid that makes it 20 bids in that chat, the box deletes the chat (ChatGPT's own Delete in the chat's "..." menu), opens a new chat in the same place (inside your ChatGPT project or GPT if the chat is in one, else ChatGPT's home), sends your bid creation prompt there and waits for ChatGPT's reply, so the next bid starts in a fresh chat that has your strategy: "Done. Bid placed, clarification question posted. New ChatGPT chat ready." It deletes only the chat that bid went to, and only when that chat holds at least that many bid prompts from the box (their "(ref:...)" line), never another chat. A deleted chat cannot be brought back. If the delete does not work (e.g. ChatGPT changed its menu), the status says so and the bids stay in the same chat. At Start, a new, empty chat gets your prompt first, and a chat that already holds 20 or more bids is renewed before the bid. With the prompt empty, or 0 bids, the box never makes a new chat. The prompt stays in your browser (the extension's storage), not in the extension files. (ChatGPT gets slower as a chat grows; the line under the status shows how many bids the chat holds.)

What the status shows while ChatGPT works: "2/7 Connecting to ChatGPT...", "typing the prompt", "sending", "looking for your message in the chat", "thinking" (ChatGPT has not started writing), "writing the bid, 640 chars", each with the seconds since the prompt went out. If ChatGPT shows its own "Skip" / "Answer now" control while it thinks, the box clicks it ("thinking skipped" in the log). After each bid the line under the status says where ChatGPT's time went: "ChatGPT 3.6 s = send 0.2 + think 2.2 + write 1.3 · bid 7 of 20 in this chat" ("30 earlier bids in this chat" with New ChatGPT chat off; amber when ChatGPT thought for over 8 s), with the ChatGPT model name when its header shows one.

While ChatGPT writes, the status counts up: "2/7 ChatGPT: writing the bid, 640 chars (7 s)". The answer is read from ChatGPT's message markup when it is recognised, else from the page right after your prompt, which also finds a prompt split over several elements; a hidden copy of the prompt or a screen-reader copy cannot hide the answer. Reading the whole page text is the last resort only (in a long chat it is slow and holds up ChatGPT's own page).

Never a silent stop: every step has a time limit and ends with a message in the status line. If the prompt does not show in the chat within 30 s, or ChatGPT gives no reply for 2 minutes, the run stops with that message and nothing is filled. On any ChatGPT problem the log also gets "Page details" (where the prompt and answer sit on ChatGPT's page): press **Copy log** and send it.

Checks before anything is submitted:
- **Proposal length**: Freelancer accepts 100 to 1500 characters (its bid form refuses more). The prompt tells ChatGPT the limit; if the proposal is still longer, ChatGPT is asked once, in the same chat, to shorten it ("asking ChatGPT to shorten it" in the log). Still too long, too short, or with an email address in it: the run stops before filling.
- **Freelancer's red messages** under the bid fields (e.g. "You must have at least 3 reviews ... to place a bid greater than ..."): the run stops before Place Bid with that text. With Pause for review on, it is shown in the log and you can fix the field before Continue.
- **Form reset**: Freelancer sometimes resets its bid form while the page waits (empty proposal, its default price and days). Right before Place Bid the box checks the form and fills what was lost again ("Freelancer had reset the bid form ..." in the log). With Pause for review on, the page is left as you checked it.
- **Bid placed** is confirmed by your bid card appearing (Edit / Retract), "Update Bid", or the bid form closing on the same page.

Stop works at any moment and returns at once; only a Post or Place Bid click already under way is waited for, so the log says what really happened.

After an update, the scripts the box put into the open Freelancer and ChatGPT tabs are replaced by the new ones on the next Start (no tab reload needed).

Notices: the box checks the project page every few seconds and shows, under Start and in its top bar, when the project cannot be bid on: **Already bid** (amber: your bid is on the page, i.e. your card in the bid list with its "Retract" / "Edit" actions, or the "Update Bid" form), **No bid form** (amber: the project shows no bid form for 3 s, which usually means you already bid and your card is further down a long bid list, or bidding is closed), **No bids left** (red), **Verified only** (Verified by Freelancer required, e.g. projects of $2,500 and over), **Preferred only** (Preferred Freelancers only), **Bidding restricted** or **Sign agreement first** (red: "The client requires you to sign an agreement"). Hover the notice for Freelancer's full message. Start on such a project stops at once, before ChatGPT is asked. Under the status the box shows the project's bid count and when Place Bid will be clicked, counted from the Start click ("Bids: 0, Place Bid at 15 s").

"You must sign the IP Agreement to work on this project" is ignored: the bid goes ahead as usual.

**NDA projects** ("You must sign the Non-Disclosure Agreement to work on this project"; amber notice **NDA to sign**, "Place Bid: you, after signing the NDA"): Freelancer refuses a bid until the NDA is signed. Start writes and fills the bid as usual, then opens the banner's "Non-Disclosure Agreement" link in a new tab and does not click Place Bid. Sign the NDA there, come back and click **Place Bid** yourself: the box sees your bid and shows "Done. Bid placed." (with "Pause for review" off it then posts the clarification question). **Continue** instead of your own click lets the box place the bid. If you click Place Bid before signing, the status shows Freelancer's refusal and the box keeps waiting. If the project shows no bid form until the NDA is signed, Start only opens the NDA and stops: sign it, reload the project page and press Start.

Options:
- **Pause for review**: stops after filling everything; check the page, then press **Continue** to Post and Place Bid. Untick it for a fully automatic run. While paused you can still change the price or anything else on the page by hand, or click **Place Bid** yourself: the box sees your bid and shows "Done. Bid placed." (the clarification question stays in its box until you click Post).
- **Seconds from the Start click to the Place Bid click**: one for projects with no bids yet (default 15 s), one for projects that already have bids (default 0). This is the total time, not an extra wait: reading the project, ChatGPT and filling happen within it, and the box only waits for what is left (ChatGPT 8 s + filling 1 s -> waits 6 s -> Place Bid at 15 s). If the steps take longer, Place Bid is clicked right away. If the bid count cannot be read, the no-bids time is used.
- **Post a clarification board question**: untick to skip the question (ChatGPT then writes none). With review off the question is posted after the bid; if anything goes wrong with it there (no board on the page, ChatGPT problem, Stop), the bid stays placed and the log says the question was not posted. It is only posted when the bid was confirmed. Right after a bid Freelancer reloads the project, and that empties its Clarification Board box (the board's form starts over), so the box first waits for that (the bid count going up, at most about 7 s), types the question, checks it is still in the box before Post, and reports "posted" only when the question shows on the board; otherwise the status says to check the board.
- **Bid upgrades** (Sponsored, Sealed, Highlight): what Start uses (the Sponsored / Highlight buttons decide those two for their own bid). Set after the proposal, price and timeline. Each upgrade on the page is ticked or unticked to match the panel, so an upgrade the page ticked by itself is unticked when it is off here. The log shows each one's state and price. Upgrades not offered on a project are skipped with a warning; if one cannot be unticked, the run stops before Place Bid.

## Pricing

Edit your prices in Settings > **Prices**: one table for fixed projects (budget from, to, your bid, days) and one for hourly ones (rate from, to, your bid per hour, hours per week). Changes are saved as you type; rows with a mistake turn red and are not used; **Reset prices** goes back to the built-in tiers in `pricing.js` (`FL_RULES`). The tier is picked by the client's minimum budget; a budget with only a minimum ("$50.00+ AUD per hour", common on recruiter projects) uses that minimum. USD, EUR, GBP, AUD, CAD, NZD and SGD use the numbers as-is (a $30-250 AUD project gets 150 AUD). Other currencies (INR, PHP, ...) are converted with the rough rates in `FL_USD_RATE`. If the rule price is below the client's minimum it is raised to the minimum. A budget outside every tier (e.g. $10-30, £20-250) uses the nearest tier, and its price is kept inside the client's range: a $10-30 project gets a 30 USD bid, 3 days. The log line says when this happened.

## The ChatGPT reply format

The instructions in Settings are yours to edit. The panel always adds a fixed "ANSWER FORMAT" block at the end asking ChatGPT for `[[PROPOSAL]]`, `[[QUESTIONS]]` and `[[END]]` marker lines (described in words, so only the answer contains them literally) and a proposal of 100 to 1500 characters (Freelancer's limit), and a first line `Freelancer project <project name> (ref:...)` it uses to find this exact message in the chat.

For speed the block also asks ChatGPT to answer at once from the text (no web search, no opening links, no other tools) and to write the proposal first, then the clarification board post of at most 3 questions. With review off the box takes the proposal from the answer as soon as the QUESTIONS line follows it, so the bid does not wait for the post; the rest of the same answer is read after the bid (no second message). With "Post a clarification board question" off, the QUESTIONS line holds just "none"; the QUESTIONS marker always stays, so a post ChatGPT writes anyway can never end up in the proposal. A proposal over 1500 characters is the only case with a second message (asking to shorten it; the first answer's question is kept). The prompt holds no link to the project (a link made ChatGPT search the web before answering). Marker lines inside your instructions or the project text are reworded, so they can never be mistaken for the answer. Only a complete answer is used: if ChatGPT's reply has no `[[PROPOSAL]]` marker, or stops before its `[[END]]` line, the run stops and nothing is filled (ChatGPT's own screen text such as "You're using the free version of ChatGPT" or "Response complete" is never taken into a proposal).

After updating the files, reload the extension in `chrome://extensions`; the version shows next to the panel title.

## If Freelancer or ChatGPT change their pages

- ChatGPT selectors: `SEL` at the top of `content/chatgpt.js`; the chat menu, Delete and its confirm button for a new chat: `CHAT_SEL` further down.
- After changing `content/chatgpt.js` or `content/freelancer.js`, change `BUILD` at its top and `SCRIPT_BUILD` in `panel.js` to the same new value, so open tabs get the new file.
- Freelancer labels: the `*_LABEL` patterns at the top of `content/freelancer.js` (matched by visible text, e.g. "Bid Amount", "Weekly Limit", "Clarification Board").
