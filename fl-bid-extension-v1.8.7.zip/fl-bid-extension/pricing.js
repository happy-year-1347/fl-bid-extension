// Price / timeline rules, in USD. A project's tier is picked by the client's
// MINIMUM budget: "from" is inclusive, "to" is exclusive. Standard Freelancer
// ranges ($30-250, $250-750, ... $20,000-50,000) each land on one tier.
// "period" is days for fixed projects and hours per week for hourly ones.
var FL_RULES = {
  fixed: [
    { from: 30, to: 250, price: 150, period: 3 },
    { from: 250, to: 750, price: 350, period: 5 },
    { from: 750, to: 1500, price: 1000, period: 7 },
    { from: 1500, to: 3000, price: 1800, period: 12 },
    { from: 3000, to: 5000, price: 3700, period: 20 },
    { from: 5000, to: 10000, price: 6000, period: 30 },
    { from: 10000, to: 15000, price: 12000, period: 50 },
    { from: 15000, to: 30000, price: 20000, period: 60 },
  ],
  hourly: [
    { from: 0, to: 15, price: 15, period: 12 },
    { from: 15, to: 25, price: 20, period: 12 },
    { from: 25, to: 50, price: 35, period: 12 },
    { from: 50, to: Infinity, price: 60, period: 12 },
  ],
};

// Freelancer shows the same budget tiers ($30-250, $250-750, ...) in these
// currencies, so the rules apply to their numbers as-is: a "$30-250 AUD"
// project gets a 150 AUD bid.
var FL_SAME_TIERS = ["USD", "EUR", "GBP", "AUD", "CAD", "NZD", "SGD"];

// Rough USD value of one unit of each other currency (INR, PHP, ...). Used to
// pick the tier and convert the tier price back, so approximate is fine.
var FL_USD_RATE = {
  USD: 1, EUR: 1.16, GBP: 1.34, AUD: 0.66, CAD: 0.72, NZD: 0.58, SGD: 0.77,
  HKD: 0.128, INR: 0.0114, PHP: 0.0172, IDR: 0.00006, MXN: 0.054, ZAR: 0.057,
  SEK: 0.105, PLN: 0.27, JPY: 0.0066, BRL: 0.18, CLP: 0.00105,
};

// "$30.00 – 250.00 USD" / "₹600 – 1,500 INR" / "$15.00 – 25.00 USD per hour"
function flParseBudget(text) {
  var t = String(text || "").replace(/ /g, " ");
  var code = t.match(new RegExp("\\b(" + Object.keys(FL_USD_RATE).join("|") + ")\\b"));
  var currency = code ? code[1]
    : /€/.test(t) ? "EUR" : /£/.test(t) ? "GBP" : /₹/.test(t) ? "INR" : /\$/.test(t) ? "USD" : null;
  var nums = (t.match(/\d[\d,]*(?:\.\d+)?/g) || []).map(function (s) { return parseFloat(s.replace(/,/g, "")); });
  return {
    currency: currency,
    min: nums.length ? nums[0] : null,
    max: nums.length > 1 ? nums[1] : null,
    hourly: /per\s*hour|\/\s*(hour|hr)\b|hourly/i.test(t),
  };
}

function flRound(x) {
  var step = x >= 100000 ? 1000 : x >= 1000 ? 10 : 1;
  return Math.round(x / step) * step;
}

// The price table from the panel's Prices settings: { fixed: [...], hourly: [...] }
// with to = null for "no upper limit" (storage cannot hold Infinity). Bad rows are
// dropped; a type with no good rows falls back to the built-in FL_RULES.
function flCleanRules(saved) {
  var out = {};
  var num = function (v) { return v == null || v === "" ? NaN : Number(v); }; // Number("") is 0
  ["fixed", "hourly"].forEach(function (type) {
    var rows = ((saved && saved[type]) || []).map(function (r) {
      return { from: num(r.from), to: r.to == null || r.to === "" ? Infinity : Number(r.to), price: num(r.price), period: num(r.period) };
    }).filter(function (r) {
      return isFinite(r.from) && r.from >= 0 && (r.to === Infinity || (isFinite(r.to) && r.to > r.from)) &&
        isFinite(r.price) && r.price > 0 && isFinite(r.period) && r.period > 0;
    }).sort(function (a, b) { return a.from - b.from; });
    out[type] = rows.length ? rows : FL_RULES[type];
  });
  return out;
}

// type: "fixed" | "hourly"; table: flCleanRules(...) result, or the built-in
// FL_RULES when omitted. Returns { price, period, currency, note } or { error }.
function flPlanBid(budget, type, table) {
  if (!budget || !budget.min) return { error: "Budget not found on the page" };
  var asIs = FL_SAME_TIERS.indexOf(budget.currency) !== -1;
  var rate = asIs ? 1 : FL_USD_RATE[budget.currency];
  if (!rate) return { error: "Unknown currency " + (budget.currency || "(none)") };
  var minUsd = budget.min * rate;
  var rules = (table || FL_RULES)[type] || [];
  var rule = rules.find(function (r) { return minUsd >= r.from && minUsd < r.to; });
  // Outside every tier ($10-30, £20-250, ...): use the nearest tier and keep
  // its price inside the client's range.
  var nearest = !rule;
  if (nearest) rule = flNearestRule(rules, minUsd);
  if (!rule) return { error: "No " + type + " price rules" };
  var price = asIs ? rule.price : flRound(rule.price / rate);
  var note = nearest ? " (budget outside your tiers, used the nearest: " + rule.from + "-" +
    (rule.to === Infinity ? "up" : rule.to) + " " + (asIs ? budget.currency : "USD") + ")" : "";
  if (price < budget.min) { price = budget.min; note += " (raised to the client's minimum)"; }
  else if (nearest && budget.max && price > budget.max) { price = budget.max; note += " (lowered to the client's maximum)"; }
  return { price: price, period: rule.period, currency: budget.currency, note: note };
}

// Distance is a ratio, so a $10 minimum is nearer the $30 tier than a $500 one.
function flNearestRule(rules, minUsd) {
  var best = null, bestDist = Infinity;
  rules.forEach(function (r) {
    var dist = minUsd < r.from ? r.from / minUsd : minUsd >= r.to ? minUsd / r.to : 1;
    if (dist < bestDist) { best = r; bestDist = dist; }
  });
  return best;
}

if (typeof module !== "undefined") module.exports = { FL_RULES, FL_SAME_TIERS, FL_USD_RATE, flParseBudget, flPlanBid, flNearestRule, flCleanRules };
