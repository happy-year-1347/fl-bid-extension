// The extension's interface is the box that box.js shows on Freelancer project
// pages. This worker handles the toolbar icon and the keyboard shortcut.

const FL_PROJECT = /^https:\/\/([a-z0-9-]+\.)?freelancer\.com\/projects\//i;
const injectBox = (tabId) => chrome.scripting.executeScript({ target: { tabId }, files: ["box.js"] }).catch(() => {});

// Freelancer tabs opened before the extension was installed or reloaded get the box now.
chrome.runtime.onInstalled.addListener(async () => {
  for (const t of await chrome.tabs.query({ url: "https://*.freelancer.com/*" })) injectBox(t.id);
});

// Toolbar icon: show or hide the box on this Freelancer page.
chrome.action.onClicked.addListener(async (tab) => {
  const r = await chrome.tabs.sendMessage(tab.id, { type: "box:toggle" }).catch(() => null);
  if (r || !/^https:\/\/([a-z0-9-]+\.)?freelancer\.com\//i.test(tab.url || "")) return;
  await injectBox(tab.id);
  chrome.tabs.sendMessage(tab.id, { type: "box:show" }).catch(() => {});
});

// The Freelancer project tab a shortcut press is meant for: the active tab, else its
// split view partner, else the most recently used project tab in that window.
async function projectTabFor(tab) {
  if (!tab) return null;
  if (FL_PROJECT.test(tab.url || "")) return tab;
  const win = await chrome.tabs.query({ windowId: tab.windowId });
  const fl = win.filter((t) => FL_PROJECT.test(t.url || ""));
  const none = chrome.tabs.SPLIT_VIEW_ID_NONE !== undefined ? chrome.tabs.SPLIT_VIEW_ID_NONE : -1;
  const split = tab.splitViewId != null && tab.splitViewId !== none ? fl.find((t) => t.splitViewId === tab.splitViewId) : null;
  return split || fl.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
}

// The "start-bid" shortcut works like the box's Start button. The box's panel
// answers the message; if none does (the box was hidden before its first load, or
// the page predates the extension), the request is left in session storage and
// the box is shown, so its panel picks the request up when it loads.
async function shortcut(tab) {
  const fl = await projectTabFor(tab);
  if (!fl) return;
  const r = await chrome.runtime.sendMessage({ type: "panel:start", tabId: fl.id }).catch(() => null);
  if (r && r.ok) return;
  await chrome.storage.session.set({ pendingStart: { at: Date.now(), tabId: fl.id } });
  await injectBox(fl.id);
  chrome.tabs.sendMessage(fl.id, { type: "box:show" }).catch(() => {});
}
chrome.commands.onCommand.addListener((command, tab) => { if (command === "start-bid") shortcut(tab); });

// box.js asks whether its tab runs auto bid (the panel keeps that tab's id in session
// storage, which content scripts cannot read): the box then shows on every page there.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "box:state" || !sender.tab) return false;
  chrome.storage.session.get({ autoTab: null }).then((s) => reply({ auto: s.autoTab === sender.tab.id }), () => reply({ auto: false }));
  return true;
});
