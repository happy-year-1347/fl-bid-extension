// Loaded on every Freelancer page. On project pages and chat pages (/messages) it shows a
// small box that holds the extension's panel (panel.html in a frame, so the panel can
// use the extension APIs); in the tab that runs auto bid, on every page. Drag the box by
// its top bar; the toolbar icon or "-" hides it. Hiding only hides: the frame keeps
// running, so a bid in progress carries on.
(() => {
  // Skip if a live copy is already here. After an extension reload the old copy's
  // box is dead (its frame no longer loads), so it is replaced.
  if (window.__flbidBoxAlive && window.__flbidBoxAlive()) return;
  window.__flbidBoxAlive = () => { try { return !!chrome.runtime.id; } catch (e) { return false; } };
  document.querySelectorAll("flbid-box").forEach((el) => el.remove());

  const ORIGIN = new URL(chrome.runtime.getURL("")).origin;
  // autoHere: this tab runs auto bid (asked once per page load; see background.js).
  let autoHere = false;
  const isProject = () => /^\/(projects\/|messages(\/|$))/.test(location.pathname) || autoHere;
  const state = { boxHidden: false, boxRight: 12, boxTop: 90 };
  let host = null, wrap = null, frame = null, bar = null, title = null;
  let size = { w: 140, h: 130 };

  const CSS = `
    .box { position: fixed; z-index: 2147483647; display: flex; flex-direction: column; border-radius: 8px;
      overflow: hidden; box-shadow: 0 4px 18px rgba(0,0,0,.35); background: #fff; }
    .bar { display: flex; align-items: center; justify-content: space-between; height: 16px; padding: 0 2px 0 3px;
      background: linear-gradient(90deg, #4338ca, #7c3aed); color: #fff; font: 600 10px/16px system-ui, "Segoe UI", sans-serif;
      cursor: move; user-select: none; touch-action: none; }
    .bar.warn { background: #b26a00; }
    .bar.err { background: #c0392b; }
    .name { display: flex; align-items: center; gap: 4px; min-width: 0; }
    .logo { width: 12px; height: 12px; flex: none; }
    .title { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .hide { all: unset; cursor: pointer; padding: 0 6px; font: 700 12px/16px system-ui, sans-serif; }
    iframe { display: block; border: 0; }`;

  function build() {
    host = document.createElement("flbid-box");
    const root = host.attachShadow({ mode: "closed" });
    const logo = (s) => chrome.runtime.getURL("icons/icon" + s + ".png");
    root.innerHTML = `<style>${CSS}</style><div class="box"><div class="bar" title="Drag to move">` +
      `<span class="name"><img class="logo" alt="" draggable="false" src="${logo(16)}" srcset="${logo(16)} 1x, ${logo(32)} 2x"><span class="title">FL Bid</span></span>` +
      `<button class="hide" title="Hide (click the extension icon to show it again)">&minus;</button></div>` +
      `<iframe allow="clipboard-write"></iframe></div>`;
    wrap = root.querySelector(".box");
    frame = root.querySelector("iframe");
    frame.src = chrome.runtime.getURL("panel.html");
    bar = root.querySelector(".bar");
    title = root.querySelector(".title");
    root.querySelector(".hide").addEventListener("click", () => { state.boxHidden = true; save(); update(); });
    // While dragging, the frame ignores the mouse: otherwise it takes the events as
    // soon as the pointer slips off the thin bar, and the drag never ends.
    bar.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || e.target.closest(".hide")) return;
      e.preventDefault();
      try { bar.setPointerCapture(e.pointerId); } catch (err) {}
      frame.style.pointerEvents = "none";
      const from = { x: e.clientX, y: e.clientY, right: parseFloat(wrap.style.right), top: parseFloat(wrap.style.top) };
      const move = (ev) => {
        state.boxRight = from.right - (ev.clientX - from.x);
        state.boxTop = from.top + (ev.clientY - from.y);
        place();
      };
      const up = () => {
        window.removeEventListener("pointermove", move, true);
        window.removeEventListener("pointerup", up, true);
        window.removeEventListener("pointercancel", up, true);
        frame.style.pointerEvents = "";
        state.boxRight = parseFloat(wrap.style.right);
        state.boxTop = parseFloat(wrap.style.top);
        save();
      };
      window.addEventListener("pointermove", move, true);
      window.addEventListener("pointerup", up, true);
      window.addEventListener("pointercancel", up, true);
    });
    place();
    document.documentElement.append(host);
  }

  // Size the frame and keep the whole box on screen (a tall box scrolls inside).
  function place() {
    if (!wrap) return;
    const h = Math.max(60, Math.min(size.h, innerHeight - 30));
    frame.style.width = size.w + "px";
    frame.style.height = h + "px";
    wrap.style.right = Math.min(Math.max(0, state.boxRight), Math.max(0, innerWidth - size.w - 4)) + "px";
    wrap.style.top = Math.min(Math.max(0, state.boxTop), Math.max(0, innerHeight - h - 20)) + "px";
  }

  function update() {
    if (!window.__flbidBoxAlive()) { clearInterval(timer); return; }
    const show = isProject() && !state.boxHidden;
    if (show && !host) build();
    if (host) host.style.display = show ? "" : "none";
  }
  const save = () => chrome.storage.local.set({ boxHidden: state.boxHidden, boxRight: state.boxRight, boxTop: state.boxTop });

  // The panel says how big it wants to be, and whether this project cannot be bid
  // on (the bar then shows why, in red, or amber for "Already bid").
  window.addEventListener("message", (e) => {
    if (!frame || e.source !== frame.contentWindow || e.origin !== ORIGIN) return;
    const s = e.data && e.data.flbidSize;
    if (s && s.w > 0 && s.h > 0) { size = { w: Math.ceil(s.w), h: Math.ceil(s.h) }; place(); }
    if (e.data && "flbidNotice" in e.data) {
      const n = e.data.flbidNotice;
      title.textContent = n ? n.label : "FL Bid";
      bar.className = "bar" + (n ? " " + n.level : "");
      bar.title = n ? n.text + " (drag to move)" : "Drag to move";
    }
  });
  window.addEventListener("resize", place);

  // From background.js: the toolbar icon (toggle) and the shortcut (show).
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (!msg || (msg.type !== "box:toggle" && msg.type !== "box:show")) return false;
    state.boxHidden = msg.type === "box:toggle" ? !state.boxHidden : false;
    save();
    update();
    reply({ ok: true, visible: isProject() && !state.boxHidden });
    return false;
  });

  // Freelancer changes pages without reloading, so watch the address.
  const timer = setInterval(update, 1000);
  chrome.storage.local.get(state).then((saved) => { Object.assign(state, saved); update(); });
  chrome.runtime.sendMessage({ type: "box:state" }).then((r) => { autoHere = !!(r && r.auto); update(); }, () => {});
})();
