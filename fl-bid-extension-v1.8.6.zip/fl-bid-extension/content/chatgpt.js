// Injected into the ChatGPT bid chat by the panel. Types the prompt, sends
// it, waits for the answer to finish and returns it as plain text.
(() => {
  // Change with every update of this file: the panel replaces a copy whose build
  // differs (one left in the page from before an update).
  const BUILD = "1.8.6";
  const prev = window.__flbidGpt;
  if (prev && prev.alive()) {
    if (prev.build === BUILD) return;
    prev.retire();
  } else if (!prev && window.__flbidGptAlive && window.__flbidGptAlive()) {
    // A live copy from before v1.7 cannot be retired; the panel reloads this tab.
    return;
  }

  // ChatGPT changes its markup from time to time; update these lists if it does.
  // Each list holds the current markup (checked 2026-10-29) and the older one.
  const SEL = {
    composer: ["textarea#mobile-composer-prompt", "form textarea[name='prompt']", "[contenteditable='true'][aria-label='Ask ChatGPT']",
      "#prompt-textarea[contenteditable='true']", "div#prompt-textarea", ".ProseMirror[contenteditable='true']", "textarea#prompt-textarea", "main form textarea"],
    send: ["button[data-composer-submit][aria-label='Send message']",
      "button[data-testid='send-button']", "#composer-submit-button", "button[aria-label='Send prompt']", "button[aria-label='Send message']"],
    stop: ["button[data-composer-submit][aria-label*='Stop']",
      "button[data-testid='stop-button']", "button[aria-label='Stop streaming']", "button[aria-label='Stop generating']"],
    user: "[data-message-role='user'], [data-message-author-role='user']",
    assistant: "[data-message-role='assistant'], [data-message-author-role='assistant']",
    content: ["[data-assistant-markdown-root]", ".markdown"],
  };

  const PROPOSAL_RE = /\[\[\s*PROPOSAL\s*\]\]/i;
  const QUESTIONS_RE = /\[\[\s*QUESTIONS\s*\]\]/i;
  const END_RE = /\[\[\s*END\s*\]\]/i;
  // ChatGPT's own screen text that the page-text reader picks up around an answer
  // (it once ended up in a proposal: "You're using the free version of ChatGPT...",
  // "Try Plus free", "Latest response", "Response complete").
  const UI_LINE = new RegExp("^(" + [
    "you['’]re using the free version of chatgpt.*", "upgrade (to plus|for .*)", "try plus free", "get plus",
    "chatgpt can make mistakes.*", "latest response", "response complete", "response stopped",
    "chatgpt said:?", "you said:?", "is this conversation helpful so far\\??", "show more", "show less", "thinking",
  ].join("|") + ")$", "i");
  const dropUiLines = (t) => t.split("\n").filter((l) => !UI_LINE.test(l.trim())).join("\n").replace(/\n{3,}/g, "\n\n").trim();

  // Each ask / wait runs under a token, one per Freelancer tab ("from"). That tab's
  // Stop or next ask stops it, so an earlier wait (its box gone after a page reload)
  // never keeps running alongside; a bid from another tab carries on.
  const tokens = new Map();
  const newToken = (from) => {
    const old = tokens.get(from);
    if (old) old.stopped = true;
    const t = { stopped: false };
    tokens.set(from, t);
    return t;
  };
  const stopTokens = (from) => {
    for (const [k, t] of tokens) if (from == null || k === from) t.stopped = true;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Laid out and not hidden with visibility/opacity (a hidden Stop button must not count).
  const visible = (el) => {
    if (!el || !el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && parseFloat(cs.opacity || "1") > 0.05;
  };
  // On screen the way the page's text is (innerText): laid out and not visibility:hidden.
  const shown = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();
  // Live status for the panel while waiting.
  function progress(text, details) {
    try { chrome.runtime.sendMessage({ type: "cgpt:progress", text, diag: details }).catch(() => {}); } catch (e) {}
  }
  function first(list) {
    for (const s of list) {
      for (const el of document.querySelectorAll(s)) if (visible(el)) return el;
    }
    return null;
  }
  // Checks right away, then every 40 ms: a wait ends as soon as its condition holds.
  async function waitFor(fn, ms, tk) {
    for (const t0 = Date.now(); ; await sleep(40)) {
      if (tk.stopped) throw new Error("Stopped");
      const v = fn();
      if (v) return v;
      if (Date.now() - t0 >= ms) return null;
    }
  }

  // Rendered markdown -> plain text, keeping paragraphs and list markers.
  function plainText(root) {
    let out = "";
    const gap = (n) => {
      if (!out) return;
      // Right after a list marker ("- ", "2. ") the item's text follows on the same line,
      // even when ChatGPT wraps it in its own block.
      if (/(^|\n)[ ]*(- |\d+\. )$/.test(out)) return;
      const have = out.length - out.replace(/\n+$/, "").length;
      if (have < n) out += "\n".repeat(n - have);
    };
    const walk = (node, depth) => {
      node.childNodes.forEach((c) => {
        if (c.nodeType === Node.TEXT_NODE) { out += c.nodeValue; return; }
        if (c.nodeType !== Node.ELEMENT_NODE) return;
        const tag = c.tagName.toUpperCase();
        if (tag === "BUTTON" || tag === "SVG") return;
        if (tag === "BR") { out += "\n"; return; }
        if (tag === "PRE") {
          gap(2);
          out += (c.querySelector("code") || c).textContent.replace(/\n+$/, "");
          gap(2);
          return;
        }
        if (tag === "LI") {
          gap(1);
          const list = c.parentElement;
          const ordered = list && list.tagName === "OL";
          const num = ordered ? Array.prototype.indexOf.call(list.children, c) + (parseInt(list.getAttribute("start"), 10) || 1) : 0;
          out += "  ".repeat(depth) + (ordered ? num + ". " : "- ");
          walk(c, depth + 1);
          gap(1);
          return;
        }
        if (tag === "UL" || tag === "OL") { gap(depth ? 1 : 2); walk(c, depth); gap(depth ? 1 : 2); return; }
        if (/^(P|H[1-6]|BLOCKQUOTE|TABLE|HR)$/.test(tag)) {
          // depth > 0 only inside a list item of the answer itself.
          const inLi = depth > 0;
          if (!inLi || c.previousElementSibling) gap(inLi ? 1 : 2);
          walk(c, depth);
          gap(inLi ? 1 : 2);
          return;
        }
        if (tag === "DIV" || tag === "TR") { gap(1); walk(c, depth); gap(1); return; }
        walk(c, depth);
      });
    };
    walk(root, 0);
    return out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function answerText(msg) {
    for (const s of SEL.content) {
      const parts = msg.querySelectorAll(s);
      if (!parts.length) continue;
      const text = [...parts].map(plainText).join("\n\n").trim();
      // Writing blocks / canvas can sit outside the markdown root; then read the whole message.
      if (PROPOSAL_RE.test(text)) return text;
      const all = plainText(msg);
      return PROPOSAL_RE.test(all) ? all : text;
    }
    return plainText(msg);
  }

  async function insert(el, text, tk) {
    el.focus();
    if (el.tagName === "TEXTAREA") {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    const typed = () => {
      const have = norm(el.innerText), want = norm(text);
      return have.includes(want.slice(0, 60)) && have.length >= want.length * 0.9;
    };
    document.execCommand("selectAll");
    document.execCommand("delete");
    // A paste keeps the line breaks; the editor turns them into paragraphs. The
    // editor handles it at once, so a short look is enough before the fallback.
    const dt = new DataTransfer();
    dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    if (await waitFor(typed, 120, tk)) return;
    document.execCommand("selectAll");
    document.execCommand("insertText", false, text);
    if (!(await waitFor(typed, 400, tk))) throw new Error("Could not type the prompt into ChatGPT");
  }

  const composerText = (el) => norm(el ? (el.tagName === "TEXTAREA" ? el.value : el.innerText) : "");
  const usable = (b) => b && !b.disabled && b.getAttribute("aria-disabled") !== "true";
  // The message box's surroundings: its form, or the nearest box holding its buttons.
  function composerArea(composer) {
    if (!composer) return null;
    const form = composer.closest("form");
    if (form) return form;
    for (let el = composer.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      if (el.querySelectorAll("button").length > 1) return el;
    }
    return null;
  }
  const buttonName = (x) => [x.id, x.getAttribute("data-testid"), x.getAttribute("aria-label"), x.type === "submit" ? "submit" : ""].join(" ");

  // The send button: a known one, else a "send"/"submit" button around the message
  // box, never the voice/dictate ones.
  function findSend(composer) {
    const b = first(SEL.send);
    if (b) return b;
    const scope = composerArea(composer);
    if (!scope) return null;
    return [...scope.querySelectorAll("button")].find((x) => visible(x) && /send|submit/i.test(buttonName(x)) && !/voice|dictat|stop/i.test(buttonName(x))) || null;
  }
  // ChatGPT's Stop button while it writes: a known one, else a visible "stop" button
  // around the message box (its label changes from time to time).
  function stopButton() {
    const b = first(SEL.stop);
    if (b) return b;
    const scope = composerArea(first(SEL.composer));
    if (!scope) return null;
    return [...scope.querySelectorAll("button")].find((x) => visible(x) && /\bstop\b/i.test(buttonName(x)) && !/dictat|voice|record|listen/i.test(buttonName(x))) || null;
  }

  // What the page looked like, so a failed run can be diagnosed from the log.
  function describe(el) {
    if (!el) return "none";
    const a = (n) => el.getAttribute(n);
    return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") +
      (a("data-testid") ? "[testid=" + a("data-testid") + "]" : "") +
      (a("aria-label") ? "[aria=" + a("aria-label") + "]" : "") +
      (!usable(el) ? "[disabled]" : "") + (visible(el) ? "" : "[hidden]");
  }
  // Ancestors of a text node: tag + data-*/role/aria attributes.
  function chainOfNode(n) {
    const out = [];
    for (let el = n.parentElement, i = 0; el && i < 8; el = el.parentElement, i++) {
      const attrs = [...el.attributes].filter((a) => /^(data-|role$|aria-|id$)/.test(a.name)).map((a) => a.name + "=" + a.value.slice(0, 30));
      out.push(el.tagName.toLowerCase() + (attrs.length ? "[" + attrs.join(" ") + "]" : ""));
    }
    return out.join(" < ");
  }
  // The last text nodes matching re (outside scripts/styles), shown or hidden, with their place.
  function copiesOf(re) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const hits = [];
    let n;
    while ((n = w.nextNode())) {
      if (re.test(n.nodeValue) && !n.parentElement.closest("script, style")) hits.push(n);
    }
    const out = hits.slice(-3).map((h) => (shown(h.parentElement) ? "shown " : "hidden ") + chainOfNode(h));
    return out.length ? (hits.length > 3 ? hits.length + " copies, last 3:\n    " : "") + out.join("\n    ") : "not in one text node";
  }

  let currentMarker = "";
  let lastSlow = null;
  function diag() {
    const composer = first(SEL.composer);
    const scope = composerArea(composer) || document;
    const count = (s) => document.querySelectorAll(s).length;
    const esc = (s) => new RegExp(s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    let pageHas = "-";
    try { pageHas = currentMarker ? String(document.body.innerText.includes(currentMarker)) : "-"; } catch (e) {}
    return [
      "script " + BUILD + ", page " + location.pathname,
      "composer " + describe(composer) + " (" + composerText(composer).length + " chars)",
      "buttons " + [...scope.querySelectorAll("button")].filter(visible).slice(0, 15).map(describe).join(" "),
      "user msgs " + count(SEL.user) + ", assistant msgs " + count(SEL.assistant) +
        ", turns " + count("[data-testid^='conversation-turn']") + ", articles " + count("article"),
      "stop " + describe(stopButton()),
      "my message: " + (currentMarker ? copiesOf(esc(currentMarker)) : "-"),
      "my message in the page text: " + pageHas,
      "answer: " + copiesOf(END_RE),
      "page text after my message: " + (lastSlow ? JSON.stringify((lastSlow.text || lastSlow.raw || "").slice(-200)) : "-"),
    ].join("\n");
  }

  // ChatGPT's own control for stopping its thinking and answering at once, if it shows
  // one after our message while it thinks.
  const SKIP_LABEL = /^(skip|skip thinking|answer now|get a quick answer|quick answer)$/i;
  function skipControl(anchor, box) {
    const all = document.querySelectorAll("button, a, [role='button']");
    for (let i = all.length - 1; i >= 0; i--) {
      const b = all[i];
      if (!(anchor.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING)) break;
      if (box && box.contains(b)) continue;
      if (SKIP_LABEL.test((b.innerText || b.getAttribute("aria-label") || "").trim()) && visible(b)) return b;
    }
    return null;
  }

  // until "questions": return as soon as the proposal is written (see waitAnswer).
  async function ask({ prompt, marker, promptEnd, timeoutMs, from, until }) {
    const tk = newToken(from);
    const composer = await waitFor(() => first(SEL.composer), 15000, tk);
    if (!composer) throw new Error("ChatGPT message box not found. Is the chat open and are you logged in?");
    // The last bid returned at [[END]], so ChatGPT may still be finishing it.
    if (stopButton()) {
      progress("still finishing the previous answer");
      if (!(await waitFor(() => !stopButton(), 30000, tk))) throw new Error("ChatGPT is still answering an earlier message");
    }

    const t0 = Date.now();
    const before = document.querySelectorAll(SEL.user).length;
    const oldAnswers = new Set(document.querySelectorAll(SEL.assistant));
    progress("typing the prompt");
    await insert(composer, prompt, tk);
    const typedMs = Date.now() - t0;
    progress("sending");

    // ChatGPT took the message once the box empties, a Stop button shows, a new user
    // turn appears or the message shows in the chat. Send button (it appears as soon as
    // the box has text), else Enter, else the form's submit.
    const accepted = () => {
      const box = first(SEL.composer);
      return document.querySelectorAll(SEL.user).length > before || !!stopButton() || (box && !composerText(box)) ||
        markerNodes(marker, composerArea(box)).length > 0;
    };
    let sentBy = null;
    const send = await waitFor(() => { const b = findSend(composer); return usable(b) ? b : null; }, 1000, tk);
    if (send) { send.click(); if (await waitFor(accepted, 2500, tk)) sentBy = "send button"; }
    if (!sentBy) {
      const box = first(SEL.composer) || composer;
      box.focus();
      box.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      if (await waitFor(accepted, 2000, tk)) sentBy = "Enter key";
      else {
        const form = box.closest("form");
        if (form && form.requestSubmit) form.requestSubmit();
        if (await waitFor(accepted, 2500, tk)) sentBy = "form submit";
      }
    }
    if (!sentBy) throw new Error(send ? "ChatGPT did not accept the message" : "ChatGPT send button not found");
    const sentMs = Date.now() - t0 - typedMs;
    // For the log: earlier prompts from the box in this chat (their "(ref:...)" line;
    // ChatGPT gets slower as a chat grows) and the model ChatGPT's header shows.
    const refs = new Set((document.querySelector("main") || document.body).textContent.match(/\(ref:[0-9a-z]+\)/g) || []);
    refs.delete("(" + marker + ")");
    const modelBtn = document.querySelector("[data-testid='model-switcher-dropdown-button']");
    const model = modelBtn ? norm(modelBtn.innerText).slice(0, 40) : "";

    const r = await waitAnswer({ marker, promptEnd, before, oldAnswers, timeoutMs, until, tk });
    return Object.assign(r, { typedMs, sentMs, sentBy, answerMs: Date.now() - t0 - typedMs - sentMs, chatBids: refs.size, model });
  }

  // ---------- reading the answer without knowing ChatGPT's markup ----------
  // Our message starts with this run's marker ("ref:..."). The answer is the page
  // text after it, from [[PROPOSAL]] to [[END]]. Two readers do this: a fast one that
  // starts at the marker (its text node, or the element around it when the page splits
  // it over several elements), and, as the last resort, the page's whole visible text
  // (innerText). A hidden copy of our message (the page may keep one, e.g. to size the
  // box) or a later copy for screen readers has no answer after it, so every copy is
  // tried, the last first.

  // { text: from [[PROPOSAL]] (to [[END]] once it is there), raw: what ChatGPT wrote so
  // far without the format (only once our own prompt's last line is seen) }
  function cut(t, promptEnd) {
    t = dropUiLines(t);
    const p = t.search(PROPOSAL_RE);
    if (p < 0) {
      const tail = promptEnd ? t.lastIndexOf(promptEnd) : -1;
      return { text: "", raw: tail >= 0 ? t.slice(tail + promptEnd.length).trim() : "" };
    }
    const a = t.slice(p);
    const e = a.match(END_RE);
    return { text: (e ? a.slice(0, e.index + e[0].length) : a).trim(), raw: "" };
  }

  // Copies of the marker on screen and outside the message box: the text node holding
  // it, or, when the page splits it (link + spans), the smallest element around the
  // piece with the run's id that holds all of it.
  const ownText = (n) => (n.nodeType === Node.TEXT_NODE ? n.nodeValue : n.textContent);
  function markerNodes(marker, box) {
    const out = [];
    if (!marker) return out;
    const id = marker.replace(/^ref:/, "");
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!n.nodeValue.includes(id)) continue;
      let at = n.nodeValue.includes(marker) ? n : null;
      for (let p = n.parentElement, up = 0; !at && p && up < 4; p = p.parentElement, up++) {
        if (p.textContent.includes(marker)) at = p;
      }
      const el = at && (at === n ? n.parentElement : at);
      if (!el || el.closest("textarea, [contenteditable='true']") || (box && box.contains(el)) || !shown(el)) continue;
      if (out[out.length - 1] !== at) out.push(at);
    }
    return out;
  }

  // The page text after node, in page order, up to stopAt (ChatGPT's message box),
  // without reading the chat before it: the rest of node's own text node is the
  // caller's; this adds what follows it at each level up to root. Hidden parts are skipped.
  function textAfterNode(node, root, stopAt) {
    const parts = [];
    for (let cur = node; cur && cur !== root; cur = cur.parentNode) {
      for (let s = cur.nextSibling; s; s = s.nextSibling) {
        if (s.nodeType === Node.TEXT_NODE) { parts.push(s.nodeValue); continue; }
        if (s.nodeType !== Node.ELEMENT_NODE) continue;
        if (stopAt && (s === stopAt || s.contains(stopAt))) return parts.join("\n");
        const cs = getComputedStyle(s);
        if (cs.display === "none" || cs.visibility === "hidden") continue;
        parts.push(s.innerText || "");
      }
    }
    return parts.join("\n");
  }
  const rootOf = (n) => { const main = document.querySelector("main"); return main && main.contains(n) ? main : document.body; };

  // Fast reader. The copy that has the answer after it is kept in st (searching a long
  // bid chat on every look is slow); while no copy has one, they are searched again
  // each second, and while none is on the page, every 300 ms.
  function readFast(st, marker, promptEnd, box) {
    const after = (n) => { const own = ownText(n); return cut(own.slice(own.indexOf(marker) + marker.length) + "\n" + textAfterNode(n, rootOf(n), box), promptEnd); };
    if (st.node && st.node.isConnected && ownText(st.node).includes(marker)) {
      const r = after(st.node);
      if (r.text || Date.now() - st.searchAt < 1000) return r;
    } else if (!st.node && st.searchAt && Date.now() - st.searchAt < 300) {
      return null;
    }
    st.searchAt = Date.now();
    const nodes = markerNodes(marker, box);
    let best = null;
    st.node = null;
    for (let i = nodes.length - 1; i >= 0; i--) {
      const r = after(nodes[i]);
      if (r.text) { st.node = nodes[i]; return r; }
      if (!best) { best = r; st.node = nodes[i]; }
    }
    return best;
  }

  // Slow reader: the page's visible text, as ChatGPT shows it. null = marker not in it.
  function readSlow(marker, promptEnd) {
    const main = document.querySelector("main");
    let t = main ? main.innerText : "";
    if (!t.includes(marker)) t = document.body.innerText || "";
    let i = t.lastIndexOf(marker);
    if (i < 0) return null;
    let best = null;
    for (let k = 0; i >= 0 && k < 6; k++, i = i > 0 ? t.lastIndexOf(marker, i - 1) : -1) {
      const r = cut(t.slice(i + marker.length), promptEnd);
      if (r.text) return r;
      if (!best) best = r;
    }
    return best;
  }

  // The answer is the last assistant message after our own message (ChatGPT's markup,
  // when it is recognised), else what the page readers find after the run's marker.
  // An older bid in the chat is never picked up: the marker is new for every run.
  // "resume" is used when the page reloaded after sending, and to read on in an answer
  // returned early: then only the marker counts.
  // until "questions": the proposal is all that is wanted now. It is complete once the
  // QUESTIONS marker line follows it, so the answer is returned then, marked partial,
  // while ChatGPT goes on with the clarification post (read later with cgpt:wait).
  async function waitAnswer({ marker, promptEnd, before, oldAnswers, timeoutMs, resume, until, tk }) {
    currentMarker = marker || "";
    lastSlow = null;
    const st = { node: null, searchAt: 0 };   // the fast reader's place for this wait
    let slow = null, slowAt = 0, slowCost = 0;
    let last = "", since = Date.now(), lastReport = 0, detailsSent = false, kept = null, foundAt = 0, firstAt = 0;
    let part = "", partSince = 0;   // until "questions": the proposal seen before the QUESTIONS line
    let skipped = false, skipLookAt = 0;
    const t0 = Date.now();
    // foundMs: our message showed in the chat; firstMs: the answer's first line showed;
    // skipped: ChatGPT's own "Skip" / "Answer now" was clicked while it was thinking.
    const result = (text, via) => ({ ok: true, text, via, foundMs: foundAt ? foundAt - t0 : null, firstMs: firstAt ? firstAt - t0 : null, skipped });
    for (; ; await sleep(100)) {
      if (tk.stopped) throw new Error("Stopped");
      const now = Date.now();
      const waited = now - t0;
      if (waited > (timeoutMs || 360000)) throw new Error("ChatGPT took too long to answer");

      const assistants = [...document.querySelectorAll(SEL.assistant)];
      const after = (u) => assistants.filter((a) => u.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_FOLLOWING);
      // Our message, once found with an answer after it, is kept (no re-search of the chat).
      let mine = kept && kept.isConnected ? kept : null;
      if (!mine) {
        const users = [...document.querySelectorAll(SEL.user)];
        const marked = marker ? users.filter((u) => u.textContent.includes(marker)) : [];
        for (let i = marked.length - 1; i >= 0 && !mine; i--) if (after(marked[i]).length) mine = kept = marked[i];
        if (!mine && marked.length) mine = marked[marked.length - 1];
        if (!mine && !resume && users.length > before) mine = users[users.length - 1];
      }
      const answers = mine ? after(mine) : resume ? [] : assistants.filter((a) => !oldAnswers.has(a));
      const answer = answers[answers.length - 1] || null;

      // What each reader sees, best first: ChatGPT's message markup, the fast page
      // reader, the page's visible text (only once it has [[PROPOSAL]]: before that it
      // also holds the message box and footer, not ChatGPT's words).
      const reads = [];
      if (answer) {
        const t = dropUiLines(answerText(answer));
        const r = cut(t, null);
        reads.push({ text: r.text, raw: r.text ? "" : t, how: "message" });
      }
      let fast = null;
      if (marker) {
        fast = readFast(st, marker, promptEnd, composerArea(first(SEL.composer)));
        if (fast) reads.push(Object.assign({ how: "page" }, fast));
        // The page's whole text is the last resort: in a long chat it takes a while to
        // read, and ChatGPT's page (its writing too) waits meanwhile. Never while another
        // reader has the answer; every second while it is the one that has it or our
        // message is not found otherwise; every 3 s while nothing reads as the answer yet.
        const gap = reads.some((r) => r.text) ? Infinity : (slow && slow.text) || !(mine || st.node) ? 1000 : 3000;
        if (now - slowAt >= Math.max(gap, slowCost * 8)) {
          const s0 = Date.now();
          slow = readSlow(marker, promptEnd);
          lastSlow = slow;
          slowAt = Date.now();
          slowCost = slowAt - s0;   // a huge chat is read less often
        }
        if (slow && slow.text && !reads.some((r) => END_RE.test(r.text))) reads.push(Object.assign({ how: "page text" }, slow));
      }
      const found = !!mine || !!fast || !!slow;
      if (found && !foundAt) foundAt = now;
      const pick = reads.find((r) => END_RE.test(r.text)) || reads.find((r) => r.text) || reads.find((r) => r.raw) || null;
      if (pick && pick.text && !firstAt) firstAt = now;
      const seen = pick ? pick.text || pick.raw : "";
      if (seen !== last) { last = seen; since = now; }
      const quiet = now - since;
      // Only a complete answer is used: [[END]] is the last line the format asks
      // for, so once it shows (and one more look finds the text unchanged) the
      // answer is done, without waiting for ChatGPT's Stop button to go away.
      const ended = !!pick && PROPOSAL_RE.test(pick.text) && END_RE.test(pick.text);
      if (ended && quiet >= 100) return result(pick.text, pick.how);
      // The proposal is done when the QUESTIONS line follows it and one more look finds it
      // unchanged (pick.text starts at [[PROPOSAL]]).
      if (until === "questions" && !ended && pick && pick.text) {
        const q = pick.text.search(QUESTIONS_RE);
        const p = q > 0 ? pick.text.slice(0, q) : "";
        if (p !== part) { part = p; partSince = now; }
        else if (p && now - partSince >= 100) return Object.assign(result(pick.text, pick.how), { partial: true });
      }

      const anchor = mine || st.node;
      const busy = !!stopButton() || (!!anchor && [...document.querySelectorAll("[aria-busy='true']")].some((el) => anchor.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING));
      // Thinking (nothing of the answer written yet): ChatGPT's own skip control, once.
      if (anchor && !skipped && !(pick && pick.text) && now - skipLookAt >= 300) {
        skipLookAt = now;
        const skip = skipControl(anchor, composerArea(first(SEL.composer)));
        if (skip) { skip.click(); skipped = true; progress("skipped ChatGPT's thinking"); }
      }
      // ChatGPT finished (flag on the current markup, or no change for a while)
      // without the [[END]] line: never fill a half answer.
      const done = answer && answer.hasAttribute("data-message-complete");
      if (last && !busy && quiet > (done ? 3000 : 12000)) {
        // One more look at the page's whole text before giving up on the answer.
        const s = marker ? readSlow(marker, promptEnd) : null;
        if (s && PROPOSAL_RE.test(s.text) && END_RE.test(s.text)) return result(s.text, "page text");
        const tail = last.replace(/\s+/g, " ").trim();
        if (PROPOSAL_RE.test(last)) {
          throw new Error("ChatGPT's answer stopped before its [[END]] line, so it was not used. It ends with: \"" +
            tail.slice(-120) + "\". Nothing was filled; press Start to try again.");
        }
        if (tail.length > 40) {
          throw new Error("ChatGPT did not answer in the [[PROPOSAL]] format, so nothing was filled. Its reply starts: \"" + tail.slice(0, 160) + "\"");
        }
      }
      // Never a silent wait: our message must show in the chat, and ChatGPT must start.
      if (!found && waited > (resume ? 20000 : 30000)) {
        throw new Error(resume ? "ChatGPT reloaded before the prompt was sent. Press Start again."
          : "The prompt was sent, but it does not show in the ChatGPT chat (looked for 30 s), so the answer cannot be read. Nothing was filled. Send the log (Settings > Log > Copy log).");
      }
      if (found && !last && !busy && now - foundAt > 120000) {
        throw new Error("ChatGPT has not answered for 2 minutes (no reply on the page). Nothing was filled; check the chat and press Start again.");
      }
      if (now - lastReport >= 1000) {
        lastReport = now;
        const state = !found ? "looking for your message in the chat" : pick && pick.text ? `writing the bid, ${pick.text.length} chars` : busy ? "thinking" : "waiting for the answer";
        const details = !detailsSent && (waited > 45000 || (!found && waited > 15000)) ? diag() : undefined;
        if (details) detailsSent = true;
        progress(state, details);
      }
    }
  }

  const handlers = {
    "cgpt:ping": async () => ({ ok: true, build: BUILD, visible: document.visibilityState === "visible" }),
    "cgpt:ask": (msg) => ask(msg).catch((e) => { e.diag = diag(); throw e; }),
    "cgpt:wait": (msg) => {
      return waitAnswer({ marker: msg.marker, promptEnd: msg.promptEnd, timeoutMs: msg.timeoutMs, resume: true, until: msg.until, tk: newToken(msg.from) }).catch((e) => { e.diag = diag(); throw e; });
    },
    "cgpt:abort": async (msg) => {
      stopTokens(msg.from);
      const stop = stopButton();
      if (stop) stop.click();
      return { ok: true };
    },
    "cgpt:retire": async () => { retire(); return { ok: true }; },
  };
  const listener = (msg, _sender, reply) => {
    const h = handlers[msg && msg.type];
    if (!h) return false;
    h(msg).then(reply, (e) => reply({ ok: false, error: e && e.message ? e.message : String(e), diag: e && e.diag }));
    return true;
  };
  function retire() {
    stopTokens(null);
    try { chrome.runtime.onMessage.removeListener(listener); } catch (e) {}
    if (window.__flbidGpt === me) window.__flbidGpt = null;
  }
  const me = {
    build: BUILD,
    alive: () => { try { return !!chrome.runtime.id; } catch (e) { return false; } },
    retire,
  };
  window.__flbidGpt = me;
  chrome.runtime.onMessage.addListener(listener);
})();
