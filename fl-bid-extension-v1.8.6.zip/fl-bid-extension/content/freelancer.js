// Injected into the Freelancer project tab by the panel. Reads the project,
// fills the bid form and clarification board, and clicks Post / Place Bid.
(() => {
  // Change with every update of this file: the panel replaces a copy whose build
  // differs (one left in the page from before an update). After an extension reload
  // the old copy's runtime is dead, so a fresh one registers.
  const BUILD = "1.8.6";
  const prev = window.__flbidFl;
  if (prev && prev.alive()) {
    if (prev.build === BUILD) return;
    prev.retire();
  } else if (!prev && window.__flbidAlive && window.__flbidAlive()) {
    // A live copy from before v1.7 cannot be retired; the panel asks for a page reload.
    return;
  }

  const PROPOSAL_LABEL = /describe your proposal/i;
  const PRICE_LABEL = /^\s*(bid amount|hourly rate)\s*$/i;
  const PERIOD_LABEL = /^\s*(this project will be delivered in|weekly limit)\s*$/i;
  const HOURLY_LABEL = /^\s*(hourly rate|weekly limit)\s*$/i;
  const BOARD_LABEL = /^\s*clarification board\s*$/i;
  // With a paid upgrade ticked the button reads "Place Bid and Pay $0.42 USD".
  const PLACE_BID = /^place bid(\s+(and|&)\s+pay\b[\s\S]*)?$/i;
  const FIELD = "input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button])";
  const CODES = "USD|EUR|GBP|AUD|CAD|NZD|SGD|HKD|INR|PHP|IDR|MXN|ZAR|SEK|PLN|JPY|BRL|CLP";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const visible = (el) => !!el && el.getClientRects().length > 0;
  const getText = (el) => (el ? (el.innerText || el.textContent || "").trim() : "");
  const cleanText = (t) => (t || "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const follows = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

  // First visible element holding a text node that matches re.
  function findText(re, from) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (from && !follows(from, n)) continue;
      if (re.test(n.nodeValue) && visible(n.parentElement)) return n.parentElement;
    }
    return null;
  }
  // First visible element matching selector that comes after anchor in the page.
  function after(anchor, selector) {
    for (const el of document.querySelectorAll(selector)) {
      if (visible(el) && follows(anchor, el)) return el;
    }
    return null;
  }
  function buttonByText(re, from) {
    for (const b of document.querySelectorAll("button, [role='button'], input[type='submit']")) {
      if (from && !follows(from, b)) continue;
      if (re.test((b.innerText || b.value || "").trim()) && visible(b)) return b;
    }
    return null;
  }
  const isDisabled = (b) => b.disabled || b.getAttribute("aria-disabled") === "true";
  function inputAfterLabel(re) {
    const label = findText(re);
    return label ? after(label, FIELD) : null;
  }
  // Freelancer's text boxes save their text into the bid form only on a "blur"
  // event: the proposal box (fl-textarea, dynamicValidation "blur") switches its
  // form control to updateOn "blur", and its handleBlur() runs
  // control.setValue(textarea.value). But when the page itself does not have focus
  // (Start was clicked in the panel's frame), Chrome moves focus WITHOUT firing
  // focus/blur events, so the text never reaches the form ("Please enter your
  // proposal"). So fire the focus/blur events on the element ourselves.
  function fireFocus(el) {
    el.focus({ preventScroll: true });
    el.dispatchEvent(new FocusEvent("focus"));
    el.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
  }
  function fireBlur(el) {
    el.dispatchEvent(new FocusEvent("blur"));
    el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    el.blur();
  }

  // Angular listens for input/change/blur, so set the value the way typing would.
  function setValue(el, value, keepFocus) {
    fireFocus(el);
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      document.execCommand("insertText", false, value);
    } else {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    if (!keepFocus) fireBlur(el);
  }
  // Checks right away, then every 50 ms: a wait ends as soon as its condition holds.
  async function waitFor(fn, ms) {
    for (const t0 = Date.now(); ; await sleep(50)) {
      const v = fn();
      if (v) return v;
      if (Date.now() - t0 >= ms) return null;
    }
  }
  // Angular updates the page within the same task as the event, so a short pause
  // between form steps is enough.
  const STEP = 60;
  const valueOf = (el) => (el.isContentEditable ? el.innerText : el.value);

  // Insert text through the browser's own editing command, which fires the same
  // beforeinput/input events as typing; fall back to the value setter. The text is
  // only saved into Freelancer's form by the blur that follows (see fireBlur).
  function typeText(el, text) {
    fireFocus(el);
    el.select();
    let ok = false;
    try { ok = document.execCommand("insertText", false, text); } catch (e) {}
    if (!ok || el.value !== text) {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(el, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
    el.dispatchEvent(new KeyboardEvent("keyup", { key: "End", code: "End", bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  // Second try: empty the box, then paste the text (falls back to typeText).
  function retypeText(el, text) {
    fireFocus(el);
    el.select();
    try { document.execCommand("delete"); } catch (e) {}
    const dt = new DataTransfer();
    dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    if (el.value !== text) typeText(el, text);
  }
  // Freelancer shows this under the box when its form has no proposal.
  const PROPOSAL_ERROR = /please (enter|write|add) (your|a) proposal|proposal is required/i;
  const proposalRejected = (box, text) => box.value !== text || !!findText(PROPOSAL_ERROR, box);
  // Freelancer's messages under the bid form's fields (fl-validation-error, shown in
  // red for a value its form refuses: "Your proposal must not be greater than 1500
  // characters", "You must have at least 3 reviews ... to place a bid greater than
  // ...", "Please enter at least 1 day", ...). Warnings (amber) are not counted.
  function formErrors() {
    const box = proposalBox();
    const btn = buttonByText(PLACE_BID);
    // The bid form: the smallest box holding both the proposal and Place Bid.
    let form = box;
    while (form && btn && !form.contains(btn)) form = form.parentElement;
    const out = [];
    for (const el of (form || document).querySelectorAll("fl-validation-error .text-error, fl-validation-error .ErrorText:not(.text-warning)")) {
      const t = getText(el).replace(/\s+/g, " ");
      if (t && visible(el) && out.indexOf(t) === -1) out.push(t);
    }
    return out.slice(0, 5);
  }

  // Press Tab on el: the same events a real Tab produces, in the same order
  // (keydown, blur/focusout on el, focus/focusin on the next field, keyup), with
  // the blur fired explicitly because it is what saves the proposal (see fireFocus).
  // If the page cancels the keydown, nothing moves, as with a real Tab.
  function pressTab(el) {
    const key = { key: "Tab", code: "Tab", keyCode: 9, which: 9, bubbles: true, cancelable: true };
    if (!el.dispatchEvent(new KeyboardEvent("keydown", key))) return false;
    const next = [...document.querySelectorAll("input, textarea, select, button, a[href], [tabindex]")]
      .find((x) => visible(x) && !x.disabled && x.tabIndex >= 0 && follows(el, x));
    fireBlur(el);
    if (next) fireFocus(next);
    (next || el).dispatchEvent(new KeyboardEvent("keyup", key));
    return true;
  }
  // The proposal box: Freelancer gives it id "descriptionTextArea".
  function proposalBox() {
    const byId = document.querySelector("textarea#descriptionTextArea, #descriptionTextArea textarea");
    if (byId && visible(byId)) return byId;
    const label = findText(PROPOSAL_LABEL);
    return label ? after(label, "textarea") : null;
  }
  // Your own bid: the edit form ("Update Bid", maybe "... and Pay $0.12 USD"), or
  // your card in the bid list. Freelancer gives only your own card the "Retract"
  // and "Edit" actions (or "Request Edit" / "Edit request submitted"); other
  // people's bids get "Report Bid". Once you have bid, the bid form is gone.
  // (findText, not the page's innerText: that lays out the whole page and is slow.)
  const OWN_BID_ACTION = /^\s*(retract|retract bid|request edit|edit request submitted)\s*$/i;
  function ownBidCard() {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!OWN_BID_ACTION.test(n.nodeValue)) continue;
      const el = n.parentElement;
      if (visible(el) && el.closest("app-bid-card, app-bid-card-actions-pattern, button, a, fl-button, fl-link, [role='button']")) return true;
    }
    return false;
  }
  function alreadyBid() {
    return !!buttonByText(/^(update bid(\s+(and|&)\s+pay\b[\s\S]*)?|retract bid)$/i) || !!findText(/edit your bid on this project/i) || ownBidCard();
  }

  // "Bids 6" in the project header: Freelancer's app-project-summary has a "Bids"
  // label with the count under it (a loading placeholder until it arrives).
  // null while loading or when the page has no count.
  const NAV = "header, nav, [role='navigation'], fl-navigation, [class*='Navigation' i], [class*='navbar' i]";
  function bidCount() {
    const num = (s) => parseInt(s.replace(/,/g, ""), 10);
    const val = document.querySelector("app-project-summary .ContentWrapper:not(.Bid) .text-body-24");
    const own = val && getText(val).match(/^\d[\d,]*$/);
    if (own) return num(own[0]);
    // Other layouts: a "Bids" label whose box reads "Bids 6".
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      if (!/^\s*bids:?\s*$/i.test(n.nodeValue) || !visible(n.parentElement) || n.parentElement.closest(NAV)) continue;
      for (let el = n.parentElement.parentElement, up = 0; el && up < 3; el = el.parentElement, up++) {
        const m = getText(el).match(/^\s*bids:?\s*(\d[\d,]*)\s*(\n|$)/i);
        if (m) return num(m[1]);
      }
    }
    const out = findText(/\d[\d,]* freelancers are bidding/i); // logged-out page
    return out ? num(getText(out).match(/(\d[\d,]*) freelancers/i)[1]) : null;
  }

  // Banners that stop a bid. Titles and messages are Freelancer's own (its bid form
  // code): "You must be a Preferred Freelancer", "Bidding on this project is
  // restricted" + "You must be Verified by Freelancer to bid on projects $2,500.00
  // USD and over...", "You have already bid on this project.", and a few rarer ones.
  // Not here: "You must sign the IP Agreement to work on this project" (a bid goes
  // through without it) and the NDA banner (see ndaLink: the box opens it to sign).
  const BLOCKERS = [
    { kind: "already", re: /you have already bid on this project/i },
    { kind: "preferred", re: /^\s*(you must be a preferred freelancer|only preferred freelancers can bid)/i },
    { kind: "verified", re: /^\s*you must be verified by freelancer to bid/i },
    { kind: "restricted", re: /^\s*(bidding on this project is restricted|you have a negative balance|this project is open to select freelancers only|this project requires a facebook certification|you must complete your profile to quote)/i },
    { kind: "nobids", re: /^\s*you have used all of your bids/i },
    { kind: "sign", re: /^\s*the client requires you to sign an agreement/i },
  ];
  // "You must sign the Non-Disclosure Agreement to work on this project. By signing the
  // Non-Disclosure Agreement ...": Freelancer refuses a bid until it is signed. The
  // banner's link opens the signing page in a new tab (initialize-nda-contract.php).
  function ndaLink() {
    const byHref = [...document.querySelectorAll("a[href*='initialize-nda-contract']")].find(visible);
    if (byHref) return byHref;
    return [...document.querySelectorAll("a, fl-link")].find((l) => /^\s*non[-\s]?disclosure agreement\s*$/i.test(getText(l)) && visible(l) &&
      /sign the\s+non[-\s]?disclosure agreement/i.test(getText(l.closest("fl-banner-alert, fl-card, [role='alert']") || l.parentElement))) || null;
  }
  // { href } of the NDA link (only a freelancer.com address), or null when there is none.
  function nda() {
    const l = ndaLink();
    if (!l) return null;
    const a = l.matches("a") ? l : l.querySelector("a");
    const href = a && /^https:\/\/([a-z0-9-]+\.)?freelancer\.com\//i.test(a.href) ? a.href : "";
    return { href };
  }
  // The banner's whole text: the first box around the matched line that adds more.
  function bannerText(el) {
    const own = getText(el).replace(/\s+/g, " ");
    for (let p = el.parentElement, up = 0; p && up < 4; p = p.parentElement, up++) {
      const t = getText(p).replace(/\s+/g, " ");
      if (t.length > 500) break;
      if (t.length > own.length + 15) return t;
    }
    return own;
  }
  // { kind, message } for the first reason (in BLOCKERS order) this project cannot
  // be bid on, or null. One pass over the page's text for all banners.
  function blocker() {
    if (alreadyBid()) return { kind: "already", message: "You have already bid on this project." };
    const found = BLOCKERS.map(() => null);
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const v = n.nodeValue;
      if (v.length < 12) continue;
      BLOCKERS.forEach((b, i) => { if (!found[i] && b.re.test(v) && visible(n.parentElement)) found[i] = n.parentElement; });
    }
    const i = found.findIndex(Boolean);
    if (i < 0) return null;
    const message = bannerText(found[i]);
    const kind = BLOCKERS[i].kind === "restricted" && /you must be verified by freelancer to bid/i.test(message) ? "verified" : BLOCKERS[i].kind;
    return { kind, message };
  }
  function errorTexts() {
    const out = [];
    for (const el of document.querySelectorAll("[class*='error' i], [role='alert']")) {
      const t = getText(el);
      if (t && t.length < 200 && visible(el) && out.indexOf(t) === -1) out.push(t);
    }
    return out.slice(0, 5);
  }

  // ---------- 1) read the project ----------

  function findTitle() {
    const sel = ["fl-heading[size='xlarge']", "fl-heading[size='large']", "h1.PageTitle", "h1[class*='title' i]", ".ProjectViewDetails-title", "[class*='project-title']", "h1"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 4) return t;
    }
    return (document.title || "").replace(/\s*[-|].*$/, "").trim() || "Freelancer Project";
  }

  // The budget is a short text like "$30.00 – 250.00 USD", or "$50.00+ AUD per hour"
  // when the client gave only a minimum (Freelancer's currency pipe writes "+" then;
  // recruiter projects often have one). Freelancer's own budget box first
  // (app-project-details-budget), then the project card, and never the top bar (it
  // shows the account balance, "£0.00 GBP").
  function findBudget(card) {
    const AMOUNT = "\\d[\\d,]*(?:\\.\\d+)?";
    const RANGE = new RegExp(AMOUNT + "(?:\\s*[–—-]\\s*\\D{0,3}" + AMOUNT + "|\\s*\\+)\\s*(" + CODES + ")\\b");
    const SINGLE = new RegExp(AMOUNT + "\\+?\\s*(" + CODES + ")\\b");
    const SKIP = /paid to you|fee|average|avg|bids?\b|balance/i;
    for (const el of document.querySelectorAll("app-project-details-budget p, .ProjectViewDetails-budget p")) {
      const t = getText(el).replace(/\s+/g, " ");
      if (SINGLE.test(t) && /[1-9]/.test(t) && visible(el)) return t;
    }
    const scan = (root, re) => {
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (!/\d/.test(n.nodeValue) || !n.parentElement || n.parentElement.closest(NAV)) continue;
        let el = n.parentElement;
        for (let up = 0; up < 3 && el; up++, el = el.parentElement) {
          // textContent first (no page layout); innerText only for the match.
          const t = el.textContent.replace(/\s+/g, " ").trim();
          if (t.length > 80) break;
          if (re.test(t) && /[1-9]/.test(t) && !SKIP.test(t) && visible(el)) return getText(el).replace(/\s+/g, " ");
        }
      }
      return "";
    };
    return (card && scan(card, RANGE)) || scan(document.body, RANGE) || (card && scan(card, SINGLE)) || "";
  }

  // The card that holds the description, the skill tags and "Project ID: ...".
  function projectCard() {
    const pid = findText(/project id/i);
    for (let el = pid && pid.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      if (getText(el).length > 150) return el;
    }
    return null;
  }

  const STATUS_TAG = /^(open|closed|awarded|featured|urgent|nda|sealed|full ?time|recruiter|ip agreement|private|qualified|guaranteed)$/i;

  function findSkills(card) {
    // Skill tags link to /jobs/<skill>; status tags like "Open" do not.
    const sel = ["fl-tag", ".TagsList-tag", "[class*='SkillTag']", "[class*='skill-tag']", "[data-cy='skill-tag']"].join(", ");
    for (const scope of [card, document]) {
      if (!scope) continue;
      const all = [...scope.querySelectorAll(sel)];
      const linked = all.filter((el) => el.querySelector("a[href*='/jobs/']"));
      const list = [];
      for (const el of linked.length ? linked : all) {
        const t = getText(el);
        if (t && t.length < 60 && !STATUS_TAG.test(t) && list.indexOf(t) === -1) list.push(t);
      }
      if (list.length) return list;
    }
    // Fallback: the short leaf texts between "Skills Required" and "Project ID".
    const label = findText(/^\s*skills required\s*$/i);
    if (!label) return [];
    const box = label.parentElement && label.parentElement.parentElement;
    const list = [];
    if (box) {
      for (const el of box.querySelectorAll("*")) {
        if (el.children.length || !follows(label, el)) continue;
        const t = getText(el);
        if (/^project id/i.test(t)) break;
        if (t && t.length < 60 && list.indexOf(t) === -1) list.push(t);
      }
    }
    return list.slice(0, 30);
  }

  function findDescription(title, pageText, card, skills) {
    if (card) {
      // Card text up to "Skills Required", the skill tag list or "Project ID".
      const t = cleanText(getText(card));
      const cuts = [t.search(/\n\s*skills required\s*\n/i), t.search(/\n\s*project id/i)];
      if (skills.length > 1) cuts.push(t.indexOf("\n" + skills[0] + "\n" + skills[1]));
      else if (skills.length === 1) cuts.push(t.lastIndexOf("\n" + skills[0] + "\n"));
      const cut = Math.min(...cuts.filter((i) => i > 0));
      const desc = (isFinite(cut) ? t.slice(0, cut) : t).trim();
      if (desc.length > 100) return desc.slice(0, 15000);
    }
    const sel = ["app-project-description", "fl-text[class*='description' i]", "[class*='ProjectDescription']", "[class*='project-description']", ".NDAProject-description", "[data-cy='project-description']"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 30) return cleanText(t);
    }
    const head = findText(/^\s*project (description|details)\s*$/i);
    for (let el = head && head.parentElement, up = 0; el && up < 5; el = el.parentElement, up++) {
      const t = cleanText(getText(el));
      if (t.length > 100 && t.length < 15000) return t;
    }
    // Fallback: the page text between the title and "Skills Required".
    const start = title ? pageText.indexOf(title) : -1;
    const end = pageText.search(/\n\s*skills required\s*\n/i);
    if (start >= 0 && end > start) return pageText.slice(start + title.length, end).trim();
    const cut = pageText.search(/place a bid on this project/i);
    return (cut > 0 ? pageText.slice(0, cut) : pageText).slice(0, 8000).trim();
  }

  function findClient() {
    const sel = ["app-client-details", "[class*='ClientDetails']", "[class*='client-details']", "app-employer-info", "[class*='EmployerInfo']", "[class*='AboutClient']", "[class*='about-client']", "[data-cy='client-info']"];
    for (const s of sel) {
      const t = getText(document.querySelector(s));
      if (t.length > 10) return cleanText(t);
    }
    const head = findText(/about\s+the\s+client/i);
    for (let el = head && head.parentElement, up = 0; el && up < 6; el = el.parentElement, up++) {
      const t = cleanText(getText(el));
      if (t.length > 60 && t.length < 2000) return t;
    }
    return "";
  }

  function findVerifications() {
    const badges = ["Identity verified", "Payment verified", "Deposit made", "Email verified", "Profile completed", "Phone verified"];
    const out = [];
    for (const badge of badges) {
      const el = findText(new RegExp("^\\s*" + badge + "\\s*$", "i"));
      if (!el) continue;
      let green = false;
      for (let row = el, up = 0; row && up < 8; row = row.parentElement, up++) {
        const icon = row.querySelector("[data-color]");
        if (icon) { green = /^(success|aqua-light|blue-xdark)$/.test(icon.getAttribute("data-color") || ""); break; }
      }
      out.push(badge + ": " + (green ? "YES" : "NO"));
    }
    return out;
  }

  async function extract() {
    // Normally the form is already there and this returns at once. It waits while
    // Freelancer is still building the page, and once the project is shown, at most
    // 3 s more for a form (none when you have bid already or bidding is closed).
    // Not for the page's load event: the project and its form are on the page long
    // before Freelancer's images and trackers finish loading (that took up to 15 s).
    await waitFor(() => proposalBox() || projectCard() || blocker(), 15000);
    if (!proposalBox()) await waitFor(() => proposalBox() || blocker(), 3000);
    const stop = blocker();
    const pageText = cleanText(document.body.innerText);
    const title = findTitle();
    const card = projectCard();
    const budget = findBudget(card);
    const tl = pageText.match(/(?:bidding\s+)?ends\s+in[^\n]{0,40}/i);
    const skills = findSkills(card);
    const desc = findDescription(title, pageText, card, skills);
    const client = findClient();
    const verifications = findVerifications();
    const projectId = (pageText.match(/project id:?\s*(\d+)/i) || [])[1] || "";
    const formType = findText(HOURLY_LABEL) ? "hourly" : findText(PRICE_LABEL) ? "fixed" : "";
    // "Describe your proposal (minimum 100 characters)": the project's own minimum.
    const minLabel = getText(findText(PROPOSAL_LABEL)).match(/minimum\s+(\d+)\s+characters/i);

    const SEP = "------------------------------------------------------------";
    // No link in the text: ChatGPT would search the web for it before answering.
    const lines = ["=== " + title + " ==="];
    if (projectId) lines.push("Project ID: " + projectId);
    if (budget) lines.push("Budget: " + budget);
    if (tl) lines.push("Timeline: " + tl[0].replace(/\s+/g, " ").trim());
    if (skills.length) lines.push("Skills: " + skills.join(", "));
    lines.push(SEP, "", "PROJECT DESCRIPTION", "", desc || "(description not found)");
    if (client || verifications.length) {
      lines.push("", SEP, "", "CLIENT INFORMATION", "");
      if (client) lines.push(client);
      if (verifications.length) lines.push("", verifications.join("\n"));
    }

    return {
      ok: true,
      data: {
        title, budget, formType, projectId, url: location.href,
        minChars: minLabel ? parseInt(minLabel[1], 10) : null,
        hasProposal: !!(proposalBox() || findText(PROPOSAL_LABEL)),
        alreadyBid: !!stop && stop.kind === "already",
        blocker: stop,
        // May still be loading (null); the panel reads it again before Place Bid.
        bids: bidCount(),
        nda: nda(),
        idRequired: /identity verification|verify your identity|id verification/i.test(pageText),
        text: lines.join("\n"),
      },
    };
  }

  // ---------- 3+4) proposal, price, timeline ----------

  async function fill({ proposal, price, period }) {
    const box = proposalBox();
    if (!box) throw new Error("Proposal box not found");
    if (box.maxLength > 0 && proposal.length > box.maxLength) {
      throw new Error("Proposal is " + proposal.length + " characters, the box allows " + box.maxLength);
    }
    const priceIn = inputAfterLabel(PRICE_LABEL);
    const periodIn = inputAfterLabel(PERIOD_LABEL);
    if (!priceIn) throw new Error("Price input (Bid Amount / Hourly Rate) not found");
    if (!periodIn || periodIn === priceIn) throw new Error("Timeline input (Delivered in / Weekly Limit) not found");

    box.scrollIntoView({ block: "center" });
    typeText(box, proposal);
    await sleep(STEP);
    const tabbed = pressTab(box);
    await sleep(STEP);
    setValue(priceIn, String(price));
    await sleep(STEP);
    setValue(periodIn, String(period));
    await sleep(STEP);
    // Leaving the box once more saves its text into the form again (handleBlur),
    // so a proposal the form dropped meanwhile is restored or shows its error now.
    fireFocus(box);
    fireBlur(box);
    await sleep(150);

    // Make sure Freelancer took the proposal; one retry, else stop before Place Bid.
    let retried = false;
    if (proposalRejected(box, proposal)) {
      retried = true;
      retypeText(box, proposal);
      await sleep(STEP);
      pressTab(box);
      await sleep(300);
      if (proposalRejected(box, proposal)) {
        throw new Error("Freelancer did not accept the proposal text (it shows \"Please enter your proposal\"). Nothing was submitted.");
      }
    }
    return { ok: true, price: priceIn.value, period: periodIn.value, chars: box.value.length, tabbed, retried, errors: formErrors() };
  }

  // Right before Place Bid: Freelancer resets its bid form when some of its data
  // reloads (empty proposal, its default price and days), which can happen while the
  // box waits for the Place Bid time. Whatever no longer holds our value is filled
  // again. Returns the names of the fields that were refilled.
  const amount = (v) => parseFloat(String(v).replace(/[^\d.]/g, ""));
  const sameAmount = (el, v) => Math.abs(amount(el.value) - Number(v)) < 0.005;
  async function restoreForm({ proposal, price, period }) {
    const restored = [];
    if (proposal == null) return restored;
    const box = proposalBox();
    const priceIn = inputAfterLabel(PRICE_LABEL);
    const periodIn = inputAfterLabel(PERIOD_LABEL);
    if (box && box.value !== proposal) {
      typeText(box, proposal);
      await sleep(STEP);
      fireBlur(box);
      await sleep(STEP);
      restored.push("proposal");
    }
    if (priceIn && price != null && !sameAmount(priceIn, price)) {
      setValue(priceIn, String(price));
      await sleep(STEP);
      restored.push("price");
    }
    if (periodIn && periodIn !== priceIn && period != null && !sameAmount(periodIn, period)) {
      setValue(periodIn, String(period));
      await sleep(STEP);
      restored.push("timeline");
    }
    if (restored.length && box) {
      fireFocus(box);
      fireBlur(box);
      await sleep(150);
      if (proposalRejected(box, proposal)) throw new Error("Freelancer had reset the bid form and did not take the proposal again. Place Bid was not clicked.");
    }
    return restored;
  }

  // ---------- 4) optional upgrades ----------

  // Each upgrade row has a tag ("SPONSORED", maybe uppercase only through CSS) and
  // a description; the description is the fallback if the tag is not found.
  const UPGRADES = {
    sponsored: [/^\s*sponsored\s*$/i, /sponsoring will boost|sponsor(ed)? (your )?bid/i],
    sealed: [/^\s*sealed\s*$/i, /sealed entry|hide your bid from other/i],
    highlight: [/^\s*highlight(ed)?\s*$/i, /highlight your bid/i],
  };
  const COST = new RegExp("[$€£₹]?\\s*\\d[\\d,]*(?:\\.\\d+)?\\s*(?:" + CODES + ")\\b|\\bfree\\b", "i");
  const isChecked = (box) => (box instanceof HTMLInputElement ? box.checked : box.getAttribute("aria-checked") === "true");

  // The upgrade's row: the smallest box around its tag holding exactly one checkbox.
  function upgradeRow(tag) {
    for (let el = tag.parentElement, up = 0; el && up < 8; el = el.parentElement, up++) {
      const inputs = el.querySelectorAll("input[type=checkbox]");
      const boxes = inputs.length ? inputs : el.querySelectorAll("[role=checkbox]");
      if (boxes.length > 1) return null;
      if (boxes.length === 1) return { row: el, box: boxes[0] };
    }
    return null;
  }

  // want: { sponsored: true, sealed: false, ... }. Each upgrade found on the page is
  // ticked or unticked to match.
  async function upgrades({ want }) {
    // Part of the bid form: if the form is there, so is this section (when offered).
    const head = await waitFor(() => findText(/^\s*optional upgrades\s*$/i), 600);
    if (!head) return { ok: true, found: false, list: [] };
    const placeBtn = buttonByText(PLACE_BID);
    const list = [];
    for (const name of Object.keys(UPGRADES)) {
      if (!(name in want)) continue;
      let parts = null;
      for (const re of UPGRADES[name]) {
        const tag = findText(re, head);
        if (tag && (!placeBtn || follows(tag, placeBtn))) parts = upgradeRow(tag);
        if (parts) { parts.tag = tag; break; }
      }
      if (!parts) { list.push({ name, found: false }); continue; }
      const { row, box, tag } = parts;
      const item = { name, found: true, cost: (getText(row).replace(/\s+/g, " ").match(COST) || [""])[0] };
      if (isChecked(box) !== !!want[name]) {
        if (isDisabled(box)) item.disabled = true;
        else {
          row.scrollIntoView({ block: "center" });
          // The real box is often hidden behind a styled one; if a click on it does
          // not change it, click its label, the styled box next to it, then the tag.
          const label = box.id ? document.querySelector("label[for='" + CSS.escape(box.id) + "']") : null;
          for (const target of [box, label, box.closest("label"), box.nextElementSibling, tag]) {
            if (!target) continue;
            target.click();
            await sleep(120);
            if (isChecked(box) === !!want[name]) { item.changed = true; break; }
          }
        }
      }
      item.on = isChecked(box);
      list.push(item);
    }
    return { ok: true, found: true, list };
  }

  // ---------- 5+6) clarification board ----------

  function boardParts() {
    const head = findText(BOARD_LABEL);
    if (!head) return null;
    const input = after(head, "textarea, [contenteditable='true']");
    return { head, input, post: buttonByText(/^post$/i, head) };
  }

  const flat = (s) => (s || "").replace(/\s+/g, " ").trim();
  // The box holds the question (its start: the page may change the line breaks).
  const holds = (input, text) => flat(valueOf(input)).startsWith(flat(text).slice(0, 80));
  // The questions on the board are Freelancer's fl-comment elements.
  const boardComments = () => document.querySelectorAll("fl-comment");
  const onBoard = (text) => { const want = flat(text).slice(0, 60); return !!want && [...boardComments()].some((c) => flat(c.textContent).includes(want)); };

  // The board is Freelancer's comment form, which saves and reloads its draft: when the
  // project's data reloads (right after a bid, for one) the form starts over and what
  // was just typed is gone. So the text must still be in the box a moment after typing;
  // if not, it is typed again (three tries).
  async function clarifyFill({ text }) {
    let parts = boardParts();
    if (!parts) return { ok: true, found: false };
    if (!parts.input) {
      // Some layouts show a button first and only open the box after a click.
      const opener = buttonByText(/ask a question|post a (question|message)|add a (question|message)/i, parts.head);
      if (opener) { opener.click(); await waitFor(() => { parts = boardParts(); return parts && parts.input; }, 1000); }
    }
    if (!parts || !parts.input) return { ok: true, found: false };
    let tries = 0;
    for (;;) {
      tries++;
      parts.input.scrollIntoView({ block: "center" });
      parts.input.click();
      if (parts.input instanceof HTMLTextAreaElement) typeText(parts.input, text);
      else setValue(parts.input, text, true);
      await sleep(700);
      parts = (await waitFor(() => { const p = boardParts(); return p && p.input ? p : null; }, 3000)) || parts;
      if (holds(parts.input, text)) break;
      if (tries === 3) throw new Error("Clarification board: Freelancer emptied the box after the question was typed (3 tries)");
    }
    if (!(await activePost(3000))) throw new Error("Clarification board: the Post button did not become active");
    return { ok: true, found: true, tries };
  }

  // Right after a bid Freelancer reloads the project (its bid count goes up), and that
  // starts the board's form over (see clarifyFill). Wait for it (at most 6 s; without a
  // count, 3 s), then a little longer, before the question is typed. No board box to
  // type into (none on the page, or you may not post): nothing to wait for.
  async function afterBid({ bids }) {
    const t0 = Date.now();
    if (!(await waitFor(() => { const p = boardParts(); return p && p.input; }, 1000))) return { ok: true, noBoard: true, ms: Date.now() - t0 };
    let countUp = false;
    if (bids == null) await sleep(3000);
    else countUp = !!(await waitFor(() => { const n = bidCount(); return n != null && n > bids; }, 6000));
    await sleep(800);
    return { ok: true, countUp, ms: Date.now() - t0 };
  }

  // The Post button can be hidden until the box has focus, so focus it first.
  async function activePost(ms) {
    const parts = boardParts();
    if (parts && parts.input) fireFocus(parts.input);
    return waitFor(() => {
      const p = boardParts();
      return p && p.post && !isDisabled(p.post) ? p.post : null;
    }, ms);
  }

  // text: the question the box filled (not in review mode: you may have changed it).
  // It must still be in the box right before Post. After Post: confirmed = the box
  // emptied (Freelancer's form does that on success); shown = the question is on the
  // board (a new fl-comment, or one with this text).
  async function clarifyPost({ text } = {}) {
    const parts = boardParts();
    if (!parts || !parts.input) throw new Error("Clarification board not found");
    if (!valueOf(parts.input).trim()) throw new Error("Clarification board box is empty (Freelancer cleared it)");
    if (text && !holds(parts.input, text)) throw new Error("Clarification board box no longer holds the question (Freelancer cleared it)");
    const before = boardComments().length;
    const post = await activePost(3000);
    if (!post) throw new Error("Clarification board Post button not found");
    post.click();
    const cleared = await waitFor(() => { const now = boardParts(); return !now || !now.input || !valueOf(now.input).trim(); }, 10000);
    if (!cleared) return { ok: true, confirmed: false, errors: errorTexts() };
    const shown = await waitFor(() => boardComments().length > before || (text && onBoard(text)), 8000);
    return { ok: true, confirmed: true, shown: !!shown };
  }

  // ---------- 7) Place Bid ----------

  const FAILED = /failed to create bid/i;
  // Placed: your own bid card is on the page (its Retract / Edit actions), or
  // Freelancer says so. (findText, not the page's innerText: that is slow on a long bid list.)
  const bidPlaced = () => ownBidCard() || !!buttonByText(/^(update bid|retract bid)$/i) ||
    !!findText(/your bid (has been|was) (placed|submitted)|bid (placed|submitted) successfully/i);
  const failureText = (el) => getText(el.parentElement || el).replace(/\s+/g, " ").slice(0, 200);
  const openDialog = () => [...document.querySelectorAll("[role='dialog'], fl-modal")].find(visible);

  // Waits for the result of one Place Bid click. oldFailure is a "Failed to create
  // bid" banner already on the page before the click, so it is not mistaken for a new one.
  async function bidResult(oldFailure) {
    const path = location.pathname;
    let goneSince = 0;
    for (const t0 = Date.now(); Date.now() - t0 < 20000; ) {
      await sleep(200);
      if (bidPlaced()) return { confirmed: true };
      const f = findText(FAILED);
      if (f && f !== oldFailure) return { confirmed: false, failed: true, errors: [failureText(f), ...errorTexts()] };
      // Freelancer removes the bid form once the bid is in (your card may be further
      // down a long bid list). Same page, no dialog, form gone for 1.5 s: placed.
      const gone = location.pathname === path && !proposalBox() && !buttonByText(PLACE_BID) && !openDialog();
      if (!gone) goneSince = 0;
      else if (!goneSince) goneSince = Date.now();
      else if (Date.now() - goneSince >= 1500) return { confirmed: true, how: "the bid form closed" };
    }
    const f = findText(FAILED);
    const dialog = openDialog();
    return { confirmed: false, failed: !!f, errors: f ? [failureText(f)] : [...formErrors(), ...errorTexts()].slice(0, 5), dialog: dialog ? getText(dialog).slice(0, 300) : "" };
  }

  // msg: { proposal, price, period } as filled (none in review mode: the page is
  // left as the user checked it).
  async function placeBid(msg) {
    if (alreadyBid()) throw new Error("This project already has your bid");
    const restored = await restoreForm(msg);
    let first = null;
    // A second click only after Freelancer itself answered "Failed to create bid".
    for (let attempt = 1; attempt <= 2; attempt++) {
      const btn = buttonByText(PLACE_BID);
      if (!btn) throw new Error("Place Bid button not found");
      const label = getText(btn).replace(/\s+/g, " ");
      if (isDisabled(btn)) throw new Error("Place Bid is disabled. " + [...formErrors(), ...errorTexts()].slice(0, 5).join(" | "));
      // Save the proposal into the form right before submitting: this blur is what
      // a manual Tab or click elsewhere does (see fireFocus).
      const box = proposalBox();
      if (box) { fireFocus(box); fireBlur(box); await sleep(150); }
      const proposalErr = findText(PROPOSAL_ERROR);
      if (proposalErr) throw new Error("Freelancer shows \"" + getText(proposalErr) + "\". Place Bid was not clicked.");
      // A value Freelancer refuses (shown in red under its field): the bid would fail.
      const errs = formErrors();
      if (errs.length) throw new Error("Freelancer shows: " + errs.join(" | ") + ". Place Bid was not clicked.");
      btn.scrollIntoView({ block: "center" });
      await sleep(STEP);
      const oldFailure = findText(FAILED);
      btn.click();
      const r = await bidResult(oldFailure);
      if (r.confirmed || !r.failed || attempt === 2) return Object.assign({ ok: true, attempts: attempt, firstError: first, button: label, restored }, r);
      first = (r.errors || []).join(" | ");
      await sleep(400);
    }
  }

  const handlers = {
    "fl:ping": async () => ({ ok: true, build: BUILD, visible: document.visibilityState === "visible" }),
    "fl:extract": extract,
    // Quick look for the box while idle: bid count and anything that blocks a bid.
    // loaded + !hasForm (and no blocker) lets the box say "No bid form".
    "fl:check": async () => ({
      ok: true, build: BUILD, bids: bidCount(), blocker: blocker(), url: location.href, nda: !!ndaLink(),
      loaded: !!projectCard(), hasForm: !!(proposalBox() || findText(PROPOSAL_LABEL)),
    }),
    // While the box waits for you (review, an NDA to sign): did you place the bid?
    // formGone: the bid form closed (your card may be further down a long bid list);
    // failed: Freelancer's "Failed to create bid" message (e.g. the NDA is not signed yet).
    "fl:ownBid": async () => {
      const f = findText(FAILED);
      const parts = boardParts();
      return {
        ok: true, url: location.href, placed: bidPlaced(),
        formGone: !proposalBox() && !buttonByText(PLACE_BID) && !openDialog(),
        failed: f ? failureText(f) : "",
        boardText: !!(parts && parts.input && valueOf(parts.input).trim()),
      };
    },
    // Last resort when the NDA link has no address the box can open itself.
    "fl:openNda": async () => {
      const l = ndaLink();
      if (!l) throw new Error("The Non-Disclosure Agreement link is not on the page");
      l.click();
      return { ok: true };
    },
    "fl:fill": fill,
    "fl:upgrades": upgrades,
    "fl:clarifyFill": clarifyFill,
    "fl:clarifyPost": clarifyPost,
    "fl:afterBid": afterBid,
    "fl:placeBid": placeBid,
    "fl:retire": async () => { retire(); return { ok: true }; },
  };
  const listener = (msg, _sender, reply) => {
    const h = handlers[msg && msg.type];
    if (!h) return false;
    h(msg).then(reply, (e) => reply({ ok: false, error: e && e.message ? e.message : String(e) }));
    return true;
  };
  function retire() {
    try { chrome.runtime.onMessage.removeListener(listener); } catch (e) {}
    if (window.__flbidFl === me) window.__flbidFl = null;
  }
  const me = {
    build: BUILD,
    alive: () => { try { return !!chrome.runtime.id; } catch (e) { return false; } },
    retire,
  };
  window.__flbidFl = me;
  chrome.runtime.onMessage.addListener(listener);
})();
