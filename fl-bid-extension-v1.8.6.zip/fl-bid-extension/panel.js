// The panel is both the interface and the runner. It lives in the small box that
// box.js puts on a Freelancer project page (as a frame, so it can use the extension
// APIs) and drives its own Freelancer tab and the ChatGPT tab through their content
// scripts, one step at a time. It works with the ChatGPT chat that is already open
// next to Freelancer (e.g. Chrome split view) and never opens a new ChatGPT tab.

const DEFAULT_PROMPT = `Write my bid for this Freelancer.com project, following my bid strategy in this chat. Also write the Clarification Board post: real questions about the client's requirements, no greeting, no self-promotion, no links or contact details.

{{PROJECT}}`;

// Freelancer's own limits for the proposal text (its bid form code): at most 1500
// characters, at least 100 unless the project's label says otherwise.
const MAX_PROPOSAL = 1500;
const MIN_PROPOSAL = 100;

// Always added at the end of the prompt, so editing the prompt cannot break the
// reply format the panel reads. The markers are described, never written out:
// only ChatGPT's answer may contain "[[PROPOSAL]]", so the page reader cannot
// mistake our own prompt (shown in the chat, maybe cut short) for the answer.
// The prompt's last line; the ChatGPT page reader skips our own prompt up to here.
// For speed: no web search (a link in the prompt made ChatGPT search the web first),
// and a short clarification post after the proposal (the box can take the proposal
// while the post is still being written), or none when the box will not post it.
const PROMPT_END = "Nothing before the PROPOSAL marker and nothing after the END marker.";
const FORMAT_HEAD = `ANSWER FORMAT (required, a tool reads your reply):
Answer at once from the text above: no web search, no opening links, no other tools.
Reply as plain chat text, not in a writing block, canvas, code block or JSON.`;
// post: "with" (the answer holds the clarification board post) or "none". Without a
// post the QUESTIONS line stays, so a post ChatGPT writes anyway can never end up in
// the proposal.
const POST_LINE = {
  with: "Write the proposal first, then the clarification board post. Keep the post short: at most 3 questions.",
  none: "Do not write a clarification board post, none is needed: after the QUESTIONS line write only the word none.",
};
const answerFormat = (minChars, post = "with") => `${FORMAT_HEAD}
Use three marker lines, each one word inside double square brackets: PROPOSAL on the line before the proposal, QUESTIONS on the line before the clarification board post, and END on the last line.
The proposal must be ${minChars} to ${MAX_PROPOSAL} characters long, spaces included (Freelancer refuses anything longer).
${POST_LINE[post] || POST_LINE.with}
${PROMPT_END}`;

const FL_PROJECT = /^https:\/\/([a-z0-9-]+\.)?freelancer\.com\/projects\//i;
const GPT_CHAT = /^https:\/\/chatgpt\.com\/(.*\/)?(c|g|uc)\//i;

const VERSION = chrome.runtime.getManifest().version;
// The content scripts' BUILD (content/freelancer.js, content/chatgpt.js): change all
// three together. A tab holding a copy with another build gets the current file.
const SCRIPT_BUILD = "1.8.6";
// waitNoBids / waitWithBids: Place Bid is clicked that many seconds after Start,
// by whether the project already has bids. rules: the Prices table (null = built-in).
const settings = { prompt: DEFAULT_PROMPT, review: true, clarify: true, waitNoBids: 15, waitWithBids: 0, rules: null,
  upSponsored: false, upSealed: false, upHighlight: false, showMore: false };
// Panel checkbox id -> upgrade name on the bid form.
const UPGRADE_BOXES = { upSponsored: "sponsored", upSealed: "sealed", upHighlight: "highlight" };
// The start buttons next to Start: Sponsored and Highlight for that bid only, in place
// of the Settings checkboxes (Sealed still comes from Settings).
const START_UPGRADES = {
  startSponsored: { sponsored: true, highlight: false },
  startHighlight: { sponsored: false, highlight: true },
  startBoth: { sponsored: true, highlight: true },
};
const upgradeNames = (pick) => [pick.sponsored && "Sponsored", pick.highlight && "Highlight"].filter(Boolean).join(" + ");
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const secs = (ms) => (ms / 1000).toFixed(1);

let running = false;
let stopRequested = false;
let stopper = null;        // { promise, reject } for the current run: Stop rejects it
let gptTabBusy = null;     // ChatGPT tab id while it is generating (for Stop)
let gptStep = null;        // { label, at } while waiting for ChatGPT (status line)
let continueWait = null;   // { resolve, reject } while paused for review
let myTabId = null;        // the Freelancer tab this panel's box is on

// ---------- interface ----------

function setStatus(text) { $("status").textContent = text; }
function log(text, kind) {
  const li = document.createElement("li");
  li.textContent = new Date().toLocaleTimeString() + "  " + text;
  if (kind) li.className = kind;
  const list = $("log");
  list.prepend(li);
  while (list.children.length > 500) list.lastChild.remove();
}
function setRunning(on) {
  running = on;
  $("start").disabled = on;
  for (const id in START_UPGRADES) $(id).disabled = on;
  $("stop").disabled = !on;
  if (!on) $("continue").hidden = true;
}
function showLast(plan, bid) {
  const box = $("last");
  box.textContent = "";
  const add = (tag, text) => { const el = document.createElement(tag); el.textContent = text; box.append(el); };
  add("div", plan.summary);
  add("pre", bid.proposal);
  if (bid.questions) { add("div", "Clarification question:"); add("pre", bid.questions); }
  $("lastBox").open = true;
}

async function loadSettings() {
  Object.assign(settings, await chrome.storage.local.get(settings));
  $("prompt").value = settings.prompt;
  $("review").checked = settings.review;
  $("clarify").checked = settings.clarify;
  $("waitNoBids").value = settings.waitNoBids;
  $("waitWithBids").value = settings.waitWithBids;
  for (const id in UPGRADE_BOXES) $(id).checked = settings[id];
  renderRules();
  showMore(settings.showMore);
}
function showMore(on) {
  $("more").hidden = !on;
  $("toggleMore").setAttribute("aria-expanded", String(on));
}
function save(key, value) {
  settings[key] = value;
  chrome.storage.local.set({ [key]: value });
}

$("prompt").addEventListener("change", (e) => save("prompt", e.target.value));
$("review").addEventListener("change", (e) => save("review", e.target.checked));
$("clarify").addEventListener("change", (e) => save("clarify", e.target.checked));
for (const id in UPGRADE_BOXES) $(id).addEventListener("change", (e) => save(id, e.target.checked));
for (const id of ["waitNoBids", "waitWithBids"]) {
  $(id).addEventListener("change", (e) => {
    const s = Math.max(0, Math.min(600, parseInt(e.target.value, 10) || 0));
    e.target.value = s;
    save(id, s);
    showCheck(lastCheck);
  });
}

// ---------- Prices (the tier table pricing.js uses) ----------

const RULE_FIELDS = ["from", "to", "price", "period"];
const rules = () => flCleanRules(settings.rules);

function ruleRow(type, r) {
  const tr = document.createElement("tr");
  for (const f of RULE_FIELDS) {
    const td = document.createElement("td");
    const input = document.createElement("input");
    input.type = "number";
    input.min = "0";
    input.step = "any";
    input.dataset.field = f;
    input.value = r[f] == null || r[f] === Infinity ? "" : r[f];
    if (f === "to") input.placeholder = "no limit";
    input.addEventListener("input", saveRules);
    td.append(input);
    tr.append(td);
  }
  const td = document.createElement("td");
  const del = document.createElement("button");
  del.textContent = "x";
  del.title = "Remove this tier";
  del.addEventListener("click", () => { tr.remove(); saveRules(); });
  td.append(del);
  tr.append(td);
  $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].append(tr);
  return tr;
}

function renderRules() {
  const table = rules();
  for (const type of ["fixed", "hourly"]) {
    $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].textContent = "";
    for (const r of table[type]) ruleRow(type, r);
  }
  $("rulesMsg").textContent = settings.rules ? "Your prices are in use." : "Built-in prices are in use.";
  $("rulesMsg").className = "small";
}

// Reads both tables; rows with a problem are marked and not saved (the others are).
function saveRules() {
  const out = {};
  let bad = 0;
  for (const type of ["fixed", "hourly"]) {
    out[type] = [];
    for (const tr of $(type === "fixed" ? "rulesFixed" : "rulesHourly").tBodies[0].rows) {
      const v = {};
      tr.querySelectorAll("input").forEach((i) => { v[i.dataset.field] = i.value.trim() === "" ? null : Number(i.value); });
      const ok = v.from != null && v.from >= 0 && (v.to == null || v.to > v.from) && v.price > 0 && v.period > 0;
      tr.querySelectorAll("input").forEach((i) => i.classList.toggle("bad", !ok));
      if (ok) out[type].push(v); else bad++;
    }
    if (!out[type].length) { bad++; out[type] = null; }
  }
  // A table with no good row keeps the built-in tiers for that type.
  const saved = { fixed: out.fixed || FL_RULES.fixed.map(toStored), hourly: out.hourly || FL_RULES.hourly.map(toStored) };
  save("rules", saved);
  $("rulesMsg").textContent = bad ? "Rows marked red are not used: \"from\" must be below \"to\", bid and days/hours above 0." : "Saved. Your prices are in use.";
  $("rulesMsg").className = bad ? "small err" : "small";
}
const toStored = (r) => ({ from: r.from, to: r.to === Infinity ? null : r.to, price: r.price, period: r.period });

$("addFixed").addEventListener("click", () => ruleRow("fixed", { from: "", to: "", price: "", period: "" }).querySelector("input").focus());
$("addHourly").addEventListener("click", () => ruleRow("hourly", { from: "", to: "", price: "", period: "" }).querySelector("input").focus());
$("resetRules").addEventListener("click", () => { save("rules", null); renderRules(); });

// ---------- notices: things that stop a bid, shown before Start ----------

// kind (from freelancer.js blocker()) -> short label for the box, red or amber.
const NOTICE = {
  already: { label: "Already bid", level: "warn" },
  verified: { label: "Verified only", level: "err" },
  preferred: { label: "Preferred only", level: "err" },
  restricted: { label: "Bidding restricted", level: "err" },
  sign: { label: "Sign agreement first", level: "err" },
  nobids: { label: "No bids left", level: "err" },
  noform: { label: "No bid form", level: "warn" },
  nda: { label: "NDA to sign", level: "warn" },
};
const NO_FORM_TEXT = "Freelancer shows no bid form on this project: you have probably bid on it already (your bid is in the bid list), or bidding is closed.";
const NDA_TEXT = "Freelancer takes a bid on this project only after you sign its Non-Disclosure Agreement. Start writes and fills the bid, opens the NDA in a new tab and waits: sign it, then click Place Bid yourself (or press Continue).";
function noticeText(b) {
  if (b.kind === "already") return "You already bid on this project.";
  if (b.kind === "noform") return NO_FORM_TEXT;
  if (b.kind === "nda") return NDA_TEXT;
  if (b.kind === "preferred") return "Only Preferred Freelancers can bid on this project.";
  if (b.kind === "verified") {
    const limit = (b.message.match(/projects\s+(.+?)\s+and over/i) || [])[1];
    return "You must be Verified by Freelancer to bid on this project" + (limit ? " (" + limit + " and over)" : "") + ".";
  }
  return b.message;
}
function showNotice(b) {
  const el = $("notice");
  const n = b && (NOTICE[b.kind] || { label: "Can't bid", level: "err" });
  el.hidden = !n;
  if (n) {
    el.textContent = n.label;
    el.className = n.level;
    el.title = noticeText(b);
  }
  // The box's top bar shows it too, in the same colour.
  parent.postMessage({ flbidNotice: n ? { label: n.label, level: n.level, text: noticeText(b) } : null }, location.ancestorOrigins[0] || "*");
}

// Seconds after Start for the Place Bid click, by the project's bid count
// (unknown count: the longer, no-bids wait).
const bidWait = (bids) => (bids > 0 ? settings.waitWithBids : settings.waitNoBids);

let lastCheck = null;
// "No bid form" only once the project page has shown no form for 3 s, so a page
// that is still loading does not flash it.
let noForm = { url: null, since: null };
function showCheck(r) {
  if (!r) return;
  lastCheck = r;
  if (r.url !== noForm.url) noForm = { url: r.url, since: null };
  if (r.loaded && r.hasForm === false && !r.blocker) noForm.since = noForm.since || Date.now();
  else noForm.since = null;
  const missing = noForm.since && Date.now() - noForm.since >= 3000;
  const stop = r.blocker || (missing ? { kind: "noform", message: NO_FORM_TEXT } : null);
  showNotice(stop || (r.nda ? { kind: "nda" } : null));
  // The time is counted from the Start click (it includes ChatGPT and filling).
  $("info").textContent = stop || r.bids == null ? "" : r.nda ? `Bids: ${r.bids}, Place Bid: you, after signing the NDA` : `Bids: ${r.bids}, Place Bid at ${bidWait(r.bids)} s`;
  $("info").title = "Place Bid is clicked this many seconds after Start, counted from the Start click; reading the project, ChatGPT and filling happen within that time. If they take longer, it clicks right away.";
}
// While idle, look at the page every few seconds (Freelancer changes pages without
// reloading, and the bid count arrives after the page). One look at a time.
let idleBusy = false;
async function idleCheck() {
  if (running || myTabId == null || idleBusy) return;
  idleBusy = true;
  try {
    const ask = () => quick(chrome.tabs.sendMessage(myTabId, { type: "fl:check" }), 5000);
    let r = await ask();
    if (!r || r.build !== SCRIPT_BUILD) {
      await load(myTabId, "content/freelancer.js", "fl", r);
      r = await ask();
    }
    if (r && r.ok && !running) showCheck(r);
    await warmChatGPT();
  } finally {
    idleBusy = false;
  }
}
// Load the ChatGPT script into the chat tab ahead of time, so Start goes straight
// to typing the prompt. Quiet: any problem shows up when Start runs.
async function warmChatGPT() {
  try {
    const { gpt } = await findTabs();
    const r = await quick(chrome.tabs.sendMessage(gpt.id, { type: "cgpt:ping" }), 3000);
    if (!r || r.build !== SCRIPT_BUILD) await load(gpt.id, "content/chatgpt.js", "cgpt", r);
  } catch (e) { /* no ChatGPT chat open yet */ }
}
// A message that may never be answered: its reply, or null after ms (or on an error).
function quick(promise, ms) {
  let timer;
  return Promise.race([promise.catch(() => null), new Promise((r) => { timer = setTimeout(() => r(null), ms); })])
    .finally(() => clearTimeout(timer));
}
// Injects a content script; an older copy that answered (r) is retired first, so it
// stops listening and only the current file answers.
async function load(tabId, file, prefix, r) {
  if (r) await quick(chrome.tabs.sendMessage(tabId, { type: prefix + ":retire" }), 2000);
  await chrome.scripting.executeScript({ target: { tabId }, files: [file] }).catch(() => {});
}
$("resetPrompt").addEventListener("click", () => { $("prompt").value = DEFAULT_PROMPT; save("prompt", DEFAULT_PROMPT); });

$("start").addEventListener("click", () => { if (!running) run(); });
for (const id in START_UPGRADES) $(id).addEventListener("click", () => { if (!running) run(START_UPGRADES[id]); });
$("stop").addEventListener("click", async () => {
  if (!running) return;
  stopRequested = true;
  setStatus("Stopping...");
  if (continueWait) continueWait.reject(new Error("Stopped"));
  const gpt = gptTabBusy;
  // Ends any wait for a page at once (except Post and Place Bid, whose result is
  // waited for: a click that happened cannot be undone, and the log must say so).
  if (stopper) stopper.reject(new Error("Stopped"));
  if (gpt) await quick(chrome.tabs.sendMessage(gpt, { type: "cgpt:abort", from: myTabId }), 2000);
});
$("continue").addEventListener("click", () => { if (continueWait) continueWait.resolve(); });
$("toggleMore").addEventListener("click", () => { const on = $("more").hidden; showMore(on); save("showMore", on); });
$("setShortcut").addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));

// ---------- keyboard shortcut ----------
// background.js picks the Freelancer tab and sends "panel:start" with its id; only
// that tab's panel answers. If none answers (the box was not loaded yet), it leaves
// a pendingStart note in session storage that the panel reads on load.
// The shortcut works like the main button: Start, or Continue while paused for review.

function shortcutPressed() {
  if (continueWait) continueWait.resolve();
  else if (!running) run();
}
async function takePendingStart(p) {
  if (!p || Date.now() - p.at > 10000 || p.tabId !== myTabId) return;
  await chrome.storage.session.remove("pendingStart");
  shortcutPressed();
}
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || msg.type !== "panel:start" || msg.tabId !== myTabId) return;
  reply({ ok: true });
  shortcutPressed();
});
chrome.storage.session.onChanged.addListener((changes) => {
  if (changes.pendingStart) takePendingStart(changes.pendingStart.newValue);
});
async function showShortcut() {
  const cmd = (await chrome.commands.getAll()).find((c) => c.name === "start-bid");
  const key = cmd && cmd.shortcut;
  $("startKey").textContent = key ? "(" + key + ")" : "";
  $("shortcut").textContent = key || "not set";
}
// The shortcut may have been changed in chrome://extensions/shortcuts meanwhile.
window.addEventListener("focus", showShortcut);
// Live status from the ChatGPT page while it is answering (every second), with the
// time since the prompt was sent, so a long wait never looks like a stop.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== "cgpt:progress" || !gptTabBusy || !gptStep) return;
  if (sender && sender.tab && sender.tab.id !== gptTabBusy) return;
  setStatus(`${gptStep.label}: ${msg.text} (${Math.round((Date.now() - gptStep.at) / 1000)} s)`);
  if (msg.diag) log("ChatGPT page details:\n" + msg.diag, "warn");
});
$("copyLog").addEventListener("click", async () => {
  const lines = [...$("log").children].reverse().map((li) => li.textContent);
  await navigator.clipboard.writeText(lines.join("\n"));
  $("copyLog").textContent = "Copied";
  setTimeout(() => { $("copyLog").textContent = "Copy log"; }, 1500);
});

// ---------- tab helpers ----------

function checkStop() { if (stopRequested) throw new Error("Stopped"); }

// Pings the tab's content script, injecting it first if needed (or replacing a copy
// with another build, left from before an update). If the page still holds an old
// copy that cannot be replaced, the tab is reloaded once. The reply says whether the
// page is visible (in split view both panes are).
async function ping(tab, file, type) {
  const prefix = type.split(":")[0];
  const hello = async () => { const r = await quick(chrome.tabs.sendMessage(tab.id, { type }), 5000); return r && r.ok ? r : null; };
  const current = (r) => r && r.build === SCRIPT_BUILD;
  let r = await hello();
  if (current(r)) return r;
  await load(tab.id, file, prefix, r);
  if (current(r = await hello())) return r;
  // Reloading our own tab would end this run (the panel lives on that page).
  if (tab.id === myTabId) throw new Error("Reload this Freelancer page (F5), then press Start again.");
  log("Reloading the tab \"" + tab.title + "\" to load the updated extension", "warn");
  await chrome.tabs.reload(tab.id);
  await sleep(1000);
  await waitTabLoaded(tab.id);
  await load(tab.id, file, prefix, null);
  if (current(r = await hello())) return r;
  throw new Error("Could not connect to the tab \"" + tab.title + "\". Reload it and press Start again.");
}

// One step in a tab's content script. Each step has a time limit, so a page that
// never answers cannot leave the run hanging, and Stop ends the wait at once
// (unless stoppable is false: Post and Place Bid report what really happened).
async function call(tabId, msg, ms, stoppable = true) {
  let timer;
  const late = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`The page did not finish "${msg.type}" in ${Math.round(ms / 1000)} s. Reload the tab and try again.`)), ms);
  });
  try {
    const r = await Promise.race([chrome.tabs.sendMessage(tabId, msg), late, stoppable && stopper ? stopper.promise : late]);
    if (!r) throw new Error("No answer from the page. Reload the tab and try again.");
    if (!r.ok) {
      if (r.diag) log("Page details:\n" + r.diag, "warn");
      throw new Error(r.error || "Step failed");
    }
    return r;
  } finally {
    clearTimeout(timer);
  }
}
function newStopper() {
  let reject;
  const promise = new Promise((_, r) => { reject = r; });
  promise.catch(() => {});
  return { promise, reject };
}

async function focusTab(tab) {
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
}

async function waitTabLoaded(tabId) {
  for (const t0 = Date.now(); Date.now() - t0 < 30000; await sleep(300)) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === "complete") return t;
  }
  throw new Error("The tab did not finish loading");
}

// The Freelancer tab is the one this box is on. The ChatGPT chat: with Chrome split
// view the two panes share a splitViewId, and the ChatGPT pane is used even as a new,
// empty chat (no /c/ address yet); otherwise the most recently used ChatGPT chat in
// this window wins. ChatGPT chats in other windows are the last resort.
const GPT_PAGE = /^https:\/\/chatgpt\.com\//i;
async function findTabs() {
  if (myTabId == null) throw new Error("Reload this Freelancer page (F5), then press Start again.");
  const fl = await chrome.tabs.get(myTabId);
  if (!FL_PROJECT.test(fl.url || "")) throw new Error("Open a Freelancer project page in this tab, then press Start");
  const win = await chrome.tabs.query({ windowId: fl.windowId });
  const none = chrome.tabs.SPLIT_VIEW_ID_NONE !== undefined ? chrome.tabs.SPLIT_VIEW_ID_NONE : -1;
  const split = fl.splitViewId != null && fl.splitViewId !== none
    ? win.filter((t) => t.splitViewId === fl.splitViewId && t.id !== fl.id) : [];
  const recent = (list) => [...list].sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));

  const all = await chrome.tabs.query({ url: "https://chatgpt.com/*" });
  const gpt = split.find((t) => GPT_PAGE.test(t.url || "")) ||
    [...recent(win), ...recent(all)].find((t) => t && GPT_CHAT.test(t.url || ""));
  if (!gpt) throw new Error("Open your ChatGPT bid chat next to the Freelancer page, then press Start");
  return { fl, gpt };
}

// ---------- ChatGPT prompt and reply ----------

// Literal markers would look like an answer on the page: in the user's own
// instructions and in the project text (a client could write anything there).
const noMarkers = (s) => s.replace(/\[\[\s*(PROPOSAL|QUESTIONS|END)\s*\]\]/gi, "$1 marker");

// The project's name from its address ("wordpress-college-site"), not the link itself:
// ChatGPT would search the web for a link before answering.
const projectSlug = (url) => (url || "").replace(/[?#].*$/, "").replace(/\/details\/?$/, "").split("/").filter(Boolean).pop() || "";
// post: see answerFormat; none when the box posts no clarification question.
const defaultPost = () => (settings.clarify ? "with" : "none");
function buildPrompt(projectText, url, ref, minChars, post = defaultPost()) {
  const tpl = noMarkers(settings.prompt || DEFAULT_PROMPT);
  const project = noMarkers(projectText);
  // A function, so "$&" or "$'" in the project text is not read as a replace pattern.
  const body = tpl.includes("{{PROJECT}}") ? tpl.replace("{{PROJECT}}", () => project) : tpl + "\n\n" + project;
  // The first line carries a unique ref so the panel can find this exact message
  // in the chat even if ChatGPT collapses a long prompt.
  return `Freelancer project ${projectSlug(url)} (ref:${ref})\n\n${body}\n\n${answerFormat(minChars || MIN_PROPOSAL, post)}`;
}
// Follow-up in the same chat when the proposal is over Freelancer's limit: the proposal
// only (the clarification post of the first answer is kept).
function buildShorten(url, ref, length, minChars) {
  return `Freelancer project ${projectSlug(url)} (ref:${ref})\n\n` +
    `Your proposal above is ${length} characters, but Freelancer accepts at most ${MAX_PROPOSAL}. ` +
    `Please shorten it to under 1300 characters: the same message and tone, just shorter.\n\n` +
    answerFormat(minChars || MIN_PROPOSAL, "none");
}

// partial: the answer was taken at its QUESTIONS line (the proposal is complete, the
// clarification post still being written), so only the proposal is read from it.
// A post of just "none" is no post.
function parseReply(text, partial = false) {
  const starts = [...text.matchAll(/\[\[\s*PROPOSAL\s*\]\]/gi)];
  if (!starts.length) throw new Error("ChatGPT did not answer in the [[PROPOSAL]] format. Its reply starts: " + text.slice(0, 160));
  const s = starts[starts.length - 1];
  const body = text.slice(s.index + s[0].length);
  const qm = body.match(/\[\[\s*QUESTIONS\s*\]\]/i);
  const em = body.match(/\[\[\s*END\s*\]\]/i);
  const qi = qm ? qm.index : -1;
  const ei = em ? em.index : -1;
  // A half answer is never used: it once put ChatGPT's own screen text into a bid.
  if (ei < 0 && !(partial && qi >= 0)) throw new Error("ChatGPT's answer has no [[END]] line (it was cut short), so it was not used. Press Start to try again.");
  const proposal = body.slice(0, qi >= 0 && (ei < 0 || qi < ei) ? qi : ei).trim();
  const post = qi >= 0 && qi < ei ? body.slice(qi + qm[0].length, ei).trim() : "";
  const questions = /^none\.?$/i.test(post) ? "" : post;
  const junk = (proposal + "\n" + questions).match(CHATGPT_SCREEN_TEXT);
  if (junk) throw new Error("The answer contains ChatGPT's screen text (\"" + junk[0].trim() + "\"), so it was not used. Press Start to try again.");
  return { proposal, questions };
}
const CHATGPT_SCREEN_TEXT = /you['’]re using the free version of chatgpt|chatgpt can make mistakes|^\s*(latest response|response complete|try plus free)\s*$/im;
// Freelancer refuses a proposal with an email address in it.
const EMAIL = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i;

// What Freelancer would refuse in the proposal, before anything is filled.
function checkBid(bid, minChars) {
  const n = bid.proposal.length;
  if (n < minChars) throw new Error(`ChatGPT's proposal is ${n} characters; Freelancer needs at least ${minChars}. Nothing was filled.`);
  if (n > MAX_PROPOSAL) throw new Error(`ChatGPT's proposal is ${n} characters; Freelancer accepts at most ${MAX_PROPOSAL}. Nothing was filled.`);
  if (EMAIL.test(bid.proposal)) throw new Error("ChatGPT's proposal contains an email address, which Freelancer does not accept. Nothing was filled.");
}

// The content script gives up after 6 minutes; this limit only catches a page that never answers.
const GPT_LIMIT = 400000;
// label: the status line's step while ChatGPT writes. until "questions": the answer
// comes back as soon as its proposal is written (reply.partial, see restOfAnswer).
async function askChatGPT(gptTab, prompt, marker, label, until = "") {
  gptTabBusy = gptTab.id;
  gptStep = label ? { label, at: Date.now() } : null;
  try {
    return await call(gptTab.id, { type: "cgpt:ask", prompt, marker, promptEnd: PROMPT_END, until, from: myTabId }, GPT_LIMIT);
  } catch (e) {
    // The ChatGPT page reloaded after the prompt went out: pick the answer up there.
    if (!/message channel closed|message port closed/i.test(e.message || "")) throw e;
    log("ChatGPT page reloaded, waiting for the answer there", "warn");
    await sleep(1500);
    checkStop();
    await waitTabLoaded(gptTab.id);
    await ping(gptTab, "content/chatgpt.js", "cgpt:ping");
    return await call(gptTab.id, { type: "cgpt:wait", marker, promptEnd: PROMPT_END, until, from: myTabId }, GPT_LIMIT);
  } finally {
    gptTabBusy = null;
    gptStep = null;
  }
}
// The whole answer of a prompt whose proposal came back early: ChatGPT goes on with the
// clarification post in that same answer, which is read on in the chat (no new message).
async function restOfAnswer(gptTab, marker) {
  gptTabBusy = gptTab.id;
  try {
    return await call(gptTab.id, { type: "cgpt:wait", marker, promptEnd: PROMPT_END, from: myTabId }, GPT_LIMIT);
  } finally {
    gptTabBusy = null;
  }
}

// Under the status: where the last bid's ChatGPT time went.
function showTiming(reply) {
  const el = $("timing");
  // send = typing + sending, think = until its first words, write = the rest.
  const total = reply.typedMs + reply.sentMs + reply.answerMs;
  const parts = reply.firstMs != null
    ? `send ${secs(reply.typedMs + reply.sentMs)} + think ${secs(reply.firstMs)} + write ${secs(reply.answerMs - reply.firstMs)}`
    : `send ${secs(reply.typedMs + reply.sentMs)} + answer ${secs(reply.answerMs)}`;
  el.textContent = `ChatGPT ${secs(total)} s = ${parts}` + (reply.skipped ? " (thinking skipped)" : "") + (reply.model ? ` · ${reply.model}` : "") +
    (reply.chatBids ? ` · ${reply.chatBids} earlier bid${reply.chatBids === 1 ? "" : "s"} in this chat` : "");
  el.title = "Last bid: how long ChatGPT took to take the prompt (send), before it started writing (think) and to write the answer (write).";
  el.className = reply.firstMs > 8000 ? "warn" : "";
  el.hidden = false;
}

// Place Bid is clicked no earlier than waitSec seconds after Start; if the run
// already took longer, it goes ahead at once. Stop works while waiting.
async function waitForBidTime(startedAt, waitSec) {
  const at = startedAt + (waitSec || 0) * 1000;
  if (Date.now() < at) log(`Waiting ${Math.ceil((at - Date.now()) / 1000)} s so Place Bid is clicked ${waitSec} s after Start`);
  while (Date.now() < at) {
    checkStop();
    setStatus(`7/7 Placing the bid in ${Math.ceil((at - Date.now()) / 1000)} s...`);
    await sleep(Math.min(250, at - Date.now()));
  }
  checkStop();
}

// The project's page without "/details" or a query: the bid must go to the project read.
const projectPage = (u) => (u || "").replace(/[?#].*$/, "").replace(/\/(details\/?)?$/, "");

// The project's Non-Disclosure Agreement in a new tab, to sign: the address of
// Freelancer's own link on the page (opened by the box: a script click on the page's
// new-tab link can be stopped by Chrome's pop-up blocker).
async function openNda(flTab, ex) {
  const url = ex.nda.href || (ex.projectId ? `https://www.freelancer.com/ajax/project/contract/initialize-nda-contract.php?project_id=${ex.projectId}&type=nda` : "");
  if (url) await chrome.tabs.create({ url, windowId: flTab.windowId, openerTabId: flTab.id, active: true });
  else await call(flTab.id, { type: "fl:openNda" }, 5000);
  log("This project needs its NDA signed before a bid: opened Freelancer's Non-Disclosure Agreement in a new tab", "warn");
}

// Paused (review on, or an NDA to sign): Continue goes on with Post and Place Bid, Stop
// ends the run, and a bid you place yourself on the page ends the wait too. Returns
// { byHand, boardText } (byHand: you placed the bid; boardText: the clarification
// box still holds text).
async function pause(flTab, text) {
  setStatus(text);
  $("continue").hidden = false;
  let over = false, goneSince = 0;
  const pressed = new Promise((resolve, reject) => { continueWait = { resolve, reject }; }).then(() => ({ byHand: false }));
  const never = new Promise(() => {});
  const own = (async () => {
    for (;;) {
      await sleep(1000);
      if (over) return never;
      const r = await quick(chrome.tabs.sendMessage(flTab.id, { type: "fl:ownBid" }), 3000);
      if (over) return never;
      if (!r || !r.ok) continue;
      if (projectPage(r.url) !== projectPage(flTab.url)) throw new Error("The Freelancer tab moved to another page");
      // Freelancer closes the bid form once the bid is in (your card may be further down).
      goneSince = r.formGone ? goneSince || Date.now() : 0;
      if (r.placed || (goneSince && Date.now() - goneSince >= 3000)) return { byHand: true, boardText: r.boardText };
      setStatus(r.failed ? `${text} Freelancer said: ${r.failed}` : text);
    }
  })();
  try {
    return await Promise.race([pressed, own]);
  } finally {
    over = true;
    continueWait = null;
    $("continue").hidden = true;
  }
}

// ---------- the run ----------

// pick: { sponsored, highlight } from a start button, in place of the Settings checkboxes.
async function run(pick = null) {
  const startedAt = Date.now();
  stopRequested = false;
  stopper = newStopper();
  setRunning(true);
  log("-- Start (v" + VERSION + ")" + (pick ? ", " + upgradeNames(pick) : "") + " --", "sep");
  let flTab = null, gptTab = null;
  let switched = false;
  // One message to ChatGPT per bid: the proposal and the clarification post come in one
  // answer. With review off the bid goes in first: the proposal is taken as soon as
  // ChatGPT has written it, the bid is filled and placed while the same answer goes on
  // with the post, and the post goes up right after the bid. With review on, the post
  // goes first.
  const postAfter = settings.clarify && !settings.review;
  const postNow = settings.clarify && !postAfter;
  let rest = null, restDone = false;   // the rest of that answer (the post), still being written
  let afterPost = "";                  // the post for after the bid, when the answer is complete
  try {
    const tabs = await findTabs();
    flTab = tabs.fl;
    gptTab = tabs.gpt;
    log("Freelancer: " + flTab.title);
    log("ChatGPT: " + gptTab.title + " (" + gptTab.url + ")");

    // 1) project details
    setStatus("1/7 Reading the project...");
    const flPing = await ping(flTab, "content/freelancer.js", "fl:ping");
    if (!flPing.visible) await focusTab(flTab);
    const ex = (await call(flTab.id, { type: "fl:extract" }, 30000)).data;
    log(`Read the project in ${secs(Date.now() - startedAt)} s`);
    showCheck({ bids: ex.bids, blocker: ex.blocker, url: ex.url, nda: !!ex.nda });
    if (ex.blocker) throw new Error(noticeText(ex.blocker));
    if (!ex.hasProposal) {
      if (ex.nda) {
        await openNda(flTab, ex);
        throw Object.assign(new Error("Sign the NDA in the new tab. This page shows no bid form before that: then reload it and press Start."), { plain: true });
      }
      if (ex.idRequired) throw new Error("Verify your ID on this project first");
      showNotice({ kind: "noform", message: NO_FORM_TEXT });
      throw new Error(NO_FORM_TEXT);
    }
    const minChars = ex.minChars || MIN_PROPOSAL;
    const budget = flParseBudget(ex.budget);
    const type = ex.formType || (budget.hourly ? "hourly" : "fixed");
    const plan = flPlanBid(budget, type, rules());
    if (plan.error) throw new Error(plan.error + ". Budget text: " + (ex.budget || "not found"));
    plan.summary = type === "hourly"
      ? `${plan.price} ${plan.currency}/hour, ${plan.period} hrs/week${plan.note}`
      : `${plan.price} ${plan.currency}, ${plan.period} days${plan.note}`;
    log(`${ex.title} | ${ex.budget} | ${type}`);
    log("Bid: " + plan.summary);
    checkStop();

    // 2) proposal and clarification post from ChatGPT, always in the one chat that is
    // open (never a new chat)
    setStatus("2/7 Connecting to ChatGPT...");
    const gptPing = await ping(gptTab, "content/chatgpt.js", "cgpt:ping");
    if (!gptPing.visible) { await focusTab(gptTab); switched = true; }
    let ref = Date.now().toString(36);
    const marker = "ref:" + ref;
    // The proposal early only while the ChatGPT pane is on screen. A ChatGPT tab brought
    // to the front for this bid gives its whole answer first, so the box goes there and
    // back once (a tab in the background may not show what ChatGPT writes).
    const early = postAfter && gptPing.visible;
    const askedAt = Date.now();
    log(`Prompt ready ${secs(askedAt - startedAt)} s after Start`);
    const reply = await askChatGPT(gptTab, buildPrompt(ex.text, ex.url, ref, minChars), marker, "2/7 ChatGPT", early ? "questions" : "");
    if (reply.typedMs != null) {
      const writing = reply.firstMs != null
        ? `started writing ${secs(reply.firstMs)} s after sending, done ${secs(reply.answerMs - reply.firstMs)} s later`
        : `answer in ${secs(reply.answerMs)} s`;
      log(`ChatGPT: prompt typed in ${secs(reply.typedMs)} s, sent in ${secs(reply.sentMs)} s (${reply.sentBy}), ${writing}` +
        (reply.via ? `, read from the ${reply.via}` : "") + (reply.model ? `, model "${reply.model}"` : "") + (reply.skipped ? ", its thinking skipped" : ""));
      showTiming(reply);
      // The rest of the time is ChatGPT's own; say what makes it faster.
      if (reply.firstMs > 8000) log(`ChatGPT needed ${secs(reply.firstMs)} s before writing. A ChatGPT model without "Thinking" starts sooner.`, "warn");
    }
    checkStop();
    let bid = parseReply(reply.text, reply.partial);
    if (reply.partial) {
      rest = restOfAnswer(gptTab, marker);
      rest.then(() => { restDone = true; }, () => { restDone = true; });
    }
    // Over Freelancer's limit: ChatGPT shortens it once, in the same chat. The first
    // answer is finished before that message, and its post is kept.
    if (bid.proposal.length > MAX_PROPOSAL) {
      log(`The proposal is ${bid.proposal.length} characters, Freelancer accepts at most ${MAX_PROPOSAL}: asking ChatGPT to shorten it`, "warn");
      let questions = bid.questions;
      if (rest) { questions = await rest.then((r) => parseReply(r.text).questions, () => ""); rest = null; }
      checkStop();
      ref = Date.now().toString(36);
      const shorter = await askChatGPT(gptTab, buildShorten(ex.url, ref, bid.proposal.length, minChars), "ref:" + ref, "2/7 ChatGPT (shortening)");
      checkStop();
      bid = parseReply(shorter.text);
      bid.questions = questions || bid.questions;
    }
    if (switched) { await focusTab(flTab); switched = false; }
    checkBid(bid, minChars);
    if (!settings.clarify) bid.questions = "";
    // Review off: the post waits for the bid (bid.questions is what goes up before it).
    if (postAfter) { afterPost = bid.questions; bid.questions = ""; }
    showLast(plan, bid);
    log(`Proposal: ${bid.proposal.length} chars` + (bid.questions ? ", 1 clarification post" : rest ? ", ChatGPT goes on with the clarification post (posted after the bid)" :
      afterPost ? ", 1 clarification post (posted after the bid)" : "") + `, ChatGPT took ${secs(Date.now() - askedAt)} s`);

    // The bid must go to the project we read ("/details" is the same page).
    if (projectPage((await chrome.tabs.get(flTab.id)).url) !== projectPage(flTab.url)) throw new Error("The Freelancer tab moved to another page");

    // 3+4) proposal, price, timeline
    setStatus("3-4/7 Filling the bid form...");
    const fillAt = Date.now();
    const filled = await call(flTab.id, { type: "fl:fill", proposal: bid.proposal, price: plan.price, period: plan.period }, 20000);
    log(`Filled in ${secs(Date.now() - fillAt)} s: proposal ${filled.chars} chars, ` + (filled.tabbed ? "Tab pressed" : "Tab blocked by the page") +
      `, price ${filled.price}, timeline ${filled.period}`);
    if (filled.retried) log("Freelancer did not take the proposal the first time; entered it again, now accepted", "warn");
    // Freelancer's own messages under the fields (e.g. a bid over what a new account
    // may bid): the bid would be refused, so it is not placed.
    if (filled.errors && filled.errors.length) {
      const why = "Freelancer shows: " + filled.errors.join(" | ");
      if (!settings.review) throw new Error(why + ". Nothing was submitted.");
      log(why + ". Fix it on the page before Continue.", "warn");
    }
    checkStop();

    // 4) optional upgrades: each one on the page is ticked or unticked as in the panel
    setStatus("4/7 Setting the bid upgrades...");
    const want = {};
    for (const id in UPGRADE_BOXES) want[UPGRADE_BOXES[id]] = settings[id];
    if (pick) Object.assign(want, pick);
    const up = await call(flTab.id, { type: "fl:upgrades", want }, 15000);
    const wanted = Object.keys(want).filter((k) => want[k]);
    if (!up.found) {
      if (wanted.length) log("No Optional Upgrades on this page; " + wanted.join(", ") + " not added", "warn");
    } else {
      const name = (u) => u.name[0].toUpperCase() + u.name.slice(1);
      log("Upgrades: " + up.list.map((u) => name(u) + " " + (!u.found ? "not offered" : (u.on ? "on" : "off") + (u.cost ? " (" + u.cost + ")" : ""))).join(", "));
      for (const u of up.list) {
        if (!u.found) { if (want[u.name]) log(name(u) + " is not offered on this project, not added", "warn"); continue; }
        if (u.on === want[u.name]) continue;
        if (u.on) throw new Error(name(u) + " is ticked on the page and could not be unticked. Nothing was submitted.");
        log(name(u) + " could not be ticked" + (u.disabled ? " (disabled on this project)" : "") + (settings.review ? "; tick it by hand before Continue" : ""), "warn");
      }
    }
    checkStop();

    // 5) clarification board text
    let board = false;
    if (bid.questions) {
      setStatus("5/7 Filling the clarification board...");
      board = (await call(flTab.id, { type: "fl:clarifyFill", text: bid.questions }, 25000)).found;
      log(board ? "Clarification question filled" : "No clarification board on this page, skipping", board ? "" : "warn");
    }
    checkStop();

    // An NDA to sign: Freelancer refuses the bid until it is signed, so the box does not
    // click Place Bid; it opens the NDA and waits for you, like Pause for review.
    if (ex.nda) await openNda(flTab, ex);
    let mine = { byHand: false };
    if (settings.review || ex.nda) {
      mine = await pause(flTab, ex.nda ? "Sign the NDA in the new tab, then click Place Bid (or press Continue)." : "Check the bid, then press Continue (or click Place Bid yourself).");
      checkStop();
    }

    // 6) Post on the clarification board
    if (board && !mine.byHand) {
      setStatus("6/7 Posting the clarification question...");
      const posted = await call(flTab.id, { type: "fl:clarifyPost" }, 30000, false);
      log(!posted.confirmed ? "Clicked Post, but the box did not clear. " + (posted.errors || []).join(" | ") :
        posted.shown ? "Clarification question posted" : "Clicked Post and the box emptied, but the question does not show on the Clarification Board: check it on the page",
      posted.confirmed && posted.shown ? "ok" : "warn");
      await sleep(200);
      checkStop();
    }

    // 7) Place Bid, after the wait for this project's bid count (read again now if
    // it was still loading at Start). Not when you placed it yourself while paused.
    let placed;
    let bidsBefore = ex.bids;   // the bid count before this bid (see fl:afterBid)
    if (mine.byHand) {
      placed = { confirmed: true };
      log(`You placed the bid, ${secs(Date.now() - startedAt)} s after Start`, "ok");
      // Review on: the question is posted only with Continue; it stays in its box for you.
      if (!postAfter) setStatus("Done. Bid placed." + (board && mine.boardText ? " The clarification question is still in its box: click Post to send it." : ""));
    } else {
      if (bidsBefore == null) bidsBefore = (await call(flTab.id, { type: "fl:check" }, 10000)).bids;
      const bids = bidsBefore;
      const waitSec = bidWait(bids);
      log(bids == null ? `Bid count not found, so Place Bid ${waitSec} s after Start` : `Bids: ${bids}, so Place Bid ${waitSec} s after Start`);
      await waitForBidTime(startedAt, waitSec);
      setStatus("7/7 Placing the bid...");
      // The values go along: Freelancer can reset its form while we wait (its data
      // reloads), and then they are filled in again right before the click. In review
      // mode the page is left as the user checked it (they may have changed it by hand).
      const expect = settings.review ? {} : { proposal: bid.proposal, price: plan.price, period: plan.period };
      placed = await call(flTab.id, Object.assign({ type: "fl:placeBid" }, expect), 90000, false);
      if (placed.restored && placed.restored.length) log("Freelancer had reset the bid form (" + placed.restored.join(", ") + "); filled it again before Place Bid", "warn");
      log("Clicked \"" + placed.button + "\"");
      if (placed.attempts > 1) log("First Place Bid click failed (" + placed.firstError + "); saved the proposal again and clicked once more", "warn");
      if (placed.confirmed) {
        log(`Bid placed, ${secs(Date.now() - startedAt)} s after Start`, "ok");
        if (!postAfter) setStatus("Done. Bid placed.");
      } else {
        const why = [placed.dialog, ...(placed.errors || [])].filter(Boolean).join(" | ");
        log("Clicked Place Bid but could not confirm it. " + why, "warn");
        setStatus("Clicked Place Bid. Check the page to confirm it went through.");
      }
    }

    // 8) review off: the clarification post, right after the bid. The bid is in
    // whatever happens here, so a problem is a warning, not an error.
    if (postAfter && !placed.confirmed) log("The clarification question was not posted, as the bid could not be confirmed", "warn");
    else if (postAfter) {
      try {
        // Freelancer updates the project after a bid, and that starts the board's form
        // over (text typed into it a moment earlier is lost): wait for it while ChatGPT
        // finishes the question.
        const settled = call(flTab.id, { type: "fl:afterBid", bids: bidsBefore }, 15000);
        settled.catch(() => {});
        let text = afterPost;
        if (rest) {
          if (!restDone) setStatus("Bid placed. ChatGPT: finishing the clarification question...");
          // The advice in these messages is for a bid that was not filled; this one is in.
          try { text = parseReply((await rest).text).questions; }
          catch (e) { throw e.message === "Stopped" ? e : new Error(e.message.replace(/\s*(nothing was filled|press start)[\s\S]*$/i, "")); }
        }
        checkStop();
        let done = "Done. Bid placed.";
        if (!text) log("ChatGPT wrote no clarification question; nothing posted", "warn");
        else {
          bid.questions = text;
          showLast(plan, bid);
          setStatus("Bid placed. Waiting for Freelancer to update the page...");
          const s = await settled.catch(() => null);
          checkStop();
          if (s && !s.noBoard) log((s.countUp ? "Freelancer updated the page after the bid (bid count up)" : "The bid count did not change on the page") +
            `; typing the question ${secs(s.ms)} s after the bid`);
          setStatus("Bid placed. Posting the clarification question...");
          const filled = await call(flTab.id, { type: "fl:clarifyFill", text }, 25000);
          if (!filled.found) log("No clarification board on this page; the question was not posted", "warn");
          else {
            if (filled.tries > 1) log(`Freelancer emptied the board's box after the question was typed; typed it again (${filled.tries} tries)`, "warn");
            const posted = await call(flTab.id, { type: "fl:clarifyPost", text }, 30000, false);
            if (!posted.confirmed) log("Clicked Post, but the box did not clear. " + (posted.errors || []).join(" | "), "warn");
            else if (!posted.shown) {
              log("Clicked Post and the box emptied, but the question does not show on the Clarification Board: check it on the page", "warn");
              done = "Done. Bid placed. Clicked Post: check that the question shows on the Clarification Board.";
            } else {
              log(`Clarification question posted, ${secs(Date.now() - startedAt)} s after Start`, "ok");
              done = "Done. Bid placed, clarification question posted.";
            }
          }
        }
        setStatus(done);
      } catch (e) {
        const msg = e && e.message ? e.message : String(e);
        log("The bid is placed, but the clarification question was not posted: " + msg, "warn");
        setStatus(msg === "Stopped" ? "Stopped after the bid was placed; no clarification question posted." : "Done. Bid placed; the clarification question was not posted: " + msg);
      }
    }
  } catch (e) {
    const msg = e && e.message ? e.message : String(e);
    log(msg, e && e.plain ? "warn" : "err");
    setStatus(msg === "Stopped" ? "Stopped." : e && e.plain ? msg : "Error: " + msg);
    // Back to the Freelancer page if ChatGPT was brought to the front for this run.
    if (switched && flTab) { try { await focusTab(flTab); } catch (err) {} }
  } finally {
    // A clarification post still being written when the run ended early: stop it, so
    // it never runs alongside the next bid.
    if (rest && !restDone) {
      await quick(chrome.tabs.sendMessage(gptTab.id, { type: "cgpt:abort", from: myTabId }), 2000);
      await quick(rest, 3000);
    }
    stopper = null;
    setRunning(false);
  }
}

// The box on the Freelancer page sizes its frame to what this page needs: the
// narrow button column, or a wider area while Settings is open.
function reportSize() {
  const w = $("more").hidden ? Math.ceil(document.querySelector(".main").getBoundingClientRect().width) + 16 : 340;
  const h = Math.ceil(document.body.getBoundingClientRect().height);
  parent.postMessage({ flbidSize: { w, h } }, location.ancestorOrigins[0] || "*");
}
new ResizeObserver(reportSize).observe(document.body);

$("ver").textContent = "v" + VERSION;
showShortcut();
loadSettings().then(async () => {
  const me = await chrome.tabs.getCurrent();
  myTabId = me ? me.id : null;
  takePendingStart((await chrome.storage.session.get("pendingStart")).pendingStart);
  idleCheck();
  setInterval(idleCheck, 2500);
});
